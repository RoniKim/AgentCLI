from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

from .config import (
    app_home,
    legacy_config_path,
    load_config,
    resolve_config_path,
    resolve_env_file,
    resolve_prompts_dir,
    save_config,
)
from .wizard import run_wizard

from .prompts import ensure_default_prompt_files


# ---- Defaults shown in /config ----
# NOTE: cycle.py references many args attributes directly (args.foo). Those MUST exist to avoid AttributeError,
# especially when starting from the interactive shell (/start) which constructs args from DEFAULTS.
DEFAULTS: Dict[str, Any] = {
    # Core / paths
    "repo": "",
    "config": "",
    "config_version": 2,
    "run_dir": "",            # empty => auto
    "resume_latest": False,
    "env_file": "",           # empty => auto (python-side .env is still loaded)

    # Runner behavior
    "autopilot": False,
    "loop": False,
    "loop_sleep_seconds": 60,
    "loop_max_cycles": 0,
    "loop_idle_exit_after": 0,
    "continuous": False,
    "iterations": 30,
    "max_turns_per_task": 12,
    "isolate_task": False,

    # Safety / gates
    "no_policy_scan": False,
    "policy_rules_file": "",
    "policy_rule": [],

    "no_build": False,
    "require_build": False,
    "run_tests": False,

    # dotnet gates (used by cycle.py)
    "dotnet_build_target": "",
    "dotnet_test_target": "",
    "dotnet_test_filter": "",

    # generic gates (preferred)
    # If provided, these override dotnet_* targets/filters and are used as-is.
    # Format: ["cmd", "arg1", "arg2", ...]
    "build_cmd": [],
    "test_cmd": [],
    "build_timeout_seconds": 1800,

    # Models
    "pm_model": "gpt-5-mini",
    "dev_model": "gpt-5.1-codex-mini",
    "qa_model": "gpt-5-mini",
    "qa_always": False,

    # Reporter / shutdown report
    "reporter_model": "gpt-5-nano",
    "report_max_turns": 8,

    # Dev cost controls
    "dev_auto_escalate": True,
    "dev_max_escalations": 2,
    "dev_model_tier1": "gpt-5.1-codex",
    "dev_model_tier2": "gpt-5.2-codex",
    "dev_escalate_on": ["no_diff", "build_failed", "test_failed"],

    # Timeouts (seconds) - referenced by cycle.py
    "pm_timeout_seconds": 900,
    "dev_timeout_seconds": 900,
    "mcp_timeout_seconds": 120,
    "test_timeout_seconds": 3600,

    # PM tuning knobs (referenced by cycle.py)
    "pm_structured_retries": 2,
    "pm_max_turns_continuations": 1,
    "pm_bootstrap_max_turns": 28,
    "pm_incremental_max_turns": 18,
    "pm_refresh_backlog": False,
    "pm_refresh_every_cycles": 0,
    "pm_include_working_tree": False,

    # Dev tuning knobs
    "dev_max_turns_continuations": 2,

    # MCP
    "mcp_mode": "npx",
    "codex_package": "@openai/codex@latest",

    # Docs
    "docs_read_mode": "digest",
    "docs_dir": ".doc/Docs",
    "docs_digest_file": ".doc/DOCS_DIGEST.md",
    "generate_digest": False,

    # Prompts (python-side default when empty)
    "prompts_dir": "",

    # Misc / debug
    "debug": False,
    "stop_file": "STOP",
    "allow_no_diff": False,
    "stop_if_no_diff": False,
}


# ---- python-side .env loader (no repo .env) ----
def _parse_env_lines(text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if "=" not in s:
            continue
        k, v = s.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k:
            out[k] = v
    return out


def load_python_side_env(explicit_env_file: Optional[str] = None, override: bool = False) -> None:
    """
    우선순위:
      1) --env-file (absolute or relative to AgentCLI home)
      2) AgentCLI 홈/.env
    repo 쪽 .env는 의도적으로 로드하지 않는다(요청 사항).
    """
    paths: list[Path] = []
    if explicit_env_file and str(explicit_env_file).strip():
        p = resolve_env_file(explicit_env_file)
        if p:
            paths.append(p)
    paths.append(app_home() / ".env")

    for p in paths:
        try:
            if not p.exists():
                continue
            data = _parse_env_lines(p.read_text(encoding="utf-8", errors="replace"))
            for k, v in data.items():
                if override or not os.getenv(k):
                    os.environ[k] = v
        except Exception:
            # env 로딩 실패는 치명적이지 않게
            pass


# 모듈 import 시점에 python-side .env 한번 로드(override=False)
load_python_side_env(explicit_env_file=None, override=False)


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(add_help=True)

    # Core
    p.add_argument("--repo", required=True, help="Repo root path")

    # Config / UX
    p.add_argument(
        "--config",
        default="",
        help="Config file path (default: AgentCLI/configs/<repo-slug>.json). Relative paths resolve from AgentCLI home.",
    )
    p.add_argument("--run-now", action="store_true", help="Run immediately (skip interactive shell)")
    p.add_argument("--wizard", action="store_true", help="Run wizard to create/update config")
    p.add_argument("--non-interactive", action="store_true", help="Disable interactive prompts")
    p.add_argument("--init-prompts", action="store_true", help="Create prompt templates in prompts_dir and exit")

    # Paths
    p.add_argument("--run-dir", default=None, help="Fixed run_dir to reuse. Empty/None = auto")
    p.add_argument("--resume-latest", action=argparse.BooleanOptionalAction, default=None, help="Resume latest run_dir")
    p.add_argument("--env-file", default=None, help="Path to .env (absolute or relative to AgentCLI home)")

    # Behavior
    p.add_argument("--autopilot", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--loop", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--loop-sleep-seconds", type=int, default=None)
    p.add_argument("--loop-max-cycles", type=int, default=None)
    p.add_argument("--loop-idle-exit-after", type=int, default=None)

    p.add_argument("--continuous", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--iterations", type=int, default=None)
    p.add_argument("--max-turns-per-task", type=int, default=None)
    p.add_argument("--isolate-task", action=argparse.BooleanOptionalAction, default=None)

    # Safety / gates
    # NOTE: argparse.BooleanOptionalAction cannot be used with option strings starting with "--no-" (Python 3.14+).
    # Keep backward-compatible flags while supporting an explicit enable flag.
    p.add_argument("--no-policy-scan", dest="no_policy_scan", action="store_true", default=None, help="Disable policy scan")
    p.add_argument("--policy-scan", dest="no_policy_scan", action="store_false", default=None, help="Enable policy scan")

    p.add_argument("--policy-rules-file", default=None, help="Path to policy rules file")
    p.add_argument("--policy-rule", action="append", default=None, help="Inline policy rule (repeatable)")

    p.add_argument("--no-build", dest="no_build", action="store_true", default=None, help="Disable build gate")
    p.add_argument("--build", dest="no_build", action="store_false", default=None, help="Enable build gate")
    p.add_argument("--require-build", action=argparse.BooleanOptionalAction, default=None, help="Force build gate even if no_build is true")
    p.add_argument("--run-tests", action=argparse.BooleanOptionalAction, default=None)

    p.add_argument("--dotnet-build-target", default=None, help="dotnet build target (e.g., path to .sln or project)")
    p.add_argument("--dotnet-test-target", default=None, help="dotnet test target (e.g., path to .sln or project)")
    p.add_argument("--dotnet-test-filter", default=None, help="dotnet test filter (passed to --filter)")

    # Generic gates (preferred): comma-separated argv list.
    # Examples:
    #   --build-cmd "dotnet,build,My.sln"
    #   --test-cmd  "dotnet,test,--filter,FullyQualifiedName~MyTest"
    p.add_argument("--build-cmd", default=None, help="Build command (comma-separated argv list)")
    p.add_argument("--test-cmd", default=None, help="Test command (comma-separated argv list)")
    p.add_argument("--build-timeout-seconds", type=int, default=None)

    # Models / MCP
    p.add_argument("--pm-model", default=None)
    p.add_argument("--dev-model", default=None)
    p.add_argument("--qa-model", default=None)
    p.add_argument("--reporter-model", default=None)
    p.add_argument("--report-max-turns", type=int, default=None)

    p.add_argument("--dev-auto-escalate", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--dev-max-escalations", type=int, default=None)
    p.add_argument("--dev-model-tier1", default=None)
    p.add_argument("--dev-model-tier2", default=None)
    p.add_argument("--dev-escalate-on", action="append", default=None, help="Escalate conditions (repeatable): no_diff, build_failed, test_failed")
    p.add_argument("--qa-always", action=argparse.BooleanOptionalAction, default=None)

    p.add_argument("--mcp-mode", default=None, choices=["npx", "codex", "disabled"])
    p.add_argument("--codex-package", default=None)
    p.add_argument("--mcp-timeout-seconds", type=int, default=None)

    # Docs / prompts
    p.add_argument("--docs-read-mode", default=None, choices=["digest", "full", "none"])
    p.add_argument("--docs-dir", default=None)
    p.add_argument("--docs-digest-file", default=None, help="Digest output file path (relative to repo by default)")
    p.add_argument("--generate-digest", action=argparse.BooleanOptionalAction, default=None, help="Force regenerate docs digest")

    p.add_argument(
        "--prompts-dir",
        default=None,
        help="Prompt templates directory. Absolute path or relative to AgentCLI home. Empty uses default AgentCLI/prompts/<repo-slug>/",
    )

    # Diagnostics
    p.add_argument("--debug", action=argparse.BooleanOptionalAction, default=None)

    # Misc
    p.add_argument("--stop-file", default=None)
    p.add_argument("--allow-no-diff", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--stop-if-no-diff", action=argparse.BooleanOptionalAction, default=None)  # compat only
    p.add_argument("--test-timeout-seconds", type=int, default=None)

    # PM tuning knobs
    p.add_argument("--pm-timeout-seconds", type=int, default=None)
    p.add_argument("--dev-timeout-seconds", type=int, default=None)
    p.add_argument("--pm-bootstrap-max-turns", type=int, default=None)
    p.add_argument("--pm-incremental-max-turns", type=int, default=None)
    p.add_argument("--pm-refresh-backlog", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--pm-refresh-every-cycles", type=int, default=None)
    p.add_argument("--pm-include-working-tree", action=argparse.BooleanOptionalAction, default=None)

    # Structured output knobs
    p.add_argument("--pm-structured-retries", type=int, default=None)
    p.add_argument("--pm-max-turns-continuations", type=int, default=None)
    p.add_argument("--dev-max-turns-continuations", type=int, default=None)

    return p


def _merge_effective(defaults: Dict[str, Any], cfg: Dict[str, Any], args_ns: argparse.Namespace) -> Dict[str, Any]:
    eff = dict(defaults)
    # config overlay
    for k, v in cfg.items():
        eff[k] = v

    # cli args overlay (only if not None)
    for k, v in vars(args_ns).items():
        if v is None:
            continue
        eff[k] = v


    # ---- MIGRATIONS (best-effort, for older saved configs) ----
    # Older configs may pin some tuning knobs to 0 (meaning "no continuations") simply because
    # they were created before these defaults were introduced. If the config has no explicit
    # version marker, treat 0 as "legacy default" and lift it to current defaults.
    cfg_ver = cfg.get("config_version", 0)
    try:
        cfg_ver_i = int(cfg_ver) if cfg_ver is not None else 0
    except Exception:
        cfg_ver_i = 0

    # Only apply when user did NOT pass CLI flags for these and config looks legacy.
    if cfg_ver_i < 2:
        if getattr(args_ns, "dev_max_turns_continuations", None) is None:
            v = eff.get("dev_max_turns_continuations", None)
            if v in (0, None, ""):
                eff["dev_max_turns_continuations"] = int(defaults.get("dev_max_turns_continuations", 2))
        if getattr(args_ns, "pm_max_turns_continuations", None) is None:
            v = eff.get("pm_max_turns_continuations", None)
            if v in (0, None, ""):
                eff["pm_max_turns_continuations"] = int(defaults.get("pm_max_turns_continuations", 1))

    # Always stamp current config_version in effective args (save happens via /wizard).
    eff["config_version"] = int(defaults.get("config_version", 2))

    # compat: stop_if_no_diff -> allow_no_diff inverse-ish (keep simple)
    if eff.get("stop_if_no_diff") is True and eff.get("allow_no_diff") is None:
        eff["allow_no_diff"] = False

    # normalize policy_rule
    pr = eff.get("policy_rule")
    if pr is None:
        eff["policy_rule"] = []
    elif isinstance(pr, str):
        eff["policy_rule"] = [pr]


    # normalize dev_escalate_on (repeatable CLI flag)
    de = eff.get("dev_escalate_on")
    if de is None:
        eff["dev_escalate_on"] = list(defaults.get("dev_escalate_on", []))
    elif isinstance(de, str):
        eff["dev_escalate_on"] = [de]

    # ---- normalize generic gate commands ----
    def _norm_cmd(v: Any) -> list[str]:
        if v is None:
            return []
        if isinstance(v, list):
            out = []
            for it in v:
                s = str(it).strip()
                if s:
                    out.append(s)
            return out
        if isinstance(v, str):
            s = v.strip()
            if not s:
                return []
            if "," in s:
                return [p.strip() for p in s.split(",") if p.strip()]
            # fallback: whitespace split
            return [p for p in s.split() if p]
        return []

    eff["build_cmd"] = _norm_cmd(eff.get("build_cmd"))
    eff["test_cmd"] = _norm_cmd(eff.get("test_cmd"))

    # Migration: if generic commands are empty but legacy dotnet targets are set,
    # keep behavior by synthesizing build_cmd/test_cmd. (This does NOT delete dotnet_* keys.)
    if not eff["build_cmd"]:
        bt = str(eff.get("dotnet_build_target", "") or "").strip()
        if bt:
            eff["build_cmd"] = ["dotnet", "build", bt]
    if not eff["test_cmd"]:
        tt = str(eff.get("dotnet_test_target", "") or "").strip()
        tf = str(eff.get("dotnet_test_filter", "") or "").strip()
        if tt or tf:
            cmd = ["dotnet", "test"]
            if tt:
                cmd.append(tt)
            if tf:
                cmd.extend(["--filter", tf])
            eff["test_cmd"] = cmd

    # build_timeout_seconds default fallback
    try:
        eff["build_timeout_seconds"] = int(eff.get("build_timeout_seconds") or defaults.get("build_timeout_seconds") or 1800)
    except Exception:
        eff["build_timeout_seconds"] = int(defaults.get("build_timeout_seconds") or 1800)

    return eff


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = _build_parser()
    args = parser.parse_args(argv)

    repo = Path(args.repo).expanduser().resolve()
    args.repo = str(repo)

    # Load python-side env first (explicit env_file wins)
    if args.env_file:
        load_python_side_env(explicit_env_file=str(args.env_file), override=False)
    else:
        load_python_side_env(explicit_env_file=None, override=False)

    # Resolve config path (python-side default)
    cfg_path = resolve_config_path(repo, args.config)
    legacy_path = legacy_config_path(repo)

    cfg: Dict[str, Any] = {}
    # Wizard mode: create/update config and exit
    if args.wizard:
        cfg = run_wizard(repo=repo, defaults=DEFAULTS)
        save_config(cfg_path, cfg)
        print(f"[OK] Wrote config: {cfg_path}")
        # ensure prompts exist in chosen prompts_dir
        pd = resolve_prompts_dir(repo, str(cfg.get("prompts_dir", "")))
        ensure_default_prompt_files(pd)
        raise SystemExit(0)

    # Normal mode: load config (prefer new location, fallback to legacy)
    read_path = cfg_path if cfg_path.exists() else legacy_path
    if read_path.exists():
        try:
            cfg = load_config(read_path)
            if read_path != cfg_path:
                print(f"[INFO] Loaded legacy config: {read_path}")
                print(f"[INFO] Next save/wizard writes to: {cfg_path}")
        except Exception as ex:
            print(f"[WARN] Failed to load config ({read_path}): {ex}")
            cfg = {}

    eff = _merge_effective(DEFAULTS, cfg, args)

    # Normalize config path into args.config (so /config prints the python-side path)
    eff["config"] = str(cfg_path)

    # Normalize prompts_dir to absolute python-side folder
    eff_prompts_dir = resolve_prompts_dir(repo, str(eff.get("prompts_dir", "")))
    eff["prompts_dir"] = str(eff_prompts_dir)

    # Normalize env_file if provided (string)
    if eff.get("env_file"):
        p = resolve_env_file(str(eff["env_file"]))
        eff["env_file"] = str(p) if p else ""

    # If init-prompts requested: create templates and exit
    if bool(eff.get("init_prompts", False)):
        ensure_default_prompt_files(eff_prompts_dir)
        print(f"[OK] Prompt templates ensured at: {eff_prompts_dir}")
        raise SystemExit(0)

    # Write back to args namespace
    out = argparse.Namespace()
    for k, v in eff.items():
        setattr(out, k, v)

    return out

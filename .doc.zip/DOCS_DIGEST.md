# DOCS DIGEST

이 파일은 `.doc/Docs` 문서들의 **헤딩 인덱스**만 로컬에서 추출한 디제스트입니다.
토큰 절약을 위해 에이전트는 기본적으로 이 디제스트만 읽고 진행합니다.

## Inventory
- .doc/Docs/01_Policy_Secrets.md
- .doc/Docs/02_Runbook.md
- .doc/Docs/03_API_EDGE.md
- .doc/Docs/04_API_FRONTEND.md
- .doc/Docs/05_SPEC_FUNCTIONAL.md
- .doc/Docs/06_SPEC_DESIGN.md
- .doc/Docs/07_PLAN_FRONTEND.md
- .doc/Docs/07a_PLAN_FRONTEND_CORRECTIONS.md
- .doc/Docs/08_DESIGN_SYSTEM.md
- .doc/Docs/99_PATCH_TWR.md
- .doc/Docs/PAD_DTOs.md
- .doc/Docs/PAD_FRONTEND_P0_API_CHECKLIST_2026-01-30.md

## 01_Policy_Secrets.md
- path: `.doc/Docs/01_Policy_Secrets.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## 보안/설정(Secrets) & 환경
  - ## Secrets & Config
  - ### 1) Edge Secrets (Supabase Dashboard → Edge Functions → Secrets)
  - ### 2) DB Vault Secrets (CRON 스크립트가 생성/참조)
  - ### 3) Verify JWT 설정
  - ## 예외/에러 규약
  - ## 기존 문서 재사용 예외사항

## 02_Runbook.md
- path: `.doc/Docs/02_Runbook.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## 예외/에러 규약
  - ## 기존 문서 재사용 예외사항
  - ## 운영/장애 대응 Runbook
  - ## Ops Runbook (운영 가이드)
  - ### 1) 매일 확인할 것
  - ### 2) 흔한 장애와 처방
  - ### 3) 로그/추적
  - ## 개발 빌드/실행 Runbook
  - ### 1) 기본 준비
  - ### 2) 빌드/실행
  - ### 3) 디버깅
  - ### 4) 재현/검증 기록
  - ### 5) 흔한 문제/처방

## 03_API_EDGE.md
- path: `.doc/Docs/03_API_EDGE.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## Edge API
  - ## Edge API (pad-market-sync / pad-recalc-worker) — v2.3.5 (2026-01-30)
  - ### 공통 보안 규칙 (필수)
  - ### 1) pad-market-sync
  - ### 2) pad-recalc-worker (server-only)
  - ### 장애 시그널(현장에서 바로 보는 기준)

## 04_API_FRONTEND.md
- path: `.doc/Docs/04_API_FRONTEND.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## 프론트엔드 API 명세
  - ## PAD v2.3.5 — 프론트엔드 API 명세서 (기능별 매핑)
  - ### 0. 공통 규칙
  - ### 1. 기능 목록(요약) — 구현 시 반드시 매핑
  - ### 2. 기능 목록(요약)
  - ### 2. 화면(UX) 단위 권장 호출 플로우
  - ### 3. API 레퍼런스 (기능별 호출 대상)
  - ### 4. 프론트에서 ‘자주 헷갈리는’ 규칙 정리
  - ### 5. 최소 구현 체크리스트 (오늘 밤부터 프론트 시작용)

## 05_SPEC_FUNCTIONAL.md
- path: `.doc/Docs/05_SPEC_FUNCTIONAL.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## 기능정의서
  - ## PAD v2.3.5 기능정의서 (FULL)
  - ### 0. 결론
  - ### 1. 공통 원칙(필수 가드레일)
  - ### 2. 기능 목록(요약)
  - ### 3. 기능 상세 정의(구현 단위)
  - ### 3.1 IA-01 통합 대시보드(요약) [P0]
  - ### 3.2 SI-03 수동 동기화(sync_me) [P0]
  - ### 3.3 SI-02 동기화 상태 표시(멀티 디바이스) [P0]
  - ### 3.4 TS-09 Rebuild 요청/상태 [P0]
  - ### 3.5 TS-10 Rebuild Worker(서버 실행) [P0]
  - ### 3.6 CF-01 거래 생성(멱등) [P0]
  - ### 3.7 CF-02 거래 수정(정정 체인) [P0]
  - ### 3.8 CF-03 거래 취소 [P0]
  - ### 3.9 TS-01 타임 머신 [P0]
  - ### 3.10 SI-08 앱 버전 체크(최소버전) [P0]
  - ### 4. UI/디자인 가이드(Blazor Hybrid 기준)
  - ### 5. 구현 체크리스트(P0)

## 06_SPEC_DESIGN.md
- path: `.doc/Docs/06_SPEC_DESIGN.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## 기능설계서
  - ## PAD v2.3.5 기능설계서 (FULL)
  - ### 0. 결론
  - ### 1. 공통 플로우/표준 규격
  - ### 2. 핵심 기능별 프로세스 설계(Flowchart + 검증 + 예외)
  - ### 2.1 홈 대시보드 로딩 (IA-01)
  - ### 2.2 수동 동기화 버튼 (SI-03 + SI-02)
  - ### 2.3 거래 생성 (CF-01)
  - ### 2.4 거래 수정/취소 (CF-02/CF-03)
  - ### 2.5 타임 머신(과거 시점 조회) (TS-01)
  - ### 2.6 정합성 센터(큐) + Rebuild 요청 (SI-01 + TS-09)
  - ### 2.7 Rebuild Worker 실행(서버) (TS-10)
  - ### 2.8 Daily Close(서버 배치) (SI-05)
  - ### 3. 화면/컴포넌트 설계(Blazor Hybrid)
  - ### 4. “반드시” 넣어야 하는 설계 메모(운영 사고 방지)
  - ### 5. 테스트 시나리오(스모크)

## 07_PLAN_FRONTEND.md
- path: `.doc/Docs/07_PLAN_FRONTEND.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## 프론트엔드 작업 계획
  - ## PAD v2.3.5 프론트엔드 작업 기획서 (MAUI) — 상세판 (2026-01-30)
  - ### 0. 결론(한 줄)
  - ### 1. 프로젝트 목표와 성공 기준
  - ### 2. 사용자/시나리오 정의
  - ### 3. 정보구조(IA) / 화면 구성
  - ### 4. 데이터 접근/통신 정책(가장 중요)
  - ### 5. 도메인 모델(프론트에서 반드시 명확히)
  - ### 6. 화면별 상세 설계(사양)
  - ### 7. 구현 순서(세부 Task Breakdown)
  - ### 8. 테스트 계획(프론트 기준)
  - ### 9. 운영/관측(Observability)
  - ### 10. 코드 규칙(SOLID/유지보수)
  - ### 11. 산출물(파일/폴더) 제안
  - ### 12. 오늘 저녁 “바로 시작” 체크리스트

## 07a_PLAN_FRONTEND_CORRECTIONS.md
- path: `.doc/Docs/07a_PLAN_FRONTEND_CORRECTIONS.md`
- decoded_as: `utf-8-sig`
- headings:
  - # 07a. Frontend Plan — Corrections & Additions
  - ## 1. Architecture Corrections
  - ### 1.1 Project Structure (ACTUAL vs 07_PLAN)
  - ### 1.2 Component Library Correction
  - ### 1.3 RPC Name Corrections
  - ### 1.4 DI Registration (MauiProgram.cs)
  - ## 2. Navigation Map (Actual Routes)
  - ### Sidebar Menu Structure (MainLayout.razor)
  - ## 3. Page-by-Page API Mapping (Actual Implementation)
  - ### 3.1 Dashboard (`/dashboard`)
  - ### 3.2 Transactions (`/transactions`)
  - ### 3.3 TransactionEntry (`/transactions/new`, `/transactions/edit/{id}`)
  - ### 3.4 Portfolio (`/portfolio`)
  - ### 3.5 Reports (`/reports`)
  - ### 3.6 Calendar (`/calendar`)
  - ### 3.7 Categories (`/categories`)
  - ### 3.8 Sync (`/sync`)
  - ## 4. Missing Page Specifications
  - ### 4.1 Reports Page (`/reports`)
  - ### 4.2 Calendar Page (`/calendar`)
  - ### 4.3 Portfolio Page (`/portfolio`)
  - ## 5. Transaction Type → Required Fields Matrix
  - ## 6. Common Code Patterns
  - ### 6.1 Page Lifecycle (every data page follows this)
  - ### 6.2 ApiService Pattern (Supabase PostgREST)
  - ### 6.3 Error Display
  - ## 7. Implementation Priority (Updated)
  - ### Already Implemented (functional)
  - ### Needs Completion / Bug Fixes

## 08_DESIGN_SYSTEM.md
- path: `.doc/Docs/08_DESIGN_SYSTEM.md`
- decoded_as: `utf-8-sig`
- headings:
  - # 08. BudgetBook Design System
  - ## 1. Foundation
  - ### 1.1 Technology Stack
  - ### 1.2 Theme Mode
  - ## 2. Color Palette
  - ### 2.1 CSS Custom Properties (`:root` in `wwwroot/css/app.css`)
  - ### 2.2 Usage Rules
  - ## 3. Typography
  - ### 3.1 Font Stack
  - ### 3.2 Scale
  - ### 3.3 Heading Rules
  - ## 4. Spacing & Layout
  - ### 4.1 Border Radius Tokens
  - ### 4.2 Spacing Conventions
  - ### 4.3 Page Layout
  - ### 4.4 Grid System
  - ## 5. Component Catalog
  - ### 5.1 Cards
  - ### 5.2 Buttons
  - ### 5.3 Badges
  - ### 5.4 Data Display
  - ### 5.5 Forms
  - ### 5.6 Feedback
  - ### 5.7 Navigation (Sidebar)
  - ## 6. Effects & Animations
  - ### 6.1 Glassmorphism
  - ### 6.2 Card Hover
  - ### 6.3 Page Entry Animation
  - ### 6.4 Button Hover
  - ## 7. Page Header Pattern
  - ## 8. State Patterns
  - ### 8.1 Loading State
  - ### 8.2 Empty State
  - ### 8.3 Error State
  - ## 9. Radzen Theme Overrides
  - ## 10. Utility Classes
  - ### 10.1 Flexbox (defined in app.css)
  - ### 10.2 Text
  - ### 10.3 Radzen Built-in Utilities
  - ## 11. Currency & Number Formatting
  - ## 12. Responsive Breakpoints
  - ## 13. Do's and Don'ts
  - ### DO
  - ### DON'T

## 99_PATCH_TWR.md
- path: `.doc/Docs/99_PATCH_TWR.md`
- decoded_as: `utf-8-sig`
- headings:
  - ## 패치 문서: Returns Summary(TWR)
  - ## PAD v2.3.5 패치 문서: 수익률 지표 분리 (순자산 증감률 vs 투자성과 TWR)
  - ### 0. 목적
  - ### 1. Path SQL
  - ### 2. Patch 내용 (무엇을 바꿨나)
  - ### 3. API 업데이트
  - ### 4. 운영/테스트 가이드
  - ### 5. 변경 이력

## PAD_DTOs.md
- path: `.doc/Docs/PAD_DTOs.md`
- decoded_as: `utf-8-sig`
- headings: (none found)

## PAD_FRONTEND_P0_API_CHECKLIST_2026-01-30.md
- path: `.doc/Docs/PAD_FRONTEND_P0_API_CHECKLIST_2026-01-30.md`
- decoded_as: `utf-8-sig`
- headings:
  - # PAD v2.3.5 — MAUI 프론트엔드 P0 API 체크리스트 (별도본)
  - ## 1) 프론트(MAUI)에서 “허용”되는 호출만 (✅)
  - ### 1.1 RPC (POST /rest/v1/rpc/*) — MAUI가 직접 호출
  - ### 1.2 Views (GET /rest/v1/<view>) — MAUI가 조회
  - ### 1.3 Tables (CRUD) — MAUI가 직접 CRUD 허용(마스터 데이터)
  - ## 2) 프론트(MAUI)에서 “절대 호출하면 안 되는 것” (🚫)
  - ### 2.1 Server-only RPC (대표)
  - ### 2.2 Server-only Edge
  - ### 2.3 Direct DML 금지 테이블 (MAUI에서 INSERT/UPDATE/DELETE 금지)
  - ## 3) Edge 호출(✅) — MAUI에서 쓰는 2개만
  - ### 3.1 종목 등록/보강
  - ### 3.2 수동 동기화
  - ## 4) 화면별 “최소 호출 세트” (P0 구현용)
  - ### 4.1 앱 시작(Startup)
  - ### 4.2 홈(Dashboard)
  - ### 4.3 거래 리스트(Transactions)
  - ### 4.4 거래 입력(쓰기)
  - ### 4.5 자산(Assets)
  - ### 4.6 성과(Performance)
  - ### 4.7 정합성(Integrity)
  - ### 4.8 설정(Settings)
  - ## 5) 프론트에서 “실수하면 바로 사고 나는” 규칙 6개
  - ## 6) (옵션) 설치 검증용 3분 체크 SQL

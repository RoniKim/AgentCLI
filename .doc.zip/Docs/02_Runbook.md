## 예외/에러 규약
- 원본: `EXCEPTIONS.md`

## 기존 문서 재사용 예외사항

아래 파일들은 “기능 정의/UX/흐름”이 중심이며, 이번 RELEASE의 파일명/권한 하드닝과 충돌하지 않아 **그대로 재사용**합니다.

- `PAD_v2.3.5_기능정의서_FULL_2026-01-29.md`
- `PAD_v2.3.5_기능설계서_FULL_2026-01-29.md`

아래는 **참고자료로만 유지**합니다(단일 진실 아님).
- 한국투자증권 오픈API 전체 문서(xlsx)

아래는 RELEASE에서 **새로 작성한 문서**가 기준입니다.
- `README.md`
- `EDGE_API.md`
- `SECRETS_AND_CONFIG.md`
- `OPS_RUNBOOK.md`

---

## 운영/장애 대응 Runbook
- 원본: `OPS_RUNBOOK.md`

## Ops Runbook (운영 가이드)

### 1) 매일 확인할 것
- `market_data_sync_runs` 최근 run 상태(FAILED/PARTIAL 증가 여부)
- `daily_snapshot_recalc_queue` backlog가 계속 쌓이는지 여부
- `snapshot_recalc_runs`(있다면) 최근 실행 결과

### 2) 흔한 장애와 처방
#### (A) KIS 토큰 관련
증상:
- 동기화 요청이 401/403 또는 token refresh 무한 대기
원인:
- KIS 1분 1회 발급 제한, 또는 만료시각 파싱 오류
처방:
- DB의 `kis_token_cache`는 **암호문(access_token_enc)** 만 저장.
- Edge는 `access_token_token_expired`(KST 타임스탬프)가 있으면 우선 사용하고,
  없으면 expires_in으로 계산(60초 여유)합니다.

#### (B) daily_close에서 특정 날짜만 실패하고 전체가 멈춤
대응:
- 이 설계는 “부분 실패 허용 + FFILL(전일 값 채움)”으로 전체 중단을 피합니다.
- 그래도 특정 종목/날짜가 계속 실패하면 `daily_snapshot_recalc_queue`에 쌓이고,
  `pad-recalc-worker`가 자동 복구를 시도합니다.

#### (C) MAUI에서 PostgREST 401/permission denied
대응:
- RLS 정책/GRANT 문제이므로 먼저 SQL 설치가 RELEASE 파일인지 확인.
- 특히 `kis_token_*` RPC는 authenticated에서 실행되면 안 됩니다(service_role-only).

### 3) 로그/추적
- Edge Function Logs: Supabase Dashboard에서 op별 성공/실패 원인 확인
- DB: `market_data_sync_runs`를 “운영용 단일 로그”로 사용

---

## 개발 빌드/실행 Runbook

### 1) 기본 준비
- .NET SDK: **10.0.102**
- MAUI 워크로드 설치:
```bash
dotnet workload install maui maui-android maui-ios maui-maccatalyst maui-windows
dotnet workload list
```
- 플랫폼 전제:
  - Windows: Android SDK/Emulator, JDK, Windows SDK
  - macOS: Xcode + CLT, iOS Simulator, Android SDK/Emulator

### 2) 빌드/실행
```bash
dotnet restore
dotnet build -c Debug -f net10.0-android
dotnet run -c Debug -f net10.0-android
```
필요 시 대상 프레임워크 변경:
- iOS: `net10.0-ios`
- MacCatalyst: `net10.0-maccatalyst`
- Windows: `net10.0-windows10.0.19041.0`

### 3) 디버깅
- Debug 구성에서 실행
- MainPage 로드 로그 확인(있다면)
- 에뮬레이터/시뮬레이터 로그 및 출력 창 확인

### 4) 재현/검증 기록
- 권장 검증 명령:
```bash
dotnet --version
dotnet --info
dotnet workload list
dotnet build BudgetBook.slnx -c Debug
dotnet build BudgetBook.slnx -c Release
```
- 로그 저장 위치: `.doc/BuildLogs/YYYY-MM-DD_platform_build.md`

### 5) 흔한 문제/처방
- `NETSDK1147` / 워크로드 누락: `dotnet workload install maui ...` 재실행
- Android SDK/JDK 경로 오류: SDK Manager에서 설치 상태 확인 후 환경변수 재설정
- iOS 빌드 실패: Xcode 설치/선택(`xcode-select`) 및 시뮬레이터 설치 확인
- Windows 타겟 빌드 실패: Windows SDK 설치 확인

---

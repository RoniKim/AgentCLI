## 기능정의서
- 원본: `PAD_v2.3.5_기능정의서_FULL_2026-01-29.FINAL.md`

## PAD v2.3.5 기능정의서 (FULL)
작성일: 2026-01-29 (KST)  
대상: MAUI Blazor Hybrid(Android/Windows) + Supabase(Postgres/RPC/View/Edge/Cron)

> 이 문서는 **프로젝트에 첨부된 v2.3.0 기능정의서/기능설계서의 전체 기능 범주(IA/TS/CF/SI/AD)**를 기준으로,
> v2.3.5에서 확정된 **시장 동기화(Manual/Batch/Daily Close) + Rebuild Queue/Worker** 운영 흐름을 포함하여
> **기능 정의를 누락 없이 ‘구현 가능한 단위’로 상세화**합니다.

---

### 0. 결론
- v2.3.5에서 프론트가 구현해야 하는 핵심은 **“RPC 기반 쓰기 + View/RPC 기반 읽기 + Edge 기반 동기화/Worker 연동”**을 **일관되게 UI로 노출**하는 것입니다.
- 특히 멀티 디바이스(PC ↔ 모바일) 환경에서 “동기화 버튼 연타”가 흔하므로, 앱은 **서버 로그 기반의 상태 표시(최근 동기화 시각/상태)**를 필수로 가져야 합니다.

---

### 1. 공통 원칙(필수 가드레일)
#### 1.1 데이터 접근 원칙
- **Write(삽입/수정/삭제): RPC만 사용**  
  - 거래 원장/정합성 파생 테이블은 앱에서 직접 쓰기 금지.
- **Read(조회): Dashboard RPC + View/Read Table**  
  - 홈은 가능한 1회 호출로 끝내고(예: `get_dashboard()`), 리스트/차트는 기간/페이지 기반 조회.

#### 1.2 보안 원칙
- 앱에는 **Service Role Key / Cron Secret 절대 포함 금지**  
- Edge Function은 (운영상) Verify JWT OFF일 수 있으나,
  - **MAUI 허용**: 사용자 JWT로 호출하는 user-mode (`sync_me`, `ensure_stock`)
  - **서버 전용**: `sync`, `daily_close`, `recalc-worker run` (Cron + Secret Header)

#### 1.3 멱등성(Idempotency)
- 거래 입력/수정은 `client_tx_id`를 사용한다.
  - 화면 진입 시 GUID 1개 생성 → 저장 완료까지 유지 → 재시도는 동일 GUID로.

---

### 2. 기능 목록(요약)
표의 “Supabase 연동”은 구현 시 반드시 매핑해야 하는 객체(테이블/뷰/RPC/Edge/Cron)입니다.  
우선순위: **P0(필수) / P1(권장) / P2(선택)**

#### 2.1 IA: 투자/자산 (Investment & Assets)
|    ID | 기능명                 | 설명                                    | 우선순위 | Supabase 연동                                                    |
| ----: | ---------------------- | --------------------------------------- | :------: | ---------------------------------------------------------------- |
| IA-01 | 통합 대시보드(요약)    | 순자산/NAV/현금/주식/부채 + 동기화 상태 |    P0    | RPC `get_dashboard()`                                            |
| IA-02 | NAV 일별 차트          | 일별 총자산 추이(기간 필터)             |    P0    | View/테이블 `v_portfolio_nav_daily`/`portfolio_nav_daily`        |
| IA-03 | 계좌별 NAV             | 계좌별 현금/주식/외화 평가액            |    P0    | `account_nav_daily`, `v_account_nav_daily`                       |
| IA-04 | 종목별 평가(계좌-종목) | 보유수량/평가액/통화/가격               |    P0    | `account_stock_nav_daily`, `v_account_stock_nav_daily`           |
| IA-05 | 자산 비중(자산군/통화) | 파이/도넛 차트 구성                     |    P1    | 조합(`account_nav_daily`, `account_stock_nav_daily`, `accounts`) |
| IA-06 | 실현손익 리포트        | 매도 확정 손익 집계/필터                |    P0    | `stock_realized_pnl`                                             |
| IA-07 | 배당금 리포트          | 월/종목별 배당 수령                     |    P1    | 거래 타입(배당) + 뷰/집계                                        |
| IA-08 | 미실현손익             | 현재가-평단 기반 평가손익               |    P1    | `holdings`, `stock_prices`, `fx_rates`                           |
| IA-09 | 종목 평단/손익분기     | 평단 변화/추가매수 영향                 |    P2    | 조합(`holdings`, 거래)                                           |
| IA-10 | 권리 이벤트 조회       | 액면분할/합병 등 타임라인               |    P1    | `stock_corporate_actions`                                        |
| IA-11 | 권리 이벤트 적용(관리) | 액면분할 적용 실행                      |    P2    | RPC `apply_stock_split()`                                        |
| IA-12 | 외화 지갑              | 환전 평균환율/잔고                      |    P1    | `currency_wallet`                                                |
| IA-13 | 기여도 랭킹            | NAV 변동 기여 TOP/N                     |    P2    | 조합(일별 NAV, 종목 NAV)                                         |
| IA-14 | What-if 시뮬           | 환율/주가 충격 테스트                   |    P2    | 클라이언트 계산 + 최신 NAV                                       |

#### 2.2 TS: 시계열/성과 (Time-series & Performance)
|    ID | 기능명               | 설명                                 | 우선순위 | Supabase 연동                                                                        |
| ----: | -------------------- | ------------------------------------ | :------: | ------------------------------------------------------------------------------------ |
| TS-01 | 타임 머신(날짜 조회) | 과거 날짜 기준 자산 상태 복원        |    P0    | `*_daily` 테이블/뷰                                                                  |
| TS-02 | 월별 수익률 히트맵   | 월 수익률/승률 표시                  |    P0    | `portfolio_returns_monthly`(+ 재계산 RPC)                                            |
| TS-03 | 리스크 지표 카드     | MDD/변동성 등                        |    P0    | `portfolio_metrics`/`v_portfolio_metrics`                                            |
| TS-04 | 지표 재계산(서버)    | Cron/Worker가 수행(프론트 호출 금지) |    P1    | (server-only) RPC `update_portfolio_metrics()`                                       |
| TS-05 | 롤링 수익률          | 7/30/90일 등                         |    P2    | `v_portfolio_nav_daily`                                                              |
| TS-06 | MDD 구간 하이라이트  | 고점-저점 구간 표시                  |    P2    | `v_portfolio_nav_daily`                                                              |
| TS-07 | 환율 민감도          | USD 노출 변동 영향                   |    P2    | `fx_rates_daily`, `account_nav_daily`                                                |
| TS-08 | 해외수익 분해        | 주가 vs 환율 분리                    |    P2    | `stock_prices_daily`, `fx_rates_daily`, `account_stock_nav_daily`                    |
| TS-09 | Rebuild 요청/상태    | 누락/오염 구간 재계산 요청/조회      |    P0    | RPC `request_snapshot_recalc`, `daily_snapshot_recalc_queue`, `snapshot_recalc_runs` |
| TS-10 | Rebuild 실행(서버)   | 큐 소비 + 구간 재계산 Worker         |    P0    | Edge `pad-recalc-worker?op=run` + Cron                                               |

#### 2.3 CF: 소비/현금흐름 (Cash Flow)
|    ID | 기능명                   | 설명                        | 우선순위 | Supabase 연동                                          |
| ----: | ------------------------ | --------------------------- | :------: | ------------------------------------------------------ |
| CF-01 | 거래 생성(멱등)          | 지출/수입/이체/주식/환전 등 |    P0    | RPC `process_transaction_v2`                           |
| CF-02 | 거래 수정(정정)          | VOID+CORRECTION 체인        |    P0    | RPC `edit_transaction_v2`                              |
| CF-03 | 거래 취소                | 역거래/무효화               |    P0    | RPC `reverse_transaction`                              |
| CF-04 | 거래 리스트(표시)        | VOID/CORRECTION 제외 기본   |    P0    | View `v_transactions_display`                          |
| CF-05 | 거래 감사 로그           | 정정/무효화 포함            |    P1    | View `v_transactions_with_info`                        |
| CF-06 | 카테고리 지출 분석       | 기간/카테고리별             |    P1    | `transactions`, `categories`(+ 뷰/집계)                |
| CF-07 | 카드 사이클 사용액(현재) | 청구기간 누적               |    P1    | `v_card_cycle_spend_current`                           |
| CF-08 | 카드 납부액(월별)        | 카드별/월별 납부            |    P1    | `v_card_payments_monthly`                              |
| CF-09 | 카드 사용(12개월)        | 최근 12 사이클              |    P2    | `v_card_cycle_spend_recent_12`                         |
| CF-10 | 카드 사용 스냅샷         | 일별 카드 사용량 저장       |    P1    | RPC `capture_card_usage_snapshot` + `card_usage_daily` |
| CF-11 | 고정지출 관리            | 구독/정기결제               |    P1    | `fixed_expenses`(+ 뷰)                                 |
| CF-12 | 계획 vs 실제             | 고정지출 대비 실제          |    P2    | 조합(고정지출 + 거래)                                  |
| CF-13 | 부채 현황                | 대출 잔액/금리/메모         |    P1    | `liabilities`                                          |
| CF-14 | 상환 로드맵              | 원금/이자 흐름              |    P2    | 조합(부채 + 거래)                                      |

#### 2.4 SI: 시스템/정합성 (System & Integrity)
|    ID | 기능명                 | 설명                                | 우선순위 | Supabase 연동                                |
| ----: | ---------------------- | ----------------------------------- | :------: | -------------------------------------------- |
| SI-01 | 정합성 센터(큐)        | 재계산 필요 날짜/사유               |    P0    | `daily_snapshot_recalc_queue`                |
| SI-02 | 동기화 상태 표시       | 최근 동기화 시각/상태(멀티디바이스) |    P0    | `market_data_sync_runs`                      |
| SI-03 | 수동 동기화(사용자)    | 사용자 요청 → 서버 실행 → 결과 반환 |    P0    | Edge `pad-market-sync?op=sync_me`            |
| SI-04 | 종목 등록/보강         | ticker 입력 시 메타/가격 저장       |    P0    | Edge `pad-market-sync?op=ensure_stock`       |
| SI-05 | 일일 마감(Daily Close) | 장마감 종가/환율/스냅샷 고정        |    P0    | Edge `pad-market-sync?op=daily_close` + Cron |
| SI-06 | 배치 동기화(서버)      | 전체 사용자 주기 동기화             |    P1    | Edge `pad-market-sync?op=sync` + Cron        |
| SI-07 | 스냅샷 캡처(관리)      | NAV/계좌/카드 스냅샷 저장           |    P2    | RPC `capture_*`                              |
| SI-08 | 앱 버전 체크           | 최소버전/권장버전 안내              |    P0    | `app_versions`/버전 RPC                      |

---

### 3. 기능 상세 정의(구현 단위)
아래는 “어떻게 구현할지”가 바로 보이도록, **입력/출력/검증/예외**를 포함한 정의입니다.  
(P0/P1은 상세, P2는 요약)

### 3.1 IA-01 통합 대시보드(요약) [P0]
- 목적: 앱 진입 시 1회 호출로 핵심 KPI/상태를 완성한다.
- 입력: 없음(또는 기간 옵션)
- 출력: 순자산/현금/주식가치/부채/월성과/동기화상태 등
- 검증: 인증 세션 유효(401 처리)
- 예외:
  - 네트워크 실패: 캐시 표시 + 재시도
  - 데이터 불완전(큐 존재): “보정 필요” 배너(SI-01 링크)

### 3.2 SI-03 수동 동기화(sync_me) [P0]
- 목적: 사용자가 필요할 때 서버가 환율/시세/통계를 최신으로 만든다.
- 입력:
  - Query `market=KR|US|ALL` (기본 ALL)
- 출력:
  - ok/status(SUCCESS/PARTIAL/FAILED), run_id, market_data_asof, usdkrw, errors[], cooldown/in_progress 정보
- 검증:
  - Authorization Bearer JWT 필수
  - 서버는 사용자별 쿨다운(권장 60초) + 진행중 가드
- 예외:
  - cooldown: `skipped=true`, `wait_ms` 반환 → UI에서 남은 시간 표시
  - in_progress: `skipped=true`, `since_ms` 반환(또는 202) → “다른 기기에서 진행중” 표시
  - PARTIAL: errors 요약 표시 + 상세는 접기

### 3.3 SI-02 동기화 상태 표시(멀티 디바이스) [P0]
- 목적: PC에서 동기화 후 모바일에서 바로 확인 가능해야 한다.
- 구현:
  - `market_data_sync_runs` 최신 1건을 읽어
    - 마지막 완료시각, status, mode, market, errorCount를 표시
- UX:
  - 홈 상단에 “마지막 동기화: 3분 전 (SUCCESS)” 배지
  - status=STARTED면 “진행중” 배지

### 3.4 TS-09 Rebuild 요청/상태 [P0]
- 목적: 과거 데이터 누락/오염을 사용자 동작으로 복구 요청 가능.
- 입력:
  - from/to(Date), reason(문자열)
- 출력:
  - 요청 적재 성공/실패, 큐 카운트
- 검증:
  - to >= from
  - 최대 기간 제한: **31일(하드 리밋)**
- 예외:
  - 오늘/미래 날짜: 서버가 자동 무시(과거만 큐 적재)
  - UI에서는 '오늘 이전'만 선택 가능하도록 가드 권장
- 너무 큰 범위: “기간을 줄여달라” 안내
  - 큐에 이미 존재: 중복 요청 안내(멱등)

### 3.5 TS-10 Rebuild Worker(서버 실행) [P0]
- 목적: 큐를 자동 처리하여 self-healing을 완성한다.
- 트리거:
  - Cron(15분) + 수동 운영 실행(선택)
- 출력:
  - 처리 유저 수/구간/성공실패 요약
- 예외:
  - Service Role 누락: 즉시 실패(운영 설정 문제)

### 3.6 CF-01 거래 생성(멱등) [P0]
- 입력:
  - type, amount, currency, date, (account/card/stock 등 타입별 필수값), client_tx_id
- 검증:
  - 타입별 필수 필드 체크(클라이언트 + 서버)
  - 잔액 음수/초과매도 등은 서버가 거부 → 사용자 메시지 변환
- 예외:
  - 네트워크 재시도는 **동일 client_tx_id**로 재시도
  - 저장 성공 후 리스트/대시보드 재조회

### 3.7 CF-02 거래 수정(정정 체인) [P0]
- 정책:
  - UPDATE가 아닌 “VOID + CORRECTION + 신규” 패턴
- UX:
  - 수정 전/후 비교 표시(선택)
  - 감사 로그(CF-05)에서 정정 체인 확인 가능

### 3.8 CF-03 거래 취소 [P0]
- 입력: transaction_id, reason
- 결과: reverse 거래 생성
- 예외: 이미 취소된 거래는 idempotent 처리(“이미 취소됨”)

### 3.9 TS-01 타임 머신 [P0]
- 규칙:
  - selectedDate < today(KST) → daily 테이블 기반
  - today → 최신 뷰/현재값 기반
- UX:
  - 화면 상단에 “과거(YYYY-MM-DD)” 배지 + 오늘로 돌아가기

### 3.10 SI-08 앱 버전 체크(최소버전) [P0]
- 목적: DB/Edge가 업데이트되어도 구버전 앱이 잘못된 호출을 하지 않게 차단.
- 구현:
  - 앱 시작 시 1회 “내 앱 버전”을 서버에 전송하여 최소버전 미만이면 차단/업데이트 유도.

---

### 4. UI/디자인 가이드(Blazor Hybrid 기준)
- 기본 목표: **대시보드/차트가 ‘한눈에’** 들어오게.
- 레이아웃:
  - 모바일 1열, PC 2~3열 반응형(Grid)
- 컴포넌트:
  - KPI 카드(숫자 크게), 상태 배지(색상/아이콘)
  - 차트: NAV Line + 월 히트맵 + 리스크 카드(MDD)
- 디자인 시스템(권장):
  - MudBlazor(생산성) 또는 Bootstrap(단순) 중 1개로 통일
- 상태 UX:
  - 동기화: 진행중/쿨다운/성공/부분/실패를 모두 구분 표기(서버 run log 기반)

---

### 5. 구현 체크리스트(P0)
- [ ] 홈: get_dashboard 1회 호출 + 캐시 + 새로고침
- [ ] 동기화: sync_me + market_data_sync_runs 최신 표시
- [ ] 거래: 생성/수정/취소를 RPC로만
- [ ] 타임머신: daily 우선 규칙 + 과거 배지
- [ ] 정합성 센터: daily_snapshot_recalc_queue 표시 + 재계산 요청
- [ ] Rebuild 상태: snapshot_recalc_runs(있다면) 표시
- [ ] 최소버전 체크: 앱 시작 시 1회

---
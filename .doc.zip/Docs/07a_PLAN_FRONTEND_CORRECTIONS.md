# 07a. Frontend Plan — Corrections & Additions

> **This document overrides 07_PLAN_FRONTEND.md where conflicts exist.**
> AI agents: read BOTH files. This file takes precedence.
> Last updated: 2026-02-08

---

## 1. Architecture Corrections

### 1.1 Project Structure (ACTUAL vs 07_PLAN)

**07_PLAN proposed** (OUTDATED — DO NOT USE):
```
Pad.App/ Pad.Presentation/ Pad.Domain/ Pad.Infrastructure/
```

**Actual project structure** (USE THIS):
```
BudgetBook/                         ← Single .NET MAUI Blazor Hybrid project
├── Components/
│   ├── Layout/
│   │   ├── MainLayout.razor        ← Main layout with sidebar + header
│   │   ├── MainLayout.razor.css
│   │   ├── EmptyLayout.razor       ← For login/standalone pages
│   │   └── SyncBadge.razor         ← Sync status indicator in header
│   ├── Pages/
│   │   ├── Login.razor
│   │   ├── Home.razor              ← Root "/" redirect
│   │   ├── Dashboard.razor         ← /dashboard
│   │   ├── Transactions.razor      ← /transactions (list)
│   │   ├── TransactionEntry.razor  ← /transactions/new, /transactions/edit/{id}
│   │   ├── Portfolio.razor         ← /portfolio
│   │   ├── Accounts.razor          ← /accounts
│   │   ├── Categories.razor        ← /categories
│   │   ├── Reports.razor           ← /reports
│   │   ├── Calendar.razor          ← /calendar
│   │   ├── Sync.razor              ← /sync (manual sync + history)
│   │   ├── Settings.razor          ← /settings
│   │   ├── UpdateRequired.razor    ← /update-required
│   │   └── NotFound.razor
│   ├── Shared/
│   │   ├── DashboardStatsCard.razor
│   │   ├── RecentTransactionsTable.razor
│   │   ├── TransactionTypeSelector.razor
│   │   ├── AccountPicker.razor
│   │   ├── ErrorToast.razor
│   │   ├── ConfirmDialog.razor
│   │   └── SkeletonLoader.razor
│   ├── Models/
│   │   ├── DashboardModels.cs      ← DashboardDto, StatsDto, ReturnsSummaryDto, TransactionDisplayDto
│   │   ├── SupabaseViewModels.cs   ← MarketDataSyncRunDto, PortfolioNavDailyDto, AccountStockNavDailyDto, PortfolioMetricsDto, PortfolioReturnsMonthlyDto
│   │   ├── TransactionRequestDto.cs ← ProcessTransactionRequest, EditTransactionRequest
│   │   ├── AppVersionDto.cs
│   │   └── CommonModels.cs         ← AccountDto, CategoryDto, CardDto, StockDto (Supabase BaseModel)
│   └── _Imports.razor
├── Models/
│   └── CommonModels.cs             ← Same as above (alias path)
├── Services/
│   ├── ApiService.cs               ← All Supabase RPC/PostgREST calls
│   ├── AuthService.cs              ← Supabase Auth (login, logout, session)
│   ├── EdgeService.cs              ← Edge Function HTTP calls
│   ├── SupabaseService.cs          ← Supabase client initialization
│   ├── AppConfig.cs / IAppConfig   ← Environment config (URL, keys)
│   ├── EnvLoader.cs                ← .env file loader
│   ├── EnvDecryptor.cs             ← Encrypted env support
│   └── TimeHelper.cs               ← KST timezone helper
├── wwwroot/
│   └── css/
│       └── app.css                 ← Design system (see 08_DESIGN_SYSTEM.md)
└── MauiProgram.cs                  ← DI registration
```

### 1.2 Component Library Correction

**07_PLAN says**: "MudBlazor or Bootstrap"
**Actual**: **Radzen.Blazor** (Material theme). See `08_DESIGN_SYSTEM.md` for all component usage.

### 1.3 RPC Name Corrections

**07_PLAN references** (WRONG):
- `create_cash_transaction()`, `create_transfer()`, `create_card_purchase()`, `create_stock_trade()` ← **DO NOT EXIST**

**Actual RPCs** (USE THESE):
| RPC | Purpose | Input DTO |
|---|---|---|
| `process_transaction_v2(...)` | Create ANY transaction type | `ProcessTransactionRequest` |
| `edit_transaction_v2(...)` | Edit existing transaction (VOID+re-create) | `EditTransactionRequest` |
| `reverse_transaction(...)` | Cancel/void a transaction | `(p_transaction_id, p_reason)` |
| `get_dashboard(...)` | Dashboard aggregate data | `(p_limit, p_include_nav)` |
| `get_returns_summary()` | Portfolio TWR returns | (none) |
| `get_current_app_version()` | App version check | (none) |

### 1.4 DI Registration (MauiProgram.cs)

```csharp
builder.Services.AddSingleton<IAppConfig, AppConfig>();
builder.Services.AddSingleton<SupabaseService>();
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<ApiService>();
builder.Services.AddScoped<EdgeService>();
```

**Note**: EdgeService uses `new HttpClient()` internally — do NOT try to inject `IHttpClientFactory`.

---

## 2. Navigation Map (Actual Routes)

```
/                     → Home.razor (redirects to /dashboard or /login)
/login                → Login.razor (EmptyLayout)
/dashboard            → Dashboard.razor
/transactions         → Transactions.razor (list, filter, search)
/transactions/new     → TransactionEntry.razor (create)
/transactions/edit/{id} → TransactionEntry.razor (edit mode)
/portfolio            → Portfolio.razor (holdings, stock NAV)
/accounts             → Accounts.razor
/categories           → Categories.razor
/reports              → Reports.razor (spending, NAV, returns charts)
/calendar             → Calendar.razor (date-picker + daily transactions)
/sync                 → Sync.razor (manual sync + run history)
/settings             → Settings.razor
/update-required      → UpdateRequired.razor
```

### Sidebar Menu Structure (MainLayout.razor)

**Main Navigation:**
1. Dashboard (`/dashboard`, icon: `dashboard`)
2. Transactions (`/transactions`, icon: `reorder`)
3. Portfolio (`/portfolio`, icon: `account_balance`)
4. Calendar (`/calendar`, icon: `calendar_today`)
5. Accounts (`/accounts`, icon: `account_balance_wallet`)
6. Categories (`/categories`, icon: `category`)
7. Reports (`/reports`, icon: `bar_chart`)

**Operations:**
8. Manual Sync (`/sync`, icon: `sync`)
9. Settings (`/settings`, icon: `settings`)

---

## 3. Page-by-Page API Mapping (Actual Implementation)

### 3.1 Dashboard (`/dashboard`)

| API Call | Method | Purpose |
|---|---|---|
| `ApiService.GetDashboardAsync(10, true)` | RPC `get_dashboard` | Stats, recent transactions, sync/kis/nav info |
| `ApiService.GetReturnsSummaryAsync()` | RPC `get_returns_summary` | TWR returns display |
| `EdgeService.SyncMeAsync(market)` | Edge `pad-market-sync?op=sync_me` | Manual market sync trigger |

**Components used**: `DashboardStatsCard`, `RecentTransactionsTable`, `SyncBadge`

### 3.2 Transactions (`/transactions`)

| API Call | Method | Purpose |
|---|---|---|
| `ApiService.GetTransactionsAsync(from, to, keyword, offset, limit)` | PostgREST `v_transactions_display` | Paginated list with filter |

### 3.3 TransactionEntry (`/transactions/new`, `/transactions/edit/{id}`)

| API Call | Method | Purpose |
|---|---|---|
| `ApiService.GetAccountsAsync()` | PostgREST `accounts` | Account dropdown |
| `ApiService.GetCategoriesAsync(kind)` | PostgREST `categories` | Category dropdown |
| `ApiService.GetCardsAsync()` | PostgREST `cards` | Card dropdown |
| `ApiService.GetStocksAsync()` | PostgREST `stocks` | Stock dropdown |
| `ApiService.ProcessTransactionAsync(request)` | RPC `process_transaction_v2` | Create |
| `ApiService.EditTransactionAsync(request)` | RPC `edit_transaction_v2` | Edit |
| `ApiService.ReverseTransactionAsync(id, reason)` | RPC `reverse_transaction` | Void/cancel |
| `ApiService.GetTransactionAsync(id)` | PostgREST `v_transactions_display` | Load for edit |

### 3.4 Portfolio (`/portfolio`)

| API Call | Method | Purpose |
|---|---|---|
| `ApiService.GetAccountStockNavAsync(date)` | PostgREST `v_account_stock_nav_daily` | Stock holdings + valuation |
| `EdgeService.EnsureStockAsync(ticker, market)` | Edge `pad-market-sync?op=ensure_stock` | Add new stock |

### 3.5 Reports (`/reports`)

| API Call | Method | Purpose |
|---|---|---|
| `ApiService.GetPortfolioNavAsync(from, to)` | PostgREST `v_portfolio_nav_daily` | NAV trend line |
| `ApiService.GetMonthlySpendingAsync(months)` | Client-side aggregation | Spending bar chart |
| `ApiService.GetPortfolioReturnsMonthlyAsync(months)` | PostgREST `portfolio_returns_monthly` | Returns chart |

### 3.6 Calendar (`/calendar`)

| API Call | Method | Purpose |
|---|---|---|
| `ApiService.GetTransactionsAsync(date, date+1day)` | PostgREST `v_transactions_display` | Day's transactions |

### 3.7 Categories (`/categories`)

| API Call | Method | Purpose |
|---|---|---|
| `ApiService.GetCategoriesAsync()` | PostgREST `categories` | Full category list |

### 3.8 Sync (`/sync`)

| API Call | Method | Purpose |
|---|---|---|
| `EdgeService.SyncMeAsync(market)` | Edge `pad-market-sync?op=sync_me` | Trigger sync |
| `ApiService.GetSyncRunsAsync(offset, limit)` | PostgREST `market_data_sync_runs` | Sync history |

---

## 4. Missing Page Specifications

### 4.1 Reports Page (`/reports`)

**Purpose**: Multi-tab analytics dashboard showing spending, asset trends, and performance.

**Layout**: 3-tab RadzenTabs

**Tab 1: 소비 (Spending)**
- RadzenChart with RadzenColumnSeries
- X-axis: month (yy-MM), Y-axis: total expense (KRW, formatted N0)
- Data: Last 6 months of expenses grouped by month (client-side from GetTransactionsAsync)
- Empty state: "소비 데이터가 없습니다."

**Tab 2: 자산 (Assets)**
- RadzenChart with RadzenLineSeries
- X-axis: date (MM-dd), Y-axis: NAV KRW
- Data: Last 60 days from `v_portfolio_nav_daily`
- Empty state: "자산 추이 데이터가 없습니다."

**Tab 3: 성과 (Performance)**
- RadzenChart with RadzenLineSeries
- X-axis: month (yy-MM), Y-axis: return % (format F2%)
- Data: Last 6 months from `portfolio_returns_monthly`
- Empty state: "수익률 데이터가 없습니다."

**Future enhancements** (not yet implemented):
- [ ] Category-breakdown pie chart in 소비 tab
- [ ] Account filter dropdown
- [ ] Date range picker
- [ ] MDD/win rate display in 성과 tab (data available via `GetLatestPortfolioMetricsAsync`)

### 4.2 Calendar Page (`/calendar`)

**Purpose**: Date-centric transaction view with inline calendar picker.

**Layout**: 2-column responsive (5:7 ratio on desktop, stacked on mobile)

**Left column**: `<RadzenDatePicker Inline="true" />`
- Selecting a date triggers `LoadAsync()` for that day

**Right column**: RadzenCard with:
- Header: selected date (yyyy-MM-dd) + daily summary (지출 total / 수입 total)
- Content: `<RadzenDataGrid>` with columns:
  - 시간 (HH:mm), 설명 (category/merchant/memo), 금액, 통화, 계좌, 상태
  - Status column shows VOID badge (red) or EDIT badge (yellow)
- Row click: navigates to `/transactions/edit/{id}`
- Row render: voided rows get `opacity: 0.45; text-decoration: line-through`, correction rows get left yellow border
- Empty state: "해당 날짜의 거래가 없습니다"

**Data flow**: `GetTransactionsAsync(date, date+1day, null, 0, 200)`

**Future enhancements**:
- [ ] Calendar day badges showing daily expense total
- [ ] Month summary card below calendar
- [ ] Swipe gesture for day navigation on mobile

### 4.3 Portfolio Page (`/portfolio`)

**Purpose**: Stock holdings overview with valuation.

**Layout**: Summary card + Holdings DataGrid

**Summary Card** (RadzenCard, top):
- 총 주식 평가액: sum of all ValueKrw
- 평가손익: PnlPct (currently null — needs snapshot comparison)
- 보유 종목 수: count of holdings

**Holdings Grid** (RadzenDataGrid):
- Columns: 티커, 시장, 수량, 시장가, 평가액(KRW), 손익%
- AllowSorting, AllowPaging (PageSize=20)
- "종목 추가" button → calls `EdgeService.EnsureStockAsync` (currently shows placeholder toast)

**Data flow**: `GetAccountStockNavAsync(today)` → maps to HoldingItem record

**Known gaps**:
- PnlPct is always null (needs avg cost from holdings table vs current price)
- "종목 추가" dialog not yet implemented
- No account-level breakdown (all accounts merged)

**Future enhancements**:
- [ ] PnL calculation: integrate holdings.avg_buy_price vs stock_prices
- [ ] Account filter for multi-account portfolios
- [ ] Pie chart showing allocation by stock
- [ ] Link to transaction history for each stock

---

## 5. Transaction Type → Required Fields Matrix

**CRITICAL for TransactionEntry form logic.** Show/require fields based on selected type:

| Type | account_id | to_account_id | card_id | stock_id | qty | fx_rate | category | merchant |
|---|---|---|---|---|---|---|---|---|
| 지출 | Required* | — | Optional | — | — | — | **Required** | Optional |
| 수입 | Required | — | — | — | — | — | **Required** | Optional |
| 이체 | Required | **Required** | — | — | — | — | Optional | — |
| 환전_매수 | Required | — | — | — | **Required** | **Required** | Optional | — |
| 환전_매도 | Required | — | — | — | **Required** | **Required** | Optional | — |
| 주식_매수 | Required | — | — | **Required** | **Required** | — | Optional | — |
| 주식_매도 | Required | — | — | **Required** | **Required** | — | Optional | — |
| 수수료 | Optional* | — | Optional* | — | — | — | Optional | — |
| 세금 | Optional* | — | Optional* | — | — | — | Optional | — |
| 배당 | Required | — | — | **Required** | — | — | Optional | — |
| 카드_대금 | **Required** | — | **Required** | — | — | — | Optional | — |

\* 지출: if card_id is set, account_id must be null (card-based expense). Otherwise account_id required.
\* 수수료/세금: at least one of account_id or card_id required.

---

## 6. Common Code Patterns

### 6.1 Page Lifecycle (every data page follows this)

```csharp
@implements IDisposable

@code {
    private bool _isLoading;
    private string? _error;
    private CancellationTokenSource? _cts;
    private bool _disposed;
    private ErrorToast _errorToast = default!;

    protected override async Task OnInitializedAsync()
    {
        await LoadAsync();
    }

    private async Task LoadAsync()
    {
        _cts?.Cancel();
        _cts?.Dispose();
        _cts = new CancellationTokenSource();
        _isLoading = true;
        _error = null;

        try
        {
            // API calls here with _cts.Token
        }
        catch (OperationCanceledException) { }
        catch (Exception ex)
        {
            _error = $"메시지: {ex.Message}";
            if (!_disposed) await _errorToast.ShowAsync(_error);
        }
        finally
        {
            _isLoading = false;
        }
    }

    public void Dispose()
    {
        _disposed = true;
        _cts?.Cancel();
        _cts?.Dispose();
    }
}
```

### 6.2 ApiService Pattern (Supabase PostgREST)

```csharp
// Table/View query
var response = await _supabaseService.Client
    .From<SomeDto>()
    .Filter("column", Operator.Equals, value)
    .Order("column", Ordering.Descending)
    .Range(offset, offset + limit - 1)
    .Get(cancellationToken);
return response.Models;

// RPC call
var result = await _supabaseService.Client.Rpc<ReturnType>("rpc_name", parameters);
```

### 6.3 Error Display

```html
@if (_error != null)
{
    <RadzenAlert Severity="AlertSeverity.Error" AllowClose="true">
        @_error
        <RadzenButton Text="다시 시도" Icon="refresh" ButtonStyle="ButtonStyle.Light"
                      Size="ButtonSize.Small" Click="@LoadAsync" />
    </RadzenAlert>
}
```

---

## 7. Implementation Priority (Updated)

Based on current project state:

### Already Implemented (functional)
- [x] Login / Auth flow
- [x] Dashboard (stats + recent transactions + returns)
- [x] Transactions list (filter, pagination, search)
- [x] TransactionEntry (create + edit + void)
- [x] Portfolio (holdings view)
- [x] Categories (list + detail)
- [x] Calendar (date picker + daily transactions)
- [x] Reports (spending/NAV/returns charts)
- [x] Sync (manual trigger + run history)
- [x] Settings (profile + logout)
- [x] App version check

### Needs Completion / Bug Fixes
- [ ] Dashboard sync error handling (current TODO)
- [ ] Categories click crash (current TODO)
- [ ] Sidebar hover flash CSS fix (current TODO)
- [ ] Profile layout alignment (current TODO)
- [ ] DTO audit against PAD_DTOs.md (current TODO)
- [ ] Portfolio PnL calculation (avg cost integration)
- [ ] Portfolio "종목 추가" dialog
- [ ] Reports: category breakdown, date range picker, MDD/win rate display
- [ ] Calendar: day badges, month summary
- [ ] Accounts page: full CRUD for accounts
- [ ] Fixed expenses management page (DB tables exist, no UI yet)

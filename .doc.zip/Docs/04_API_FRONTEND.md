## 프론트엔드 API 명세
- 원본: `PAD_v2.3.5_API_SPEC_FOR_FRONTEND_2026-01-30.FINAL.md`

## PAD v2.3.5 — 프론트엔드 API 명세서 (기능별 매핑)

- 기준 스키마/문서: PAD v2.3.5 (Release 2026-01-30)
- 작성일: 2026-01-30 (Asia/Seoul (KST))

---

### 0. 공통 규칙

#### 0.1 Base URL / 경로
- REST(PostgREST): `POST/GET/PATCH/DELETE {SUPABASE_URL}/rest/v1/<table_or_view>`
- RPC(Postgres Function): `POST {SUPABASE_URL}/rest/v1/rpc/<function_name>`
- Edge Function: `POST {SUPABASE_URL}/functions/v1/<function_name>?...`

#### 0.2 공통 헤더
- `apikey: <SUPABASE_ANON_KEY>`
- `Authorization: Bearer <access_token>` (사용자 호출 전부)
- `Content-Type: application/json`
- 서버/크론 전용: `x-cron-secret: <CRON_SECRET>` (클라이언트 절대 포함 금지)

#### 0.3 타입/코드

- `transaction_type`: `지출`, `수입`, `이체`, `주식_매수`, `주식_매도`, `배당금`, `수수료`, `세금`, `환전_매수`, `환전_매도`, `대출_실행`, `대출_상환_원금`, `대출_상환_이자`, `교정`, `카드_대금`

- `currency_code`: `KRW`, `USD`

- `stock_market`: `KR`, `US`

- `account_type`: `Cash`, `Bank`, `Securities`, `Etc`

- 시간대: DB 내부는 `timestamptz(UTC)` 저장, UI 표시는 KST 변환을 원칙으로 합니다.


#### 0.4 에러 처리(프론트 기준)
- PostgREST/RPC: 4xx는 입력/권한 문제, 5xx는 서버/함수 오류로 분류
- RPC는 `raise exception` 메시지가 그대로 내려옵니다. 메시지 기반으로 사용자 안내/재시도 여부를 결정하세요.
- Edge: `{ ok:false, error, detail? }` 형태가 있을 수 있으며 HTTP 200이어도 실패가 있을 수 있으니 `ok`를 우선 확인합니다.

---

### 1. 기능 목록(요약) — 구현 시 반드시 매핑

### 2. 기능 목록(요약)
표의 “Supabase 연동”은 구현 시 반드시 매핑해야 하는 객체(테이블/뷰/RPC/Edge/Cron)입니다.  
우선순위: **P0(필수) / P1(권장) / P2(선택)**

#### 2.1 IA: 투자/자산 (Investment & Assets)
|    ID | 기능명                 | 설명                                    | 우선순위 | Supabase 연동                                                    |
| ----: | ---------------------- | --------------------------------------- | :------: | ---------------------------------------------------------------- |
| IA-01 | 통합 대시보드(요약)    | 순자산/NAV/현금/주식/부채 + 동기화 상태 |    P0    | RPC `get_dashboard()`                                            |
| IA-02 | NAV 일별 차트          | 일별 총자산 추이(기간 필터)             |    P0    | View/테이블 `v_portfolio_nav_daily`/`portfolio_nav_daily`        |
| IA-03 | 계좌별 NAV             | 계좌별 현금/주식/외화 평가액            |    P0    | `account_nav_daily`, `v_account_nav_daily`                       |
| IA-04 | 종목별 평가(계좌-종목) | 보유수량/평가액/통화/가격               |    P0    | `account_stock_nav_daily`, `v_account_stock_nav_daily`           |
| IA-05 | 자산 비중(자산군/통화) | 파이/도넛 차트 구성                     |    P1    | 조합(`account_nav_daily`, `account_stock_nav_daily`, `accounts`) |
| IA-06 | 실현손익 리포트        | 매도 확정 손익 집계/필터                |    P0    | `stock_realized_pnl`                                             |
| IA-07 | 배당금 리포트          | 월/종목별 배당 수령                     |    P1    | 거래 타입(배당) + 뷰/집계                                        |
| IA-08 | 미실현손익             | 현재가-평단 기반 평가손익               |    P1    | `holdings`, `stock_prices`, `fx_rates`                           |
| IA-09 | 종목 평단/손익분기     | 평단 변화/추가매수 영향                 |    P2    | 조합(`holdings`, 거래)                                           |
| IA-10 | 권리 이벤트 조회       | 액면분할/합병 등 타임라인               |    P1    | `stock_corporate_actions`                                        |
| IA-11 | 권리 이벤트 적용(관리) | 액면분할 적용 실행                      |    P2    | RPC `apply_stock_split()`                                        |
| IA-12 | 외화 지갑              | 환전 평균환율/잔고                      |    P1    | `currency_wallet`                                                |
| IA-13 | 기여도 랭킹            | NAV 변동 기여 TOP/N                     |    P2    | 조합(일별 NAV, 종목 NAV)                                         |
| IA-14 | What-if 시뮬           | 환율/주가 충격 테스트                   |    P2    | 클라이언트 계산 + 최신 NAV                                       |

#### 2.2 TS: 시계열/성과 (Time-series & Performance)
|    ID | 기능명               | 설명                                 | 우선순위 | Supabase 연동                                                                        |
| ----: | -------------------- | ------------------------------------ | :------: | ------------------------------------------------------------------------------------ |
| TS-01 | 타임 머신(날짜 조회) | 과거 날짜 기준 자산 상태 복원        |    P0    | `*_daily` 테이블/뷰                                                                  |
| TS-02 | 월별 수익률 히트맵   | 월 수익률/승률 표시                  |    P0    | `portfolio_returns_monthly`(+ 재계산 RPC)                                            |
| TS-03 | 리스크 지표 카드     | MDD/변동성 등                        |    P0    | `portfolio_metrics`/`v_portfolio_metrics`                                            |
| TS-04 | 지표 재계산(서버)    | Cron/Worker가 수행(프론트 호출 금지) |    P1    | (server-only) RPC `update_portfolio_metrics()`                                       |
| TS-05 | 롤링 수익률          | 7/30/90일 등                         |    P2    | `v_portfolio_nav_daily`                                                              |
| TS-06 | MDD 구간 하이라이트  | 고점-저점 구간 표시                  |    P2    | `v_portfolio_nav_daily`                                                              |
| TS-07 | 환율 민감도          | USD 노출 변동 영향                   |    P2    | `fx_rates_daily`, `account_nav_daily`                                                |
| TS-08 | 해외수익 분해        | 주가 vs 환율 분리                    |    P2    | `stock_prices_daily`, `fx_rates_daily`, `account_stock_nav_daily`                    |
| TS-09 | Rebuild 요청/상태    | 누락/오염 구간 재계산 요청/조회      |    P0    | RPC `request_snapshot_recalc`, `daily_snapshot_recalc_queue`, `snapshot_recalc_runs` |
| TS-10 | Rebuild 실행(서버)   | 큐 소비 + 구간 재계산 Worker         |    P0    | Edge `pad-recalc-worker?op=run` + Cron                                               |

#### 2.3 CF: 소비/현금흐름 (Cash Flow)
|    ID | 기능명                   | 설명                        | 우선순위 | Supabase 연동                                          |
| ----: | ------------------------ | --------------------------- | :------: | ------------------------------------------------------ |
| CF-01 | 거래 생성(멱등)          | 지출/수입/이체/주식/환전 등 |    P0    | RPC `process_transaction_v2`                           |
| CF-02 | 거래 수정(정정)          | VOID+CORRECTION 체인        |    P0    | RPC `edit_transaction_v2`                              |
| CF-03 | 거래 취소                | 역거래/무효화               |    P0    | RPC `reverse_transaction`                              |
| CF-04 | 거래 리스트(표시)        | VOID/CORRECTION 제외 기본   |    P0    | View `v_transactions_display`                          |
| CF-05 | 거래 감사 로그           | 정정/무효화 포함            |    P1    | View `v_transactions_with_info`                        |
| CF-06 | 카테고리 지출 분석       | 기간/카테고리별             |    P1    | `transactions`, `categories`(+ 뷰/집계)                |
| CF-07 | 카드 사이클 사용액(현재) | 청구기간 누적               |    P1    | `v_card_cycle_spend_current`                           |
| CF-08 | 카드 납부액(월별)        | 카드별/월별 납부            |    P1    | `v_card_payments_monthly`                              |
| CF-09 | 카드 사용(12개월)        | 최근 12 사이클              |    P2    | `v_card_cycle_spend_recent_12`                         |
| CF-10 | 카드 사용 스냅샷         | 일별 카드 사용량 저장       |    P1    | RPC `capture_card_usage_snapshot` + `card_usage_daily` |
| CF-11 | 고정지출 관리            | 구독/정기결제               |    P1    | `fixed_expenses`(+ 뷰)                                 |
| CF-12 | 계획 vs 실제             | 고정지출 대비 실제          |    P2    | 조합(고정지출 + 거래)                                  |
| CF-13 | 부채 현황                | 대출 잔액/금리/메모         |    P1    | `liabilities`                                          |
| CF-14 | 상환 로드맵              | 원금/이자 흐름              |    P2    | 조합(부채 + 거래)                                      |

#### 2.4 SI: 시스템/정합성 (System & Integrity)
|    ID | 기능명                 | 설명                                        | 우선순위 | Supabase 연동                                |
| ----: | ---------------------- | ------------------------------------------- | :------: | -------------------------------------------- |
| SI-01 | 정합성 센터(큐)        | 재계산 필요 날짜/사유                       |    P0    | `daily_snapshot_recalc_queue`                |
| SI-02 | 동기화 상태 표시       | 최근 동기화 시각/상태(멀티디바이스)         |    P0    | `market_data_sync_runs`                      |
| SI-03 | 수동 동기화(사용자)    | 사용자 요청 → 서버 실행 → 결과 반환         |    P0    | Edge `pad-market-sync?op=sync_me`            |
| SI-04 | 종목 등록/보강         | ticker 입력 시 메타/가격 저장               |    P0    | Edge `pad-market-sync?op=ensure_stock`       |
| SI-05 | 일일 마감(Daily Close) | 장마감 종가/환율/스냅샷 고정                |    P0    | Edge `pad-market-sync?op=daily_close` + Cron |
| SI-06 | 배치 동기화(서버)      | 전체 사용자 주기 동기화                     |    P1    | Edge `pad-market-sync?op=sync` + Cron        |
| SI-07 | 스냅샷 캡처(서버)      | NAV/계좌/카드 스냅샷 저장(프론트 호출 금지) |    P2    | (server-only) RPC `capture_*`                |
| SI-08 | 앱 버전 체크           | 최소버전/권장버전 안내                      |    P0    | `app_versions`/버전 RPC                      |

---

---

### 2. 화면(UX) 단위 권장 호출 플로우

#### 2.1 앱 시작(Startup)
1) (P0) 앱 버전 체크: RPC `get_current_app_version()`
2) (P0) 대시보드 프리로드: RPC `get_dashboard()`
3) (옵션) 동기화 상태 배지: `market_data_sync_runs` 최근 1건 조회

#### 2.2 대시보드 화면
- 핵심: RPC `get_dashboard()` 한 번으로 **요약 카드 + 최근 거래 + 동기화 상태 + 지표**를 받습니다.
- 차트(일별 NAV): View `v_portfolio_nav_daily` (기간 필터)

#### 2.3 거래(가계부) 화면
1) 목록: View `v_transactions_display` (기본: VOID/CORRECTION 제외)
2) 생성: RPC `process_transaction_v2` (**멱등키 `p_client_tx_id`는 프론트에서 항상 넣기(사실상 필수)**)
3) 수정: RPC `edit_transaction_v2`
4) 취소: RPC `reverse_transaction`
5) 과거 날짜 영향(시간축): 필요 시 `daily_snapshot_recalc_queue` 확인/표시 + `request_snapshot_recalc` 요청

#### 2.4 투자/포트폴리오 화면
- 계좌별 NAV: View `v_account_nav_daily`
- 종목별 평가(계좌-종목): View `v_account_stock_nav_daily`
- 실현손익: Table `stock_realized_pnl`
- 종목 등록(티커 입력 시): Edge `pad-market-sync?op=ensure_stock`

#### 2.5 성과/리스크 화면
- 월별 수익률: `portfolio_returns_monthly`
- MDD/승률 등: View `v_portfolio_metrics`
- (관리) 지표 재계산: RPC `update_portfolio_metrics` (운영 정책에 따라 UI에서 숨김 가능)

#### 2.6 카드 화면
- 현재 사이클 사용액: View `v_card_cycle_spend_current`
- 월별 납부액: View `v_card_payments_monthly`
- 최근 12 사이클: View `v_card_cycle_spend_recent_12`

#### 2.7 설정/마스터 데이터 화면
- 계좌/카드/카테고리/고정지출/부채는 기본적으로 테이블 CRUD(PostgREST)를 사용합니다.
- 단, `transactions`, `account_balances`, `holdings`, `stats`는 **직접 DML 금지**(RPC/서버만).

---

### 3. API 레퍼런스 (기능별 호출 대상)

#### 3.1 RPC 목록 (DB Function)

> 경로: `POST /rest/v1/rpc/<function>`


##### (IA-01) get_dashboard

- 시그니처: `public.get_dashboard(p_limit int default 10, p_include_nav boolean default true) RETURNS jsonb`

- 목적: 대시보드에 필요한 **요약 카드 + 최근 거래 + 동기화 상태 + KIS 토큰 상태 + NAV(최근 2일 비교)**를 1회 호출로 제공
- 요청 Body 예시:
  - `{ "p_limit": 20, "p_include_nav": true }`

- 응답: JSONB (핵심 필드)
  - `stats`: `public.stats` 1행 (없을 수 있음)
  - `recent`: `v_transactions_display` 최근 N건
  - `sync`: 사용자 기준 최근 `market_data_sync_runs` 1건 (없을 수 있음)
  - `kis`: `get_kis_token_status()` 결과

> 참고: `kis`는 `get_dashboard`에 포함되므로, `get_kis_token_status()`를 별도로 호출하는 것은 **설정/진단 화면에서만** 권장합니다.
  - `nav`: 최근 2영업일 NAV 비교(없을 수 있음)
  - `generated_at`: 서버 생성 시각

```json
{
  "user_id": "uuid",
  "stats": { /* stats row or null */ },
  "recent": [ /* recent tx rows */ ],
  "sync": { /* latest run or null */ },
  "kis": { "has_token": true, "expires_at": "..." },
  "nav": {
    "latest_date": "2026-01-30",
    "latest_nav_krw": 123456.78,
    "prev_nav_krw": 120000.00,
    "delta_nav_krw": 3456.78
  },
  "generated_at": "2026-01-30T00:00:00Z"
}
```

> **주의:** NAV 라인 시계열/리스크 지표는 `get_dashboard`에 포함되지 않습니다.  
> - NAV 라인: `GET /rest/v1/v_portfolio_nav_daily?select=...&order=trading_date.desc&limit=...`  
> - 리스크 지표: `GET /rest/v1/v_portfolio_metrics?select=*`

##### (TS-??) get_returns_summary (순자산 증감률 + 투자성과 TWR 요약)

- 시그니처: `public.get_returns_summary() RETURNS table (...)`

- 목적:
  - **순자산 증감률(NAV 기반)**: `networth_*`
  - **입출금 제외 투자성과(TWR)**: `twr_*`
  - 프론트에서 **일간/월간/연간/누적** 성과를 1회 호출로 조회

- 요청:
  - Body: `{}` (또는 생략)

- 응답(단일 row):
  - `asof` (date)
  - `networth_krw` (numeric)
  - `networth_daily_pct`, `networth_mtd_pct`, `networth_ytd_pct`, `networth_cum_pct` (numeric, %)
  - `assets_krw` (numeric) — 투자자산(현금+외화환산+주식평가)
  - `external_flow_today_krw` (numeric) — 오늘 외부현금흐름(입금+ / 출금-)
  - `twr_daily_pct`, `twr_mtd_pct`, `twr_ytd_pct`, `twr_cum_pct` (numeric, %)

- UI 표기 권장:
  - “누적 수익률”은 2개로 분리:
    - `누적 순자산 증감률` = `networth_cum_pct`
    - `누적 투자성과(TWR)` = `twr_cum_pct`
  - 초기 데이터 부족(전일/기준일 없음) 시 % 값이 `null`인 것은 정상 → UI는 `N/A` 처리 권장


##### (CF-01) process_transaction_v2 (거래 생성, 멱등)

- 시그니처: `public.process_transaction_v2(p_date timestamptz, p_type transaction_type, p_amount numeric, p_currency currency_code, p_account_id uuid default null, p_to_account_id uuid default null, p_card_id uuid default null, p_stock_id uuid default null, p_qty numeric default null, p_fx_rate numeric default null, p_liability_id uuid default null, p_category text default null, p_memo text default null, p_is_correction boolean default false, p_linked_transaction_id uuid default null, -- v1.3.2: category FK + merchant p_category_id uuid default null, p_merchant text default null, -- v1.3.2+: idempotency p_client_tx_id uuid default null) RETURNS uuid`

- 목적: 거래 생성 + 잔액/보유/통계 업데이트를 **원자적으로** 수행
- 멱등키: `p_client_tx_id` (uuid) — 네트워크 재시도/버튼 중복탭 방어를 위해 **항상** 넣는 것을 권장
- 타입별 필수 필드(요약):
  - `지출/수입`: `p_category_id` 필수
  - `이체`: `p_account_id` + `p_to_account_id` 필수 (동일 계좌 금지)
  - `주식_매수/주식_매도`: `p_account_id` + `p_stock_id` + `p_qty>0` 필수
  - `환전_매수/환전_매도`: `p_account_id` + `p_qty>0` + `p_fx_rate>0` 필수
  - `대출_*`: `p_account_id` + `p_liability_id` 필수
  - 공통: `p_amount>=0`, `p_currency` 필수
- 주요 실패 메시지(서버 검증):
  - 계좌 음수 방지: `Account balance cannot be negative...`
  - 보유수량 음수 방지: `Holdings cannot be negative...`
  - USD 지갑 음수 방지: `USD wallet cannot be negative`


##### (CF-02) edit_transaction_v2 (거래 수정)

- 시그니처: `public.edit_transaction_v2(p_original_transaction_id uuid, -- 새 값(원하면 null=변경없음, 빈문자열=''로 "비우기" 가능) p_new_date timestamptz default null, p_new_type transaction_type default null, p_new_amount numeric default null, p_new_currency currency_code default null, p_new_account_id uuid default null, p_new_to_account_id uuid default null, p_new_card_id uuid default null, p_new_stock_id uuid default null, p_new_qty numeric default null, p_new_fx_rate numeric default null, p_new_liability_id uuid default null, p_new_category_id uuid default null, p_new_category text default null, p_new_merchant text default null, p_new_memo text default null, p_edit_reason text default null, p_client_tx_id uuid default null) RETURNS uuid`

- 목적: **원거래 VOID 처리 + 교정/대체 거래 생성**으로 정합성 유지
- 특징: 수정은 UPDATE가 아니라 “체인 생성”입니다.
  - 원거래: `is_voided=true`, `superseded_by=<new_tx_id>`
  - 새 거래: `linked_transaction_id=<원거래>` (교정 체인)
- 멱등키: `p_client_tx_id`(uuid) — 수정 요청 중복 방어
- 제한:
  - `is_correction=true` 거래는 수정 불가
  - 이미 void 된 거래 수정 불가


##### (CF-03) reverse_transaction (거래 취소)

- 시그니처: `public.reverse_transaction(p_transaction_id uuid, p_reason text default null) RETURNS uuid`

- 목적: 거래를 ‘무효화’하기 위한 역거래를 생성하고 원거래를 VOID 처리
- 제한: 교정 거래는 reverse 불가


##### (TS-09/SI-01) request_snapshot_recalc

- 시그니처: `public.request_snapshot_recalc(p_from date, p_to date, p_reason text default 'MANUAL') RETURNS int`

- 목적: 과거 스냅샷 오염/누락 시 재계산 요청을 `daily_snapshot_recalc_queue`에 등록
- 정책: **최대 31일(하드 리밋)**, 오늘/미래 날짜는 자동 무시
- 반환값: 큐에 적재된 날짜 수(대략)
- UI 포인트:
  - 큐가 비어있지 않으면 ‘재계산 필요’ 배지를 표시


##### (TS-04) update_portfolio_metrics

- 시그니처: `public.update_portfolio_metrics(p_user_id uuid, p_asof_date date default current_date, p_lookback_days int default 365) RETURNS void`

- 목적: 지정 날짜(asof) 기준으로 리스크 지표를 갱신
- 운영 권장: 일반 사용자 UI에 노출하지 않고, 서버 배치(daily_close)에서 호출하는 것을 권장


##### (IA-11) apply_stock_split (관리자)

- 시그니처: `public.apply_stock_split(p_stock_id uuid, p_ratio_num integer, p_ratio_den integer, p_effective_date date, p_memo text default null) RETURNS uuid`

- 목적: 액면분할 반영(보유수량/평단/가격 시계열 보정)
- UI 노출: P2(선택), 관리자/개발 전용


##### (SI-08) get_current_app_version

- 시그니처: `public.get_current_app_version() RETURNS table(version text, min_supported_version text, created_at timestamptz)`

- 목적: 최소 지원 버전/권장 버전 안내 (강제 업데이트 UX)


##### (운영/진단) get_kis_token_status

- 시그니처: `public.get_kis_token_status() RETURNS jsonb`

- 목적: 토큰 캐시 상태 진단 (토큰 원문은 노출하지 않음)
- UI 노출: 설정 화면 ‘진단’ 섹션에만 제한적으로 권장


##### (카드 사이클 계산) calc_card_cycle_bounds

- 시그니처: `public.calc_card_cycle_bounds(p_start_day int, p_as_of date) RETURNS table(period_start date, period_end date)`

- 목적: 카드 청구기간(시작/끝) 경계 계산 (뷰에서 내부적으로 사용)


---

#### 3.2 Views (읽기 전용)

> 경로: `GET /rest/v1/<view>?select=...&...`


##### public.v_portfolio_nav_daily

- 컬럼: `user_id`, `trading_date`, `nav_krw`, `delta_nav_krw`, `delta_nav_pct`, `market_data_asof`, `source`, `is_snapshot`

- 권장 사용처:

  - NAV 일별 차트(IA-02/TS-05/TS-06)

  - today 스냅샷이 없으면 LIVE 행을 자동으로 포함합니다.



##### public.v_account_nav_daily

- 컬럼: `user_id`, `trading_date`, `account_id`, `account_name`, `cash_krw`, `usd_qty`, `usd_value_krw`, `stock_value_krw`, `total_krw`, `market_data_asof`, `source`, `is_snapshot`

- 권장 사용처:

  - 계좌별 NAV(IA-03)



##### public.v_account_stock_nav_daily

- 컬럼: `user_id`, `trading_date`, `account_id`, `account_name`, `stock_id`, `ticker`, `stock_name`, `market`, `qty`, `price`, `price_currency`, `fx_rate_used`, `value_krw`, `market_data_asof`, `source`, `is_snapshot`

- 권장 사용처:

  - 종목별 평가(계좌-종목)(IA-04)



##### public.v_portfolio_metrics

- 컬럼: `user_id`, `asof_date`, `mdd_pct`, `lookback_days`, `months_count_12m`, `positive_months_12m`, `win_rate_12m`, `updated_at`

- 권장 사용처:

  - 리스크 지표 카드(TS-03)



##### public.v_dashboard

- 컬럼: `s.user_id`, `s.total_networth_krw`, `s.krw_cash_total`, `s.usd_value_krw`, `s.stock_value_krw`, `s.total_liability_krw`, `s.expense_this_month`, `s.income_this_month`, `s.card_bill_this_month`, `s.interest_cost_this_month`, `usdkrw_rate`, `s.updated_at`

- 권장 사용처:

  - (대체) 단순 대시보드 뷰 — 현재는 RPC get_dashboard 권장



##### public.v_transactions_with_info

- 컬럼: `t.transaction_id`, `t.user_id`, `t.date`, `t.type`, `t.amount`, `t.currency`, `t.account_id`, `a.account_name`, `t.to_account_id`, `to_account_name`, `t.category_id`, `category`, `cat.category_kind`, `t.merchant`, `t.memo`, `t.card_id`, `c.card_name`, `card_linked_account_id`, `card_linked_account_name`, `t.stock_id`, `stock_ticker`, `stock_name`, `stock_market`, `t.qty`, `t.fx_rate`, `t.liability_id`, `l.liability_name`, `t.is_correction`, `t.linked_transaction_id`, `t.is_voided`, `t.voided_at`, `t.void_reason`, `t.superseded_by`, `t.client_tx_id`, `t.created_at`, `t.updated_at`

- 권장 사용처:

  - 감사/전체 로그(CF-05)



##### public.v_transactions_display

- 컬럼: `(= v_transactions_with_info에서 is_voided=false AND is_correction=false 필터)`

- 권장 사용처:

  - 거래 리스트 기본(CF-04)



##### public.v_card_cycle_spend_current

- 컬럼: `c.user_id`, `c.card_id`, `c.card_name`, `c.linked_account_id`, `c.statement_start_day`, `b.period_start`, `b.period_end`, `spend_amount_krw`

- 권장 사용처:

  - 카드 관련 리포트(CF-07~CF-10)



##### public.v_card_cycle_spend_by_account_current

- 컬럼: `v.user_id`, `account_id`, `a.account_name`, `a.account_type`, `v.period_start`, `v.period_end`, `spend_amount_krw`, `card_count`

- 권장 사용처:

  - 카드 관련 리포트(CF-07~CF-10)



##### public.v_card_cycle_spend_recent_12

- 컬럼: `user_id`, `card_id`, `card_name`, `statement_start_day`, `period_start`, `period_end`, `cycle_month_kst`, `spend_amount_krw`

- 권장 사용처:

  - 카드 관련 리포트(CF-07~CF-10)



##### public.v_card_payments_monthly

- 컬럼: `t.user_id`, `t.card_id`, `c.card_name`, `month_kst`, `paid_amount_krw`

- 권장 사용처:

  - 카드 관련 리포트(CF-07~CF-10)



##### public.v_fixed_expenses_active_list

- 컬럼: `user_id`, `fixed_expense_id`, `title`, `amount`, `day_of_month`, `note`, `category_id`, `updated_at`

- 권장 사용처:

  - 고정지출 리스트/월합(CF-11)



##### public.v_fixed_expenses_monthly

- 컬럼: `user_id`, `total_monthly_krw`, `item_count`, `updated_at_max`

- 권장 사용처:

  - 고정지출 리스트/월합(CF-11)



---

#### 3.3 Tables (CRUD/조회)

> 경로: `GET/POST/PATCH/DELETE /rest/v1/<table>`


##### 마스터 데이터(프론트 CRUD)

- `accounts`: 계좌 관리(추가/수정/삭제)
- `cards`: 카드 관리(청구 시작일, 연결 계좌 등)
- `categories`: 카테고리 관리
- `fixed_expenses`: 고정지출 관리
- `liabilities`: 부채(대출) 관리
- `stocks`: 종목 마스터(직접 INSERT 금지, Edge ensure_stock 경유 권장)


##### 시계열/리포트(읽기 위주)

- `portfolio_nav_daily`, `account_nav_daily`, `account_stock_nav_daily`: 일별 스냅샷(서버 생성)
- `portfolio_returns_monthly`: 월별 수익률
- `portfolio_metrics`: 리스크 지표 원본(보통 뷰로 조회)
- `stock_realized_pnl`: 실현손익 리포트
- `stock_prices_daily`, `fx_rates_daily`: 시계열 가격/환율
- `market_data_sync_runs`: 동기화 실행 이력(멀티 디바이스 상태표시)
- `snapshot_recalc_runs`: 재계산 실행 이력
- `daily_snapshot_recalc_queue`: 재계산 필요 큐(SI-01)


##### 직접 DML 금지(프론트는 읽기만)

- `transactions`: 생성/수정/취소는 RPC만
- `account_balances`, `holdings`, `stats`: 서버/트리거/RPC만


---

#### 3.4 Edge Functions

> 경로: `POST /functions/v1/<fn>?...`


##### pad-market-sync

- **op=ensure_stock**

  - Path: `/functions/v1/pad-market-sync?op=ensure_stock`

  - Auth: 사용자 모드: Authorization(Bearer access_token) / 서버 모드: x-cron-secret + body.user_id

  - Body: `{"ticker": "string (필수)", "market": "KR|US|null", "name": "string|null", "currency": "KRW|USD|null", "user_id": "uuid (서버 모드 전용)"}`

  - Resp: EnsureStockResponse (MAUI DTO 기준)

- **op=sync_me**

  - Path: `/functions/v1/pad-market-sync?op=sync_me`

  - Auth: Authorization(Bearer access_token) 필수

  - Body: `{}`

  - Resp: SyncMeResponse (MAUI DTO 기준)

- **op=daily_close**

  - Path: `/functions/v1/pad-market-sync?op=daily_close&market=KR|US`

  - Auth: 서버 전용: x-cron-secret

  - Body: `{}`

  - Resp: DailyCloseResponse (MAUI DTO 기준)

- **op=sync**

  - Path: `/functions/v1/pad-market-sync?op=sync&market=KR|US`

  - Auth: 서버 전용: x-cron-secret

  - Body: `{}`

  - Resp: ScheduledSyncResponse (MAUI DTO 기준)


##### pad-recalc-worker

- Path: `/functions/v1/pad-recalc-worker?op=run`
- Auth: 서버 전용: x-cron-secret
- Body: `{}`
- Resp: RecalcWorkerResponse (MAUI DTO 기준)


---

### 4. 프론트에서 ‘자주 헷갈리는’ 규칙 정리

#### 4.1 카드 지출 vs 통장 지출
- 카드 지출: `transactions.card_id` 채움, `account_id`는 보통 null(‘통장 잔액’에 즉시 반영하지 않음)
- 카드 대금(납부): 타입 `카드_대금` + `account_id`(출금계좌) + `card_id`(대상 카드)

#### 4.2 주식 매수/매도
- 매수/매도 모두 `stock_id`, `account_id`, `qty`, `amount`가 핵심
- 수수료/세금은 별도 거래(`수수료`, `세금`)로 기록(매수/매도 본체와 분리)

#### 4.3 환전
- `환전_매수`: USD를 ‘사서’ USD 지갑 증가, KRW 감소
- `환전_매도`: USD 감소, KRW 증가
- `qty`는 USD 수량, `fx_rate`는 USDKRW

#### 4.4 멱등키(client_tx_id) 운영 팁
- 생성/수정/취소 요청마다 `Guid.NewGuid()`로 생성해 요청에 포함
- 네트워크 재시도 시 **같은 client_tx_id**로 재시도하면 서버가 기존 거래 ID를 반환합니다.
- UI에서 ‘연타’ 방지(버튼 disable) + 서버 멱등을 함께 두면 운영사고가 크게 줄어듭니다.


---

### 5. 최소 구현 체크리스트 (오늘 밤부터 프론트 시작용)

- [ ] Startup: `get_current_app_version` + `get_dashboard`
- [ ] 거래 목록: `v_transactions_display` (페이징/필터)
- [ ] 거래 입력: `process_transaction_v2` (타입별 폼 분기)
- [ ] 거래 수정/취소: `edit_transaction_v2`, `reverse_transaction`
- [ ] 자산 차트: `v_portfolio_nav_daily`
- [ ] 계좌/종목 평가: `v_account_nav_daily`, `v_account_stock_nav_daily`
- [ ] 실현손익: `stock_realized_pnl`
- [ ] 수동 동기화 버튼: `pad-market-sync?op=sync_me`
- [ ] 종목 등록: `pad-market-sync?op=ensure_stock`
- [ ] 정합성 배지: `daily_snapshot_recalc_queue` 조회 + (필요 시) `request_snapshot_recalc`

---

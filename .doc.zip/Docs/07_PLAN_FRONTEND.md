## 프론트엔드 작업 계획
- 원본: `PAD_v2.3.5_FRONTEND_WORK_PLAN_2026-01-30_DETAILED.FINAL.md`

## PAD v2.3.5 프론트엔드 작업 기획서 (MAUI) — 상세판 (2026-01-30)

> 대상: Android + Windows (C# .NET MAUI)  
> 백엔드: Supabase(Postgres + RPC + RLS) + Edge Functions + pg_cron  
> 목적: **실사용 가능한 가계부/자산관리 앱**을 “입력 UX 최적화 + 정합성 보장 + 장애 대응 가능” 수준으로 완성

---

### 0. 결론(한 줄)
프론트엔드는 **“세션/권한(필수) → 대시보드(가시성) → 입력(가치) → 수정/VOID(안전) → 상태/운영(지속성)”** 순서로 구축하고, **쓰기=RPC/Edge, 읽기=View/RPC**로 일원화한다.

---

### 1. 프로젝트 목표와 성공 기준

#### 1.1 목표(Goals)
1) **빠른 입력**: 하루 사용 기준 “거래 10건 입력”이 부담 없이 가능  
2) **안전한 수정**: 할인/정정/환불 같은 수정이 “데이터 훼손 없이” 가능 (VOID + 교정)  
3) **정합성 위임**: 잔액/보유/통계는 DB가 책임지고, 앱은 UX/검증/가시성에 집중  
4) **운영 가능**: 동기화 실패/지연이 발생해도 앱이 상태를 보여주고 사용자가 복구 가능  
5) **멀티플랫폼**: Android/Windows에서 UX가 크게 깨지지 않는 공통 구조

#### 1.2 비목표(Non-goals)
- 실시간 주가/체결 스트리밍(초단타 수준)
- 다중 사용자 협업/공유(우선순위 낮음)
- 금융기관 연동 자동 수집(당장 제외)
- 완벽한 회계(복식부기 전체) 구현(확장 가능하되 MVP는 단순화)

#### 1.3 성공 지표(Definition of Success)
- 로그인/세션: 10회 재실행/재로그인 테스트에서 실패 0
- 입력: 핵심 거래 유형 4종(현금/이체/카드/주식) 입력 후 대시보드 반영 100%
- 수정: 거래 수정 10회 시나리오에서 잔액 불일치 0
- 상태: daily_close KR/US 성공 여부 확인 가능 + 실패 시 안내
- 크래시/장애: 네트워크 off/on, 토큰 만료, 권한 오류에서 앱이 “죽지 않고” 안내

---

### 2. 사용자/시나리오 정의

#### 2.1 페르소나(단일 사용자 중심)
- 본인 1인 실사용(모든 데이터는 본인 소유)
- 입력량: 하루 5~20건
- 관심: 순자산/부채/주식 평가/현금흐름

#### 2.2 핵심 사용자 여정(User Journeys)
1) **오늘 소비 입력**
   - 홈 → 입력 → 카드 결제 → 저장 → 내역에서 확인
2) **이체(현금 이동)**
   - 입력 → 계좌이체 → “출금 계좌 잔액 감소 + 입금 계좌 증가” 확인
3) **주식 거래**
   - 입력 → 매수/매도 → 보유수량/평단/실현손익 반영
4) **정정(할인/취소/오입력)**
   - 내역 → 상세 → 수정(VOID + 교정) → 대시보드/잔액 불일치 없음을 확인
5) **상태 확인**
   - 설정/상태 → KR/US daily_close 마지막 성공 시각 확인 → 실패면 재시도/가이드

---

### 3. 정보구조(IA) / 화면 구성

#### 3.1 탭/메뉴 구조(권장)
- **홈(Dashboard)**: 요약, 최근 거래, 상태 배너
- **입력(Quick Add)**: 거래 유형 선택 → 폼
- **내역(Transactions)**: 목록/필터/검색/상세/수정(VOID)
- **자산(Assets)**: 계정/카드/주식/부채 요약 및 상세
- **설정/상태(Settings & Ops)**: 마스터 관리(카테고리/계정/카드), 동기화 상태, 디버그

#### 3.2 공통 UI 패턴
- 상단: 기간 선택(오늘/주/월/커스텀) + 새로고침
- 카드형 요약 + 리스트(최근 10건)
- “저장/수정”은 **확정 버튼** 1개 + 실패 시 원인 메시지 + 재시도

---

### 4. 데이터 접근/통신 정책(가장 중요)

#### 4.1 원칙
- **쓰기(INSERT/UPDATE/DELETE)**: 반드시 **RPC 또는 Edge Function**만 사용  
  - 프론트에서 테이블 직접 쓰기 금지(정합성 깨짐/권한 혼동/운영 리스크)
- **읽기(SELECT)**: View 또는 읽기 전용 RPC로 통일  
- 모든 요청은 “관측 가능”해야 함(요청 ID/에러 분류/재시도/취소)

#### 4.2 권장 클라이언트 모듈
- `ISessionProvider`: SecureStorage 기반 토큰 보관/갱신
- `ISupabaseApi`: PostgREST/RPC 공용 래퍼(인증 헤더/에러 매핑)
- `IEdgeClient`: Edge Function 호출 래퍼(x-cron-secret 없이, 앱용 경로만)
- `RequestGate`: 동시 요청 제한(특히 리스트/대시보드)
- `RetryPolicy`: 일시 오류 재시도(네트워크/429/5xx만)

#### 4.3 예외/에러 분류 규칙
- 네트워크: Offline/Timeout/DNS
- 인증: 401(세션 만료), 403(RLS/권한)
- 검증: 400(입력값 오류), 제약조건 위반
- 서버: 5xx(Edge/RPC 내부 오류)
- 사용자 메시지: “원인 + 다음 행동”으로 표시  
  - 예: “세션이 만료되었습니다. 다시 로그인해주세요.”  
  - 예: “잔액이 부족합니다. 출금 금액을 줄이거나 계좌를 변경하세요.”

---

### 5. 도메인 모델(프론트에서 반드시 명확히)

#### 5.1 값 객체(Value Objects)
- `Money(amount, currency)`  
- `Quantity(decimal)` (주식 수량은 소수/정수 정책 명확히)  
- `TradeSide(Buy/Sell)`  
- `Fee(amount, currency)` / `Tax(amount, currency)`  
- `DateOnly(trading_date)` vs `DateTime(occurred_at)` 구분

#### 5.2 거래 유형(입력 UX를 위한 분류)
- CashDeposit / CashWithdraw
- Transfer (Account → Account)
- CardPurchase (Card + Category)
- StockBuy / StockSell

> 구현상 DB는 하나의 transactions(또는 타입 필드)일 수 있으나, **UI는 유형별 폼**이 정답이다.

---

### 6. 화면별 상세 설계(사양)

> 아래는 “페이지 단위 기능정의 + 상태 + API”를 한 번에 잡기 위한 상세 스펙이다.

#### 6.1 LoginPage / Auth Flow
**목표**: 세션 안정화, 자동 로그인, 만료 처리

- 입력: email/password 또는 provider(선택)
- 성공: 토큰 저장(SecureStorage) + 초기 데이터 프리패치
- 실패: 에러 메시지(401/invalid credentials)

**상태**
- Idle → Submitting → Success → Navigation
- Offline 시 “네트워크 연결 확인”

**작업 항목**
- [ ] `ISessionProvider` 구현
- [ ] 토큰 갱신(만료 5분 전 시도)
- [ ] 전역 401 핸들링(자동 로그아웃 or 재로그인 유도)

---

#### 6.2 DashboardPage
**목표**: “오늘 내 상태” 한 화면에 이해

**표시 요소**
- 순자산(총자산-총부채)
- 현금(KRW + USD 환산)
- 주식 평가액(KRW 환산)
- 부채 총액
- 최근 거래 10건
- **상태 배너**: KR/US daily_close 마지막 성공 시각 + 실패 경고

**데이터 정책**
- 읽기: dashboard view/RPC(프로젝트 DB 설계에 맞춰 1개로 고정)
- 새로고침: Pull-to-refresh + 수동 버튼

**빈 상태**
- 계정/카드/거래가 없을 때 “시작 가이드” 표시

---

#### 6.3 QuickAddPage(입력 허브)
**목표**: 입력 진입 비용 최소화

- 버튼 4개: 현금, 이체, 카드, 주식
- 최근 사용한 계정/카드/카테고리 “즐겨찾기”
- “마지막 입력 반복” 기능(선택)

---

#### 6.4 Cash Transaction Form
**필드**
- 계정(Account)
- 구분(입금/출금)
- 금액(통화)
- 날짜/시간(occurred_at)
- 카테고리(선택)
- 메모(선택)

**검증**
- 금액 > 0
- 미래 날짜 제한(정책에 따라)
- 출금은 잔액 부족 시 서버에서 실패 → 사용자 메시지 매핑

**저장**
- RPC: `create_cash_transaction(...)` 형태(실제 RPC명은 프로젝트 기준)

---

#### 6.5 Transfer Form (Account → Account)
**필드**
- From 계정, To 계정
- 금액/통화
- 날짜/시간
- 메모

**검증**
- From != To
- 금액 > 0
- 통화 일치(정책: 서로 다른 통화 계정 이체는 MVP에서는 금지 추천)

**저장**
- RPC: `create_transfer(...)` (원자적으로 2개 거래/잔액 반영)

---

#### 6.6 Card Purchase Form
**필드**
- 카드(Card)
- 카테고리(Category)
- 금액
- 결제일(occurred_at)
- 메모

**추가 옵션(후순위)**
- 할부 개월
- 부분 취소

**저장**
- RPC: `create_card_purchase(...)`
- (DB가 청구/납부를 자동 생성한다면 UI는 상태만 표시)

---

#### 6.7 Stock Trade Form (Buy/Sell)
**필드**
- 시장(KR/US)
- 종목(검색: ticker/name)
- 구분(Buy/Sell)
- 수량
- 단가
- 수수료(선택)
- 세금(선택)
- 거래일(occurred_at) + “체결일” 의미 명확히
- 메모

**검증**
- 수량 > 0, 단가 > 0
- Sell: 보유수량 부족 시 실패 처리
- 통화: KR=KRW, US=USD(원칙)

**저장**
- RPC: `create_stock_trade(...)`
- UI에서 “예상 체결금액” 계산(단가*수량 + 수수료 등)만 제공  
  실현손익 확정은 DB가 책임

**휴장/환율**
- 거래 입력과 daily_close는 별개  
- 대시보드는 daily_close 기반 환율/시세로 평가

---

#### 6.8 TransactionsListPage
**요구사항**
- 페이징(최소 limit/offset)
- 필터: 기간, 타입, 계정, 카드, 카테고리, 종목, 키워드
- 정렬: 최신순
- 빠른 액션: 스와이프(상세/수정/VOID)

**성능**
- 서버에서 필터링(클라이언트 전체 로드 금지)
- 검색은 debounce(300ms)

---

#### 6.9 TransactionDetailPage + 수정/VOID
**원칙**
- 수정/삭제는 “원본 변경”이 아니라 **VOID + 교정 거래 생성**
- 상세에서 “원본/교정 연결”을 보여주면 추적성↑

**UI 플로우**
- 상세 → 수정 → (기존 거래 VOID) + (새 거래 생성) → 결과 표시
- 실패 시: “원본은 그대로 유지” 보장

---

#### 6.10 AssetsPage
- Accounts: 잔액, 최근 변동
- Cards: 이번 달 사용액, 결제 예정
- Stocks: 종목별 수량/평단/평가/실현손익(가능한 범위)
- Liabilities: 부채 목록/상환(후순위)

---

#### 6.11 Settings & Ops Page
**목표**: 운영 가시성 + 마스터 관리

- 마스터:
  - 카테고리 CRUD
  - 계정 CRUD
  - 카드 CRUD
- 상태:
  - 최근 `market_data_sync_runs` (KR/US)
  - 마지막 `market_data_asof`
  - (개발 빌드 전용) 수동 daily_close 트리거 버튼
- 디버그:
  - 앱 버전, API endpoint, 환경(prod/vts), 로그 레벨

---

### 7. 구현 순서(세부 Task Breakdown)

#### Phase 0 — 오늘 저녁(골격)
1) 프로젝트 구조 정리
   - `Pad.App`, `Pad.Presentation`, `Pad.Application`, `Pad.Domain`, `Pad.Infrastructure`
2) DI 컨테이너 구성
3) 세션/인증 인프라
4) 공통 네트워크 레이어(에러 매핑/재시도/취소)

#### Phase 1 — Dashboard
1) Dashboard API 호출 연결
2) 상태 배너(최근 sync run)
3) 최근 거래 10건 목록

#### Phase 2 — 입력 4종
1) QuickAdd 허브
2) Cash
3) Transfer
4) Card
5) Stock

#### Phase 3 — 내역/수정
1) 필터/검색/페이징
2) 상세
3) 수정/VOID 플로우

#### Phase 4 — 마스터 관리
1) 카테고리
2) 계정
3) 카드

#### Phase 5 — 운영 화면
1) sync runs 리스트
2) 에러 안내
3) (옵션) 개발용 수동 트리거

---

### 8. 테스트 계획(프론트 기준)

#### 8.1 기능 테스트(핵심)
- 로그인 성공/실패/세션 만료
- 입력 4종: 성공/검증 실패/서버 제약 실패
- 수정/VOID: 원본 유지 + 교정 생성
- 필터/검색: 기간/계정/키워드 조합
- 상태 배너: KR/US run 표시, 실패 시 안내

#### 8.2 장애 시나리오
- 네트워크 끊김 중 저장 → 재시도
- 서버 500 → 안내 + 재시도
- 401 → 재로그인 유도
- 403 → 권한 안내(앱이 하면 안 되는 동작)

#### 8.3 성능 테스트(실사용 수준)
- 거래 5,000건 기준 리스트 스크롤/검색
- 대시보드 로딩 1초 이내 목표(캐시/프리패치)

---

### 9. 운영/관측(Observability)
- 앱 로그: 요청 시작/종료, 오류 코드, 상관 ID(가능하면)
- 민감정보 마스킹(토큰/개인정보/키)
- StatusPage에 “마지막 동기화 시간/실패 원인” 표시
- (선택) Sentry 등 크래시 리포팅 연동

---

### 10. 코드 규칙(SOLID/유지보수)
- ViewModel은 UI 상태만, 네트워크 호출은 UseCase/Service로
- DTO는 Contracts 프로젝트로 고정(변경 최소화)
- 모든 비동기 요청에 CancellationToken
- 공통 Result 타입 사용(성공/실패/에러코드)

---

### 11. 산출물(파일/폴더) 제안
- `docs/FRONTEND_PLAN.md` (본 문서)
- `docs/API_MAPPING.md` (페이지 ↔ RPC/View/Edge 매핑표)
- `src/Pad.Contracts/` (DTO)
- `src/Pad.Infrastructure/` (Supabase/Edge/Session)
- `src/Pad.Presentation/` (Pages/ViewModels/Components)

---

### 12. 오늘 저녁 “바로 시작” 체크리스트
1) `ISessionProvider` 구현 완료
2) DashboardPage에 실제 데이터 1개라도 연결
3) Status 배너(최근 KR/US run) 표시
4) QuickAdd 허브만 만들고 Cash 입력부터 1개 완성

---

#### 부록 A. 파일 참고(프로젝트에 존재하는 산출물)
- `PAD_v2.3.5_MAUI_DTO.InputsAndEdgeResponses.cs`
- `PAD_v2.3.5_MAUI_DTO.Generated.PATCHED.cs`
- `EDGE_API.md`
- `OPS_RUNBOOK.md`
- `SECRETS_AND_CONFIG.md`

> 위 파일들은 “계약(Contract)”이므로, 프론트 구현 시 네임스페이스 분리 + 버전 고정을 권장합니다.

---
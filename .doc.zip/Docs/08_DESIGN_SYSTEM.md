# 08. BudgetBook Design System

> Source of truth for all UI styling. AI agents MUST follow this spec — do not invent colors, fonts, or spacing.

## 1. Foundation

### 1.1 Technology Stack

| Layer | Choice | Notes |
|---|---|---|
| Component Library | **Radzen.Blazor** (Material theme) | `<RadzenTheme Theme="material" />` in MainLayout |
| CSS Framework | Custom utility classes + Radzen overrides | NO Tailwind/Bootstrap (bootstrap.min.css exists but is legacy — do not use) |
| Font | **Outfit** (Google Fonts) | Weights: 300, 400, 500, 600, 700 |
| Icons | Material Icons (via Radzen `Icon` prop) | e.g. `Icon="dashboard"`, `Icon="account_balance_wallet"` |

### 1.2 Theme Mode

**Dark mode only.** There is no light mode toggle. All colors assume a dark background.

---

## 2. Color Palette

### 2.1 CSS Custom Properties (`:root` in `wwwroot/css/app.css`)

```css
/* HSL base values (no hsl() wrapper — used as: hsl(var(--accent-vibrant))) */
--accent-vibrant:    247, 85%, 65%;    /* #6366f1 — Indigo 500 */
--accent-secondary:  327, 85%, 65%;    /* #ec4899 — Pink 500 */

/* Backgrounds */
--bg-deep:           222, 47%, 5%;     /* Very dark navy — body/layout bg */
--bg-card:           222, 47%, 11%;    /* Slate 900-ish — sidebar, cards */
--bg-glass:          rgba(30, 41, 59, 0.7);  /* Glassmorphism panels */

/* Derived */
--primary:           hsl(var(--accent-vibrant));        /* Indigo */
--primary-glow:      hsla(var(--accent-vibrant), 0.3);  /* Glow/focus ring */
--secondary:         hsl(var(--accent-secondary));       /* Pink */

/* Text */
--text-main:         #f8fafc;    /* Primary text — near white */
--text-muted:        #94a3b8;    /* Secondary text — Slate 400 */
--text-dim:          #64748b;    /* Tertiary/label text — Slate 500 */

/* Borders */
--border-light:      rgba(255, 255, 255, 0.08);   /* Default borders */
--border-strong:     rgba(255, 255, 255, 0.15);   /* Emphasized borders */

/* Semantic */
--success:           #10b981;   /* Emerald 500 */
--danger:            #ef4444;   /* Red 500 */
--warning:           #f59e0b;   /* Amber 500 */
```

### 2.2 Usage Rules

| Context | Color | Example |
|---|---|---|
| Body background | `hsl(var(--bg-deep))` | Body, RadzenLayout |
| Card/panel background | `var(--bg-glass)` | `.premium-card`, `.card` |
| Sidebar background | `var(--bg-card)` | RadzenSidebar |
| Header background | `rgba(15, 23, 42, 0.6)` + `backdrop-filter: blur(20px)` | RadzenHeader |
| Primary text | `var(--text-main)` | Headings, values |
| Secondary text | `var(--text-muted)` | Labels, descriptions |
| Tertiary text | `var(--text-dim)` | Timestamps, IDs, hints |
| Positive values (income, gain) | `var(--success)` / `#10b981` | +₩1,200,000 |
| Negative values (expense, loss) | `var(--danger)` / `#ef4444` | -₩500,000 |
| Gradient text | `.text-gradient` class | Page titles |
| Primary button | `.btn-premium` — gradient `var(--primary)` → `var(--secondary)` | "NEW RECORD" |

---

## 3. Typography

### 3.1 Font Stack

```css
font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
-webkit-font-smoothing: antialiased;
```

### 3.2 Scale

| Element | Size | Weight | Letter-spacing | Class/selector |
|---|---|---|---|---|
| Page title (h1) | `2.5rem` | 800 | `-0.02em` | `h1` + `.text-gradient` |
| Section title (h2) | `1.75rem` | 700 | `-0.03em` | `h2` |
| Card title | `1.2rem` | 700 | default | Inline style |
| Body text | `1rem` (16px) | 400 | default | Default |
| Label / subtitle | `0.9rem` | 400 | default | `.text-dim` |
| Small label | `0.85rem` | 400 | `0.05em` | Table headers |
| Section header (sidebar) | `0.7rem` | 800 | `0.1em` | `text-transform: uppercase` |
| Badge text | `0.75rem` | 600 | default | `.badge` |

### 3.3 Heading Rules

- All headings: `color: var(--text-main)`, `font-weight: 700`, `letter-spacing: -0.03em`, `margin-bottom: 1.25rem`
- Page titles: always use `.text-gradient` class for gradient fill

---

## 4. Spacing & Layout

### 4.1 Border Radius Tokens

```css
--radius-xl:  1.5rem;    /* premium-card */
--radius-lg:  1rem;      /* card, glass-panel, table wrapper */
--radius-md:  0.75rem;   /* buttons, inputs, nav items */
```

### 4.2 Spacing Conventions

| Context | Value |
|---|---|
| Page content padding | `2rem` |
| Card inner padding | `1.5rem` |
| Grid gap (card-grid) | `1.5rem` |
| Section margin-bottom | `2rem` |
| Sidebar item margin | `0.25rem 0.75rem` |
| Badge padding | `0.25rem 0.75rem` |

### 4.3 Page Layout

```
┌──────────────────────────────────────────────────────┐
│ RadzenHeader (sticky, blur backdrop)                  │
│  [≡ toggle] [BudgetBook logo]     [Sync][+NEW][👤]   │
├────────────┬─────────────────────────────────────────┤
│ RadzenSide │ RadzenBody                              │
│ bar 260px  │  .main-content (max-width: 1400px)     │
│            │   padding: 2rem                         │
│ PanelMenu  │   @Body                                │
│            │                                         │
└────────────┴─────────────────────────────────────────┘
```

### 4.4 Grid System

```css
.card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}
```

For form layouts, use Radzen's `rz-grid` / `rz-col-*` classes:
- `rz-col-12` = full width
- `rz-col-md-4` / `rz-col-md-8` = sidebar + detail pattern (Categories page)
- `rz-col-md-5` / `rz-col-md-7` = calendar + detail pattern

---

## 5. Component Catalog

### 5.1 Cards

**Premium Card** — primary container for content sections:
```html
<div class="premium-card">
    <!-- Has glassmorphism bg, hover lift effect, radial gradient overlay -->
</div>
```

**Radzen Card** — used for simpler containers:
```html
<RadzenCard> ... </RadzenCard>
```

### 5.2 Buttons

| Type | Class/Component | Usage |
|---|---|---|
| Primary action | `.btn-premium` | "NEW RECORD", major CTAs |
| Standard | `<RadzenButton ButtonStyle="ButtonStyle.Primary">` | "종목 추가" |
| Light/Ghost | `<RadzenButton ButtonStyle="ButtonStyle.Light" Variant="Variant.Flat">` | Refresh, filters |
| Small | Add `Size="ButtonSize.Small"` | Inline actions |

### 5.3 Badges

```html
<span class="badge badge-success">LIVE</span>   <!-- green -->
<span class="badge badge-danger">ERROR</span>    <!-- red -->
```

Additional inline badges (used in Calendar):
```html
<!-- VOID status -->
<span style="background: rgba(239,68,68,0.15); color: #ef4444; padding: 0.15rem 0.5rem; border-radius: 999px; font-size: 0.7rem; font-weight: 600;">VOID</span>

<!-- EDIT/CORRECTION status -->
<span style="background: rgba(234,179,8,0.15); color: #eab308; padding: 0.15rem 0.5rem; border-radius: 999px; font-size: 0.7rem; font-weight: 600;">EDIT</span>
```

### 5.4 Data Display

| Component | Usage |
|---|---|
| `<RadzenDataGrid>` | Transaction lists, portfolio holdings, sync history |
| `<RadzenChart>` with `<RadzenColumnSeries>` | Monthly spending bar chart |
| `<RadzenChart>` with `<RadzenLineSeries>` | NAV trend, returns trend |
| `<RadzenListBox>` | Category selection (left panel) |
| `<RadzenTabs>` / `<RadzenTabsItem>` | Reports page (소비/자산/성과 tabs) |

### 5.5 Forms

| Component | Usage |
|---|---|
| `<RadzenDatePicker Inline="true">` | Calendar date selection |
| `<RadzenDropDown>` | Account/category selectors |
| `.input-field` | Custom text inputs (dark bg, border glow on focus) |
| `<RadzenProgressBarCircular>` | Full-page loading spinner |
| `<RadzenProgressBar Mode="ProgressBarMode.Indeterminate">` | Inline loading bar |

### 5.6 Feedback

| Component | Usage |
|---|---|
| `<ErrorToast>` | Shared error toast (every page includes `@ref="_errorToast"`) |
| `<RadzenAlert Severity="AlertSeverity.Error">` | Inline error banner with retry button |
| `<ConfirmDialog>` | Destructive action confirmation (logout, delete) |
| `<SkeletonLoader>` | Loading placeholder with shimmer animation |

### 5.7 Navigation (Sidebar)

Sidebar uses `<RadzenPanelMenu>` with `<RadzenPanelMenuItem>`:

```html
<RadzenPanelMenuItem Text="Dashboard" Path="/dashboard" Icon="dashboard" />
```

**CSS overrides applied** (in `app.css`):
- Items have `border-radius: var(--radius-md)`, margin `0.25rem 0.75rem`
- Default: `background: transparent`, `color: var(--text-muted)`
- Hover: `background: rgba(255,255,255,0.05)`, `color: var(--primary)`
- Active: `background: var(--primary-glow)`, `color: var(--primary)`, left border `3px solid var(--primary)`

---

## 6. Effects & Animations

### 6.1 Glassmorphism

```css
background: var(--bg-glass);           /* rgba(30, 41, 59, 0.7) */
backdrop-filter: blur(12px);
border: var(--glass-border);           /* 1px solid rgba(255,255,255,0.1) */
border-radius: var(--radius-xl);
box-shadow: var(--glass-shadow);       /* 0 8px 32px rgba(0,0,0,0.37) */
```

### 6.2 Card Hover

```css
.premium-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 40px 0 rgba(0, 0, 0, 0.5);
    border-color: hsla(var(--accent-vibrant), 0.4);
}
```

### 6.3 Page Entry Animation

```css
.fade-in {
    animation: slideUpFade 0.6s cubic-bezier(0.22, 1, 0.36, 1) forwards;
}
@keyframes slideUpFade {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}
```

### 6.4 Button Hover

```css
.btn-premium:hover {
    filter: brightness(1.1);
    transform: scale(1.02);
    box-shadow: 0 6px 20px hsla(var(--accent-vibrant), 0.6);
}
```

---

## 7. Page Header Pattern

Every page follows this standard header:

```html
<div class="flex justify-between items-center" style="margin-bottom: 2rem;">
    <div>
        <h1 class="text-gradient" style="font-weight: 800; margin: 0;">{Page Title}</h1>
        <p class="text-dim" style="font-size: 0.9rem;">{Subtitle description}</p>
    </div>
    <RadzenButton Icon="refresh" ButtonStyle="ButtonStyle.Light" Variant="Variant.Flat"
                  Click="@LoadAsync" IsBusy="@_isLoading" Disabled="@_isLoading" />
</div>
```

---

## 8. State Patterns

### 8.1 Loading State

```html
<!-- Full page: centered spinner -->
<RadzenProgressBarCircular Value="100" ShowValue="false" Mode="ProgressBarMode.Indeterminate" />

<!-- Inline: skeleton loader -->
<SkeletonLoader Rows="5" Widths="15%,30%,20%,15%" />

<!-- Inline: progress bar -->
<RadzenProgressBar Mode="ProgressBarMode.Indeterminate" Style="width:100%;" />
```

### 8.2 Empty State

```html
<div class="premium-card text-center" style="padding: 3rem 2rem; background: linear-gradient(135deg, rgba(99, 102, 241, 0.05), transparent);">
    <RadzenIcon Icon="{icon}" Style="font-size: 3rem; color: var(--primary); opacity: 0.6; margin-bottom: 1rem;" />
    <p style="font-size: 1.1rem; font-weight: 500; margin-bottom: 0.5rem;">{Empty message}</p>
    <p class="text-dim" style="font-size: 0.9rem;">{Guidance text}</p>
</div>
```

### 8.3 Error State

```html
<RadzenAlert Severity="AlertSeverity.Error" AllowClose="true">
    @_error
    <RadzenButton Text="다시 시도" Icon="refresh" ButtonStyle="ButtonStyle.Light"
                  Size="ButtonSize.Small" Style="margin-left: 1rem;" Click="@LoadAsync" />
</RadzenAlert>
```

---

## 9. Radzen Theme Overrides

All Radzen component overrides are in `wwwroot/css/app.css` (lines 230-278):

```css
.rz-layout     { background-color: hsl(var(--bg-deep)) !important; }
.rz-header     { background: rgba(15,23,42,0.8) !important; backdrop-filter: blur(16px) !important; }
.rz-sidebar    { background: var(--bg-card) !important; }
.rz-panel-menu { background: transparent !important; }
.rz-profile-menu { margin-right: 0.25rem !important; }
```

**IMPORTANT**: Always use `!important` when overriding Radzen defaults to ensure custom dark theme takes precedence.

---

## 10. Utility Classes

### 10.1 Flexbox (defined in app.css)

| Class | CSS |
|---|---|
| `.flex` | `display: flex` |
| `.flex-col` | `flex-direction: column` |
| `.items-center` | `align-items: center` |
| `.justify-between` | `justify-content: space-between` |
| `.justify-center` | `justify-content: center` |
| `.gap-2` | `gap: 0.5rem` |
| `.gap-4` | `gap: 1rem` |
| `.w-full` | `width: 100%` |
| `.h-full` | `height: 100%` |

### 10.2 Text

| Class | Effect |
|---|---|
| `.text-gradient` | Indigo→Pink gradient text fill |
| `.text-dim` | `color: var(--text-dim)` — use for labels, hints |
| `.text-secondary` | `color: var(--text-muted)` — Radzen built-in |

### 10.3 Radzen Built-in Utilities

Use `rz-` prefixed classes from Radzen for layout within Radzen components:
- `rz-flex`, `rz-items-center`, `rz-justify-between`, `rz-gap-3`, `rz-wrap`
- `rz-mb-3`, `rz-mt-3` (margin)
- `rz-text-bold`, `rz-text-xl`, `rz-text-secondary`
- `rz-text-danger`, `rz-text-success`
- `rz-text-center`, `rz-text-right`
- `rz-grid`, `rz-col-12`, `rz-col-md-4`, etc.

---

## 11. Currency & Number Formatting

Use `FormatHelpers` static class (already in project):

| Method | Output |
|---|---|
| `FormatHelpers.FormatCurrency(decimal?)` | `₩1,234,567` or `$1,234.56` |
| `FormatHelpers.FormatPct(decimal?)` | `+12.34%` / `-5.67%` |
| `FormatHelpers.GetPctClass(decimal?)` | Returns `rz-text-success` or `rz-text-danger` |
| `FormatHelpers.FormatKstDate(DateTime)` | `2026-02-08 14:30` (KST) |

---

## 12. Responsive Breakpoints

| Breakpoint | Value | Layout change |
|---|---|---|
| Mobile | `< 641px` | Sidebar collapses (toggle), single column |
| Tablet+ | `≥ 641px` | Sidebar visible, multi-column grid |
| Desktop | Grid `minmax(280px, 1fr)` | Auto-fit columns |

The sidebar is controlled by `@bind-Expanded="_sidebarExpanded"` on `<RadzenSidebar>` with `<RadzenSidebarToggle>` in the header.

---

## 13. Do's and Don'ts

### DO
- Use `.premium-card` for main content containers
- Use `.text-gradient` for page titles
- Use `var(--text-dim)` for labels and hints
- Use `RadzenButton ButtonStyle="ButtonStyle.Light" Variant="Variant.Flat"` for secondary actions
- Use `<ErrorToast>` on every page for error feedback
- Use `<SkeletonLoader>` during data loading
- Include `@implements IDisposable` and `CancellationTokenSource` on pages with async data

### DON'T
- Do NOT use Bootstrap classes (legacy file exists but is not the design system)
- Do NOT use MudBlazor (not installed)
- Do NOT add light mode colors or theme toggles
- Do NOT use raw color values — always use CSS custom properties
- Do NOT create new utility classes when Radzen `rz-*` classes exist
- Do NOT override Radzen styles without `!important`

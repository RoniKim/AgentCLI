# PAD v2.3.5 — MAUI 프론트엔드 P0 API 체크리스트 (별도본)
- 생성일: 2026-01-30
- 목적: **오늘 저녁부터 바로 구현**할 수 있게, “프론트에서 호출 가능한 것 / 절대 호출하면 안 되는 것 / 화면별 최소 호출 세트”만 1장으로 정리
- 기준: Release COMBINED 문서(단일 진실: INSTALL.sql + Edge TS)

---

## 1) 프론트(MAUI)에서 “허용”되는 호출만 (✅)

### 1.1 RPC (POST /rest/v1/rpc/*) — MAUI가 직접 호출
- ✅ `get_current_app_version()`  
  - 앱 시작 시 1회. 최소버전 체크(강제 업데이트 UX)
- ✅ `get_dashboard(p_limit, p_include_nav)`  
  - 홈 KPI + 최근 거래 + 동기화 상태 + 토큰 상태(진단용)
- ✅ `process_transaction_v2(...)`  
  - 거래 생성(멱등키 `p_client_tx_id` **항상** 넣기)
- ✅ `edit_transaction_v2(...)`  
  - 거래 수정(UPDATE가 아니라 **VOID + 교정 체인**)
- ✅ `reverse_transaction(p_transaction_id, reason)`  
  - 거래 취소(역거래 생성 + 원거래 VOID)
- ✅ `request_snapshot_recalc(p_from, p_to, reason)`  
  - 정합성(재계산) 요청 큐 적재  
  - ⚠️ 서버 하드 리밋: **최대 31일**, 오늘/미래 자동 무시
- ✅ `get_returns_summary()` *(패치 적용된 경우만)*  
  - 순자산 증감률 vs 투자성과(TWR) 분리 요약(단일 row)

### 1.2 Views (GET /rest/v1/<view>) — MAUI가 조회
- ✅ `v_transactions_display` : 기본 거래 리스트(VOID/CORRECTION 제외)
- ✅ `v_transactions_with_info` : 감사/전체 로그(정정/무효화 포함)
- ✅ `v_portfolio_nav_daily` : NAV 라인 차트(기간 필터)
- ✅ `v_account_nav_daily` : 계좌별 NAV
- ✅ `v_account_stock_nav_daily` : 계좌-종목별 평가
- ✅ `v_portfolio_metrics` : MDD/승률 등 리스크 카드
- ✅ 카드 리포트
  - `v_card_cycle_spend_current`
  - `v_card_payments_monthly`
  - `v_card_cycle_spend_recent_12`
  - (선택) `v_card_cycle_spend_by_account_current`

### 1.3 Tables (CRUD) — MAUI가 직접 CRUD 허용(마스터 데이터)
- ✅ `accounts`, `cards`, `categories`, `fixed_expenses`, `liabilities`
- ✅ `stocks`는 조회는 가능하나, **등록/보강은 Edge ensure_stock 경유를 권장**

---

## 2) 프론트(MAUI)에서 “절대 호출하면 안 되는 것” (🚫)
> 보안/정합성/운영 정책상 **server-only** 입니다.  
> 프론트에서 호출 시 403(권한), 또는 더 위험한 운영 사고(키 노출 등)가 발생합니다.

### 2.1 Server-only RPC (대표)
- 🚫 `update_portfolio_metrics(...)`
- 🚫 `capture_*_snapshot(...)` 전부 (NAV/계좌/카드 등)
- 🚫 `rebuild_daily_snapshots(...)`, `rebuild_monthly_returns(...)`, `rebuild_*`
- 🚫 `persist_market_data_daily(...)` 등 daily 확정/배치성 함수
- 🚫 `kis_token_*` 전부

### 2.2 Server-only Edge
- 🚫 `pad-market-sync?op=sync` (전체 사용자 배치)
- 🚫 `pad-market-sync?op=daily_close` (장마감 확정)
- 🚫 `pad-recalc-worker?op=run` (큐 소비 + 재계산 실행)

### 2.3 Direct DML 금지 테이블 (MAUI에서 INSERT/UPDATE/DELETE 금지)
- 🚫 `transactions`
- 🚫 `account_balances`
- 🚫 `holdings`
- 🚫 `stats`
> 위는 **RPC/서버**가 원자적으로 관리합니다. 직접 쓰면 정합성이 깨집니다.

---

## 3) Edge 호출(✅) — MAUI에서 쓰는 2개만
> 공통: `Authorization: Bearer <user_access_token>` 사용  
> ⚠️ 앱 코드/리포지토리에 CRON_SECRET / SERVICE_ROLE_KEY 절대 저장 금지

### 3.1 종목 등록/보강
- ✅ `POST /functions/v1/pad-market-sync?op=ensure_stock`
- Body(JSON): `{ ticker, market: "KR"|"US", name?, note? }`
- 응답: `{ ok, mode, stock:{...}, latestPrice }`

### 3.2 수동 동기화
- ✅ `POST /functions/v1/pad-market-sync?op=sync_me&market=KR|US|ALL`
- Body: 없음(권장)
- 응답: 성공/부분/실패 + cooldown/in_progress 스킵 케이스 포함  
  - `skipped=true, reason="cooldown", wait_ms=...`
  - `skipped=true, reason="in_progress", since_ms=...`

---

## 4) 화면별 “최소 호출 세트” (P0 구현용)
> 아래대로만 구현해도 앱이 끊기지 않고 운영 가능한 MVP가 됩니다.

### 4.1 앱 시작(Startup)
1. `rpc/get_current_app_version`
2. `rpc/get_dashboard` (프리로드)
3. (선택) `market_data_sync_runs` 최신 1건 조회(상태 배지 보강)

### 4.2 홈(Dashboard)
- 1차: `rpc/get_dashboard`
- 2차(차트/지표):  
  - `GET v_portfolio_nav_daily?trading_date=gte.<from>&trading_date=lte.<to>&order=trading_date.asc`  
  - `GET v_portfolio_metrics?order=asof_date.desc&limit=1`
- 새로고침: `rpc/get_dashboard` 재호출 + 필요 시 `sync_me` 버튼 제공

### 4.3 거래 리스트(Transactions)
- 목록: `GET v_transactions_display` (기간/필터/페이지네이션)
- 상세/감사: `GET v_transactions_with_info` (transaction_id로 1건 조회)

### 4.4 거래 입력(쓰기)
- 생성: `rpc/process_transaction_v2` (**p_client_tx_id 필수**)  
- 수정: `rpc/edit_transaction_v2` (**p_client_tx_id 권장**)  
- 취소: `rpc/reverse_transaction`  
- 성공 후: `rpc/get_dashboard` 재호출(홈 KPI 동기화)

### 4.5 자산(Assets)
- 계좌별: `GET v_account_nav_daily`(날짜/기간)
- 종목별: `GET v_account_stock_nav_daily`(날짜/기간)
- 실현손익: `GET stock_realized_pnl`(필터/정렬)

### 4.6 성과(Performance)
- 월 수익률: `GET portfolio_returns_monthly`
- 리스크: `GET v_portfolio_metrics`
- (패치 적용 시) 요약: `rpc/get_returns_summary`

### 4.7 정합성(Integrity)
- 큐: `GET daily_snapshot_recalc_queue` (count/범위 표시)
- 요청: `rpc/request_snapshot_recalc(from,to,reason)`  
  - ⚠️ 31일 제한 UI에서도 막기(서버도 거절)

### 4.8 설정(Settings)
- 마스터 CRUD: `accounts/cards/categories/fixed_expenses/liabilities`
- 상태: `market_data_sync_runs` 최근 N건 리스트(성공/부분/실패 표시)

---

## 5) 프론트에서 “실수하면 바로 사고 나는” 규칙 6개
1. **CRON_SECRET / SERVICE_ROLE_KEY 앱에 절대 포함 금지**
2. `transactions/account_balances/holdings/stats` 직접 쓰기 금지 → 항상 RPC
3. `sync_me`는 Body DTO가 아니라 **Query `market=`** 로 제어(Body 비우기 권장)
4. 거래 입력/수정은 **client_tx_id(멱등키)** 를 항상 넣기(연타/재시도 방어)
5. 재계산 요청은 **최대 31일**(UI에서도 제한)
6. `get_dashboard`는 “요약”만. 차트/리스크는 별도 조회(View)로 분리

---

## 6) (옵션) 설치 검증용 3분 체크 SQL
```sql
select to_regprocedure('public.get_returns_summary()') is not null as has_get_returns_summary;
select public.get_dashboard(5, true);
select
  has_function_privilege('authenticated', 'public.update_portfolio_metrics(uuid,date,int)', 'EXECUTE') as auth_can_update_metrics,
  has_function_privilege('authenticated', 'public.kis_token_decide(text)', 'EXECUTE') as auth_can_kis_token;
```

---

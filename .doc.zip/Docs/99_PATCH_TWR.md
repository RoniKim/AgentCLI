



## 패치 문서: Returns Summary(TWR)
- 원본: `PAD_v2.3.5_patch_returns_twr_2026-01-30.md`

## PAD v2.3.5 패치 문서: 수익률 지표 분리 (순자산 증감률 vs 투자성과 TWR)

### 0. 목적
현재 시스템의 “누적 수익률”은 **NAV(순자산) 기반**이므로,
- 실현손익(매도/배당 등)은 **포함**되지만
- 외부 현금흐름(수입/지출/대출 실행/상환 등)도 **함께 섞여** 들어갑니다.

따라서 사용자 관점에서 혼동이 생깁니다.

이번 패치의 목표는 지표를 2개로 분리하는 것입니다.

- **순자산 증감률 (Networth Return)**: “내 자산이 실제로 늘었나?”
- **투자성과 (TWR, Time-Weighted Return)**: “입출금 효과 제거한 투자 실력”

---

### 1. Path SQL

#### 1.1 Patch SQL 파일
- **파일명:** `PAD_v2.3.5_patch_returns_twr_2026-01-30.sql`
- **역할:** 아래 객체들을 추가/교체
  - `public.ctx_uid()` (테스트용 UID fallback)
  - `public.v_portfolio_assets_daily` (자산 시계열)
  - `public.v_external_cashflow_daily` (외부 현금흐름 시계열)
  - `public.v_portfolio_twr_daily` (TWR 일별/누적 시계열)
  - `public.get_returns_summary()` (프론트 1회 호출용 요약 RPC)

> **권장 저장 경로(Repo 기준 예시)**  
> - `/db/patches/PAD_v2.3.5_patch_returns_twr_2026-01-30.sql`  
> - 또는 `/supabase/migrations/<timestamp>_returns_twr.sql` (프로젝트 운영 방식에 맞춰 선택)

---

### 2. Patch 내용 (무엇을 바꿨나)

#### 2.1 `public.ctx_uid()` (SQL Editor 테스트 지원)
- production(PostgREST/앱): `auth.uid()` 사용
- SQL Editor(비인증 실행): `set_config('app.user_id','<uuid>',true)`로 UID 주입 가능

```sql
select set_config('app.user_id', '<YOUR-UUID>', true);
select * from public.get_returns_summary();
```

#### 2.2 `public.v_portfolio_assets_daily` (자산 시계열)
- Snapshot 우선:
  - `account_nav_daily` 합계(계좌 `is_include_in_networth = true`만)
- Snapshot이 오늘 없을 때 Live fallback:
  - `stats.krw_cash_total + stats.usd_value_krw + stats.stock_value_krw`

출력 컬럼(핵심):
- `trading_date`
- `assets_krw`
- `source`, `is_snapshot`

#### 2.3 `public.v_external_cashflow_daily` (외부 현금흐름)
기본 정책(조정 가능):
- 외부 유입(+): `수입`, `대출_실행`
- 외부 유출(-): `지출`, `카드_대금`, `대출_상환_원금`, `대출_상환_이자`

> 카드 사용(카드 결제 거래)은 순자산에 즉시 반영되지 않는 구조이므로  
> 외부흐름에서는 “카드 사용”이 아니라 **`카드_대금`만** 포함하는 것을 기본으로 둠.

환산:
- KRW: 그대로
- USD 등: `t.fx_rate` → 없으면 `fx_rates_daily` → 없으면 `fx_rates` fallback으로 USDKRW 적용

#### 2.4 `public.v_portfolio_twr_daily` (투자성과 TWR)
일별 수익률:
- `r_t = (A_t - A_{t-1} - Flow_t) / A_{t-1}`  
  (A=자산, Flow=외부 현금흐름)

누적 수익률:
- `TWR Index = Π(1 + r_t) = exp( Σ ln(1 + r_t) )`

구현 포인트:
- 재귀 CTE를 쓰지 않고 **윈도우 함수(sum/min)**로 누적 계산(운영 안정성/성능 유리)
- `exp/ln`은 `double precision` → `round( , digits )`를 위해 `numeric` 캐스팅 처리

#### 2.5 `public.get_returns_summary()` (프론트 1회 호출용)
반환 지표:
- `networth_*` : 기존 `v_portfolio_nav_daily` 기반 (순자산 증감률)
- `twr_*`      : `v_portfolio_twr_daily` 기반 (투자성과)

주의(PL/pgSQL):
- `returns table(...)`의 컬럼명은 PL/pgSQL 변수로도 존재 →  
  내부 SELECT에서 `alias.column` 형태로 완전 수식(ambiguous 방지)

---

### 3. API 업데이트

#### 3.1 RPC 추가: `get_returns_summary`
- **HTTP**
  - `POST /rest/v1/rpc/get_returns_summary`
- **Request Body**
  - 없음 (`{}` 또는 body 생략)
- **Response (단일 row)**
```json
{
  "asof": "2026-01-30",
  "networth_krw": 12345678.90,
  "networth_daily_pct": 2.3,
  "networth_mtd_pct": 8.7,
  "networth_ytd_pct": 15.2,
  "networth_cum_pct": 8.35,
  "assets_krw": 22345678.90,
  "external_flow_today_krw": -500000.00,
  "twr_daily_pct": 1.1,
  "twr_mtd_pct": 3.4,
  "twr_ytd_pct": 9.9,
  "twr_cum_pct": 12.3
}
```

#### 3.2 프론트 표시 권장
- **“누적 수익률” UI를 2개로 분리**
  - `누적 순자산 증감률` → `networth_cum_pct`
  - `누적 투자성과(TWR)` → `twr_cum_pct`
- “오늘 외부현금흐름”을 함께 표시하면 해석이 쉬움
  - 예: `external_flow_today_krw = -500,000` → “오늘 입출금 -50만원”

#### 3.3 초기 데이터가 없을 때 처리(UI)
- DB에 `stats` row, `portfolio_nav_daily` 스냅샷이 없으면 값이 `null`이 정상.
- UI에서는 다음 정책 권장:
  - 금액: `0` 또는 빈 상태 문구
  - 퍼센트: `N/A` (전일/기준일 데이터 없음)

---

### 4. 운영/테스트 가이드

#### 4.1 SQL Editor 테스트(비인증)
```sql
select set_config('app.user_id', '<YOUR-UUID>', true);
select * from public.get_returns_summary();
```

#### 4.2 앱/MAUI 테스트(인증)
- 앱 로그인 후 동일 RPC 호출
- SQL Editor fallback 없이 `auth.uid()`로만 동작

---

### 5. 변경 이력
- 2026-01-30: 최초 작성
  - TWR 계산: 재귀 CTE → 윈도우 함수 기반으로 확정
  - round(double precision, digits) 이슈 → numeric 캐스팅으로 해결
  - PL/pgSQL ambiguous 이슈 → alias.column 완전 수식으로 해결

---

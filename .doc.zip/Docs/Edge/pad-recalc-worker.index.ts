// =========================================================
// PAD Edge Function: pad-recalc-worker (v2.3.5 RELEASE)
// Date: 2026-01-29 (KST)
// Purpose:
//  - Consume daily_snapshot_recalc_queue and call rebuild_daily_snapshots (service-role)
//  - Write run logs to snapshot_recalc_runs (optional)
// Security:
//  - Scheduled/Cron only: requires x-cron-secret header
// =========================================================

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

type Json = Record<string, unknown>;

function json(status: number, body: Json) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}

function toKstDateString(d: Date): string {
  // Convert to Asia/Seoul date (YYYY-MM-DD) without external libs
  const kst = new Date(d.getTime() + 9 * 60 * 60 * 1000);
  const yyyy = kst.getUTCFullYear();
  const mm = String(kst.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(kst.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function addDays(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split("-").map((x) => Number(x));
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() + days);
  const yyyy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function groupContiguous(dates: string[]): Array<{ from: string; to: string; count: number }> {
  if (dates.length === 0) return [];
  const sorted = [...dates].sort();
  const groups: Array<{ from: string; to: string; count: number }> = [];
  let from = sorted[0];
  let to = sorted[0];
  let count = 1;

  for (let i = 1; i < sorted.length; i++) {
    const expected = addDays(to, 1);
    if (sorted[i] === expected) {
      to = sorted[i];
      count++;
    } else {
      groups.push({ from, to, count });
      from = sorted[i];
      to = sorted[i];
      count = 1;
    }
  }
  groups.push({ from, to, count });
  return groups;
}

serve(async (req) => {
  try {
    const url = new URL(req.url);
    const op = url.searchParams.get("op") ?? "run";

    const cronSecret = Deno.env.get("CRON_SECRET") ?? Deno.env.get("PAD_CRON_SECRET") ?? "";
    const gotSecret = req.headers.get("x-cron-secret") ?? "";
    if (!cronSecret || gotSecret !== cronSecret) {
      return json(401, { ok: false, error: "unauthorized" });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("PROJECT_URL") ?? "";
    const serviceKey = Deno.env.get("SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    if (!supabaseUrl || !serviceKey) {
      return json(500, { ok: false, error: "missing_env(SUPABASE_URL|PROJECT_URL / SERVICE_ROLE_KEY)" });
    }

    const sb = createClient(supabaseUrl, serviceKey, {
      auth: { persistSession: false },
      global: {
        headers: {
          apikey: serviceKey,
          Authorization: `Bearer ${serviceKey}`,
          "X-Client-Info": "pad-recalc-worker/2.3.5",
        },
      },
    });

    if (op !== "run") {
      return json(400, { ok: false, error: "unsupported_op", op });
    }

    const todayKst = toKstDateString(new Date());
    const maxUsers = Number(Deno.env.get("RECALC_MAX_USERS") ?? "20");
    const maxDatesPerUser = Number(Deno.env.get("RECALC_MAX_DATES_PER_USER") ?? "31");

    // 1) find users who have pending recalc (past dates only)
    const { data: users, error: userErr } = await sb
      .from("daily_snapshot_recalc_queue")
      .select("user_id")
      .lt("trading_date", todayKst)
      .order("created_at", { ascending: true })
      .limit(2000);

    if (userErr) return json(500, { ok: false, error: "queue_select_failed", detail: userErr.message });

    const userIds = Array.from(new Set((users ?? []).map((x) => x.user_id))).slice(0, maxUsers);
    const summary: Json = { ok: true, today_kst: todayKst, users: userIds.length, processed: [] as unknown[] };

    for (const userId of userIds) {
      // 2) fetch dates for that user (bounded)
      const { data: rows, error: qErr } = await sb
        .from("daily_snapshot_recalc_queue")
        .select("trading_date, reason")
        .eq("user_id", userId)
        .lt("trading_date", todayKst)
        .order("trading_date", { ascending: true })
        .limit(maxDatesPerUser);

      if (qErr) {
        (summary.processed as unknown[]).push({ user_id: userId, ok: false, error: qErr.message });
        continue;
      }

      const dates = (rows ?? []).map((r) => r.trading_date as string);
      const groups = groupContiguous(dates);

      // Optional: create run log row
      let runId: string | null = null;
      try {
        const { data: run, error: runErr } = await sb
          .from("snapshot_recalc_runs")
          .insert({
            user_id: userId,
            status: "STARTED",
            from_date: groups[0]?.from ?? null,
            to_date: groups[groups.length - 1]?.to ?? null,
            items_total: dates.length,
          })
          .select("run_id")
          .single();
        if (!runErr) runId = run?.run_id ?? null;
      } catch (_) {
        // table may not exist (optional)
      }

      let totalSuccess = 0;
      let totalFail = 0;
      const segResults: unknown[] = [];

      for (const g of groups) {
        // 3) rebuild that contiguous range
        const { error: rpcErr } = await sb.rpc("rebuild_daily_snapshots", {
          p_user_id: userId,
          p_from_date: g.from,
          p_to_date: g.to,
          p_source: "REBUILD_WORKER",
        });

        if (rpcErr) {
          totalFail += g.count;
          segResults.push({ from: g.from, to: g.to, count: g.count, ok: false, error: rpcErr.message });
          continue;
        }

        // 4) determine remaining failures in that segment (queue rows still present)
        const { data: remain, error: rErr } = await sb
          .from("daily_snapshot_recalc_queue")
          .select("trading_date", { count: "exact" })
          .eq("user_id", userId)
          .gte("trading_date", g.from)
          .lte("trading_date", g.to);

        const remaining = rErr ? g.count : (remain?.length ?? 0);
        const success = Math.max(0, g.count - remaining);
        const fail = g.count - success;

        totalSuccess += success;
        totalFail += fail;

        segResults.push({ from: g.from, to: g.to, count: g.count, ok: true, success, fail });
      }

      // Optional: finish run log
      if (runId) {
        const status = totalFail === 0 ? "SUCCESS" : totalSuccess > 0 ? "PARTIAL" : "FAILED";
        try {
          await sb.from("snapshot_recalc_runs").update({
            status,
            finished_at: new Date().toISOString(),
            items_success: totalSuccess,
            items_failed: totalFail,
            message: totalFail === 0 ? null : "Some dates remain in recalc queue (see daily_snapshot_recalc_queue.reason)",
          }).eq("run_id", runId);
        } catch (_) {
          // ignore
        }
      }

      (summary.processed as unknown[]).push({
        user_id: userId,
        dates: dates.length,
        groups: segResults,
        success: totalSuccess,
        fail: totalFail,
      });
    }

    return json(200, summary);
  } catch (e) {
    return json(500, { ok: false, error: "unhandled", detail: String(e) });
  }
});

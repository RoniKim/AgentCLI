// FINAL BUILD ARTIFACT (RELEASE)
// - Version: v2.3.5
// - Date: 2026-01-30
// - Requires DB: PAD_v2.3.5_FULL_SCHEMA_RELEASE_2026-01-30.sql (kis_token_cache.access_token_enc + kis_token_* RPC)
// ------------------------------------------------------------


// index.ts (Supabase Edge Function) - pad-market-sync
//
// Features
// - op=ensure_stock
//    * User mode: Authorization Bearer <user access_token> (RLS-safe)
//    * Server/Test mode: x-cron-secret == CRON_SECRET AND body.user_id (uuid)
// - op=sync_me (user manual sync): Authorization Bearer <user access_token> (returns SUCCESS/FAILED/PARTIAL)
// - op=sync (server-only): x-cron-secret == CRON_SECRET
//
// Market data sources
// - FX (USDKRW): Frankfurter https://frankfurter.dev/
// - Stock price: Korea Investment & Securities (KIS) Open API
//
// IMPORTANT (Supabase setting)
// - This function MUST have "Verify JWT" disabled (verify_jwt=false).
//   Because server calls (cron/ops) use x-cron-secret, not a user JWT.
//   Dashboard: Edge Functions -> pad-market-sync -> Settings -> Verify JWT OFF
//
// Security note
// - NEVER put CRON_SECRET in MAUI app. Server-only.

import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

// NOTE (v2.3.2 ENV):
// - Edge Secrets cannot be created with SUPABASE_* prefix via UI.
// - Use SERVICE_ROLE_KEY for service role JWT (required for rebuild/daily_close server ops).
// - Use CRON_SECRET for server-only calls (x-cron-secret header).
import iconv from "https://esm.sh/iconv-lite@0.6.3";
type Market = "KR" | "US";
type SyncMarket = "KR" | "US" | "ALL";

const FRANKFURTER_URL = "https://api.frankfurter.dev/v1/latest?base=USD&symbols=KRW";

function env(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}




// -------------------- Request JSON parsing (client payload is always UTF-8) --------------------
async function readBodyJson(req: Request): Promise<any> {
  const ct = (req.headers.get("content-type") ?? "").toLowerCase();
  if (ct.includes("application/json")) {
    try { return await req.json(); } catch { /* fallthrough */ }
  }
  const txt = await req.text();
  if (!txt) return {};
  try { return JSON.parse(txt); } catch { return {}; }
}

// -------------------- Token Crypto (AES-GCM, Edge-side only) --------------------
// Stores ciphertext in DB (kis_token_cache.access_token_enc). DB never sees plaintext.
function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}
function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function aesKeyFromPassphrase(pass: string): Promise<CryptoKey> {
  const raw = new TextEncoder().encode(pass);
  const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", raw));
  return crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
async function encryptToken(plain: string): Promise<string> {
  const key = await aesKeyFromPassphrase(env("KIS_TOKEN_CRYPTO_KEY"));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(plain)));
  const payload = new Uint8Array(iv.length + ct.length);
  payload.set(iv, 0);
  payload.set(ct, iv.length);
  return `v1:${bytesToBase64(payload)}`;
}
async function decryptToken(enc: string): Promise<string> {
  if (!enc) throw new Error("Empty encrypted token");
  if (!enc.startsWith("v1:")) throw new Error("Unsupported token format");
  const bytes = base64ToBytes(enc.slice(3));
  const iv = bytes.subarray(0, 12);
  const ct = bytes.subarray(12);
  const key = await aesKeyFromPassphrase(env("KIS_TOKEN_CRYPTO_KEY"));
  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, ct);
  return new TextDecoder().decode(pt);
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-cron-secret",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
}



function looksMojibake(s: string): boolean {
  if (!s) return false;
  if (s.includes("�")) return true;
  const q = s.replace(/[\s]/g, "");
  if (q.length >= 2 && /^[?]+$/.test(q)) return true;
  return false;
}

async function parseJsonKis(resp: Response): Promise<any> {
  const buf = new Uint8Array(await resp.arrayBuffer());
  const ct = (resp.headers.get("content-type") ?? "").toLowerCase();
  const hasEuc = ct.includes("euc-kr") || ct.includes("cp949") || ct.includes("ks_c_5601-1987");

  let text = new TextDecoder("utf-8").decode(buf);
  if (hasEuc || text.includes("�")) {
    try { text = iconv.decode(buf as any, "euc-kr"); } catch {}
  }
  try { return JSON.parse(text); } catch {}

  // last resort
  const t2 = iconv.decode(buf as any, "euc-kr");
  return JSON.parse(t2);
}
function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders(), "Content-Type": "application/json; charset=utf-8" },
  });
}

function isUuid(v: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);
}

function asNumber(v: unknown): number | null {
  const n = typeof v === "number" ? v : Number.parseFloat(String(v ?? ""));
  return Number.isFinite(n) ? n : null;
}

async function fetchJson(url: string, init: RequestInit, timeoutMs = 12_000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort("timeout"), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: ac.signal });
    const text = await res.text();
    let body: any;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = text;
    }
    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}: ${text}`);
    return body;
  } finally {
    clearTimeout(t);
  }
}



// -------------------- KIS fetch (handles EUC-KR/CP949 JSON) --------------------
async function fetchKisJson(url: string, init: RequestInit, timeoutMs = 12_000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort("timeout"), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: ac.signal });
    const body = await parseJsonKis(res.clone());
    if (!res.ok) {
      throw new Error(`HTTP ${res.status} ${res.statusText}: ${JSON.stringify(body)}`);
    }
    return body;
  } finally {
    clearTimeout(t);
  }
}

async function mapLimit<T, R>(items: T[], limit: number, fn: (t: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let idx = 0;
  const workers = Array.from({ length: Math.max(1, limit) }, async () => {
    while (true) {
      const i = idx++;
      if (i >= items.length) break;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}

function kisEnv(): string {
  return (Deno.env.get("KIS_ENV") ?? "prod").toLowerCase();
}
function isVts(): boolean {
  const e = kisEnv();
  return e.includes("vts") || e.includes("mock") || e.includes("test");
}
function kisBaseUrl(): string {
  return isVts()
    ? "https://openapivts.koreainvestment.com:29443"
    : "https://openapi.koreainvestment.com:9443";
}

function sbAdmin() {
  const url = env("SUPABASE_URL");
  const serviceKey = Deno.env.get("SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
  if (!serviceKey) throw new Error("Missing env: SERVICE_ROLE_KEY");
  // Force service-role JWT on every request (do not rely on defaults)
  return createClient(url, serviceKey, {
    auth: { persistSession: false },
    global: { headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` } },
  });
}

function sbUser(req: Request) {
  const url = env("SUPABASE_URL");
  const anon = env("SUPABASE_ANON_KEY"); // Supabase Edge 기본 제공
  const auth = req.headers.get("authorization") ?? "";
  return createClient(url, anon, { global: { headers: { authorization: auth } } });
}


// -------------------- market_data_sync_runs insert helper (provider fallback) --------------------
function isMissingProviderColumn(err: any): boolean {
  const code = String(err?.code ?? "");
  const msg = String(err?.message ?? err?.details ?? err?.hint ?? err ?? "");
  // Postgres undefined_column is 42703
  if (code === "42703" && msg.includes("provider")) return true;
  if (msg.includes('column "provider"') && msg.includes("market_data_sync_runs")) return true;
  if (msg.includes("market_data_sync_runs") && msg.includes("provider") && msg.includes("does not exist")) return true;
  return false;
}

async function insertSyncRunWithFallback(admin: any, payload: Record<string, any>) {
  // 1) try with provider (preferred)
  const { data, error } = await admin
    .from("market_data_sync_runs")
    .insert(payload)
    .select("run_id")
    .single();

  if (!error) return data;

  // 2) provider missing -> fail-fast (provider column is mandatory in v2.3)
  if (isMissingProviderColumn(error)) {
    throw new Error(
      'DB schema mismatch: public.market_data_sync_runs.provider column is missing. Apply the full SQL (v2.3) before deploying the Edge Function.'
    );
  }

  // 3) other errors
  throw error;
}

// -------------------- KIS Token Manager (DB의 kis_token_* 사용; 1분룰 포함) --------------------

function computeKisExpiresAtIso(expiresInSeconds: number, tokenExpiredRaw: string): string {
  const now = Date.now();

  // KIS may provide an explicit expiry timestamp (KST) like "YYYY-MM-DD HH:MM:SS".
  // Prefer it over expires_in to avoid unnecessary refresh attempts.
  let expiryMs: number | null = null;

  const m = /^([0-9]{4})-([0-9]{2})-([0-9]{2})[ T]([0-9]{2}):([0-9]{2}):([0-9]{2})$/.exec(
    tokenExpiredRaw.trim(),
  );
  if (m) {
    const isoKst = `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}+09:00`;
    const d = new Date(isoKst);
    const t = d.getTime();
    if (!Number.isNaN(t) && t > 0) expiryMs = t;
  }

  if (expiryMs === null) {
    if (!Number.isFinite(expiresInSeconds) || expiresInSeconds <= 0) {
      throw new Error(
        `Bad token response: missing/invalid expires_in and access_token_token_expired (${JSON.stringify({
          expires_in: expiresInSeconds,
          access_token_token_expired: tokenExpiredRaw,
        })})`,
      );
    }
    expiryMs = now + Math.floor(expiresInSeconds * 1000);
  }

  // Safety margin: refresh 60 seconds earlier, but never produce an already-expired timestamp.
  const safeMs = Math.max(now + 60_000, expiryMs - 60_000);
  return new Date(safeMs).toISOString();
}

class KisTokenManager {
  constructor(
    private sb: ReturnType<typeof createClient>,
    private owner: string,
  ) {}

  async getAccessToken(): Promise<string> {
    for (let attempt = 0; attempt < 12; attempt++) {
      const { data, error } = await this.sb.rpc("kis_token_decide", { p_owner: this.owner });
      if (error) throw error;

      const action = String((data as any)?.action ?? "");
      if (action === "USE_CACHE") return await decryptToken(String((data as any).access_token_enc));

      if (action === "WAIT") {
        const w = Math.max(1, Number((data as any).wait_seconds ?? 3));
        await new Promise((r) => setTimeout(r, w * 1000));
        continue;
      }

      if (action === "REFRESH_ALLOWED") {
        try {
          const tok = await fetchJson(`${kisBaseUrl()}/oauth2/tokenP`, {
            method: "POST",
            headers: { "Content-Type": "application/json; charset=utf-8" },
            body: JSON.stringify({
              grant_type: "client_credentials",
              appkey: env("KIS_APP_KEY"),
              appsecret: env("KIS_APP_SECRET"),
            }),
          });
          const accessToken = String(tok?.access_token ?? "");
          const expiresIn = Number(tok?.expires_in ?? 0);
          const tokenExpiredRaw = String(tok?.access_token_token_expired ?? "").trim();

          if (!accessToken) throw new Error(`Bad token response: ${JSON.stringify(tok)}`);

          const expiresAt = computeKisExpiresAtIso(expiresIn, tokenExpiredRaw);
          const { error: e2 } = await this.sb.rpc("kis_token_finish_refresh", {
            p_owner: this.owner,
            p_access_token_enc: await encryptToken(accessToken),
            p_expires_at: expiresAt,
          });
          if (e2) throw e2;

          return accessToken;
        } catch (e) {
          await this.sb.rpc("kis_token_fail_refresh", { p_owner: this.owner, p_error: String(e) });
          throw e;
        }
      }

      throw new Error(`Unknown kis_token_decide action: ${JSON.stringify(data)}`);
    }

    throw new Error("Failed to obtain KIS token (too many waits)");
  }
}

function kisHeaders(accessToken: string, trId: string) {
  return {
    "Content-Type": "application/json; charset=utf-8",
    authorization: `Bearer ${accessToken}`,
    appkey: env("KIS_APP_KEY"),
    appsecret: env("KIS_APP_SECRET"),
    tr_id: trId,
    custtype: Deno.env.get("KIS_CUSTTYPE") ?? "P",
  };
}

// 국내 현재가
async function kisDomesticPrice(accessToken: string, ticker6: string): Promise<number> {
  const url =
    `${kisBaseUrl()}/uapi/domestic-stock/v1/quotations/inquire-price` +
    `?FID_COND_MRKT_DIV_CODE=J&FID_INPUT_ISCD=${encodeURIComponent(ticker6)}`;
  const body = await fetchKisJson(url, { method: "GET", headers: kisHeaders(accessToken, "FHKST01010100") });
  const price = asNumber(body?.output?.stck_prpr);
  if (!price || price <= 0) throw new Error(`KIS KR bad price for ${ticker6}: ${JSON.stringify(body?.output)}`);
  return price;
}

// 국내 종목 기본정보(종목명 확보) - 인코딩 이슈를 원천 제거하기 위해 서버가 authoritative name을 저장
async function kisDomesticBasicInfo(accessToken: string, ticker6: string) {
  const url =
    `${kisBaseUrl()}/uapi/domestic-stock/v1/quotations/search-stock-info` +
    `?PRDT_TYPE_CD=300&PDNO=${encodeURIComponent(ticker6)}`;

  const body = await fetchKisJson(url, { method: "GET", headers: kisHeaders(accessToken, "CTPF1002R") });
  const out = body?.output ?? {};

  const abrv = String(out?.prdt_abrv_name ?? "").trim();
  const full = String(out?.prdt_name ?? "").trim();

  return {
    name: abrv || full || ticker6,
    prdt_abrv_name: abrv || null,
    prdt_name: full || null,
  };
}

// 해외 현재가 상세(실전만 가능)
async function kisOverseasPrice(accessToken: string, excd: string, symb: string): Promise<number> {
  if (isVts()) throw new Error("KIS_ENV=vts 환경에서는 해외주식(US) 현재가상세가 미지원입니다. prod로 실행하세요.");

  const makeUrl = (auth: string) =>
    `${kisBaseUrl()}/uapi/overseas-price/v1/quotations/price-detail` +
    `?AUTH=${encodeURIComponent(auth)}&EXCD=${encodeURIComponent(excd)}&SYMB=${encodeURIComponent(symb)}`;

  // AUTH는 문서 상 required인데 실제 값 설명이 빈 케이스가 있어 ""→"0" 방어
  try {
    const body = await fetchKisJson(makeUrl(""), { method: "GET", headers: kisHeaders(accessToken, "HHDFS76200200") });
    const price = asNumber(body?.output?.last);
    if (!price || price <= 0) throw new Error("bad");
    return price;
  } catch {
    const body = await fetchKisJson(makeUrl("0"), { method: "GET", headers: kisHeaders(accessToken, "HHDFS76200200") });
    const price = asNumber(body?.output?.last);
    if (!price || price <= 0) throw new Error(`KIS US bad price for ${symb}(${excd}): ${JSON.stringify(body?.output)}`);
    return price;
  }
}

function prdtTypeFromExcd(excd: string): string | null {
  // SQL 예시 기준(512 NASDAQ / 513 NYSE / 529 AMEX)
  switch (excd) {
    case "NAS":
      return "512";
    case "NYS":
      return "513";
    case "AMS":
      return "529";
    default:
      return null;
  }
}

async function tryDetectUsExcd(accessToken: string, symb: string) {
  const candidates = ["NAS", "NYS", "AMS"];
  for (const excd of candidates) {
    try {
      const price = await kisOverseasPrice(accessToken, excd, symb);
      return { excd, price, prdtType: prdtTypeFromExcd(excd) };
    } catch {
      // continue
    }
  }
  throw new Error(`US ticker "${symb}"를 NAS/NYS/AMS에서 찾지 못했습니다. (티커/상장시장 확인 필요)`);
}

// -------------------- FX (Frankfurter) --------------------
async function fetchUsdKrw(): Promise<number> {
  const fx = await fetchJson(FRANKFURTER_URL, { method: "GET" });
  const rate = asNumber(fx?.rates?.KRW);
  if (!rate || rate <= 0) throw new Error(`Frankfurter bad rate: ${JSON.stringify(fx)}`);
  return rate;
}

// -------------------- op=ensure_stock --------------------
async function ensureStock(req: Request) {
  const auth = req.headers.get("authorization") ?? "";
  const cronHeader = req.headers.get("x-cron-secret") ?? "";
  const cronSecret = Deno.env.get("CRON_SECRET") ?? "";

    const body = await readBodyJson(req);
  const ticker = String(body?.ticker ?? "").trim();
  const market = String(body?.market ?? "").toUpperCase() as Market;
  const requestedName = String(body?.name ?? "").trim();
  const note = body?.note == null ? null : String(body.note);

  if (!ticker) return json({ ok: false, error: "ticker is required" }, 400);
  if (market !== "KR" && market !== "US") return json({ ok: false, error: "market must be KR or US" }, 400);

  // ---------- User mode: Authorization 필요 ----------
  if (auth.startsWith("Bearer ")) {
    const userClient = sbUser(req);
    const { data: u, error: ue } = await userClient.auth.getUser();
    if (ue || !u?.user) return json({ ok: false, error: "Unauthorized" }, 401);

    const admin = sbAdmin();
    const tokenMgr = new KisTokenManager(admin, Deno.env.get("KIS_TOKEN_OWNER") ?? "kis:default");
    const accessToken = await tokenMgr.getAccessToken();

    let currency: "KRW" | "USD" = market === "KR" ? "KRW" : "USD";
    let kis_excd: string | null = null;
    let kis_prdt_type_cd: string | null = null;
    let latestPrice: number | null = null;

    // authoritative name (KR: from KIS; US: from client fallback)
    let resolvedName = requestedName || ticker;

    if (market === "KR") {
      if (!/^\d{6}$/.test(ticker)) return json({ ok: false, error: "KR ticker must be 6 digits (예: 005930)" }, 400);
      const bi = await kisDomesticBasicInfo(accessToken, ticker);
      resolvedName = bi.name;
      if (looksMojibake(resolvedName) && requestedName) {
        resolvedName = requestedName;
      }
      latestPrice = await kisDomesticPrice(accessToken, ticker);
    } else {
      if (isVts()) return json({ ok: false, error: "KIS_ENV=vts 환경에서는 US 현재가 조회 불가. prod로 변경 필요" }, 400);
      const detected = await tryDetectUsExcd(accessToken, ticker);
      kis_excd = detected.excd;
      kis_prdt_type_cd = detected.prdtType;
      latestPrice = detected.price;
    }

    const upsertPayload: any = {
      ticker,
      name: resolvedName,
      market,
      currency,
      note,
      kis_excd,
      kis_prdt_type_cd,
    };

    const { data: saved, error: e2 } = await userClient
      .from("stocks")
      .upsert(upsertPayload, { onConflict: "user_id,ticker" })
      .select("stock_id,ticker,name,market,currency,kis_prdt_type_cd,kis_excd,kis_tr_mket_cd,note")
      .single();
    if (e2) throw e2;

    if (latestPrice && latestPrice > 0) {
      await admin.from("stock_prices").upsert({
        user_id: u.user.id,
        stock_id: saved.stock_id,
        price: latestPrice,
        currency,
        source: "KIS",
        updated_at_source: new Date().toISOString(),
      }, { onConflict: "user_id,stock_id" });
    }

    return json({ ok: true, mode: "user", stock: saved, latestPrice });
  }

  // ---------- Server/Test mode: x-cron-secret + user_id ----------
  if (!cronSecret || cronHeader !== cronSecret) {
    return json({ ok: false, error: "Missing authorization header" }, 401);
  }

  const userId = String(body?.user_id ?? "").trim();
  if (!isUuid(userId)) return json({ ok: false, error: "server mode requires valid user_id(uuid)" }, 400);

  const admin = sbAdmin();
  const tokenMgr = new KisTokenManager(admin, Deno.env.get("KIS_TOKEN_OWNER") ?? "kis:default");
  const accessToken = await tokenMgr.getAccessToken();

  let currency: "KRW" | "USD" = market === "KR" ? "KRW" : "USD";
  let kis_excd: string | null = null;
  let kis_prdt_type_cd: string | null = null;
  let latestPrice: number | null = null;

  // authoritative name (KR: from KIS; US: from client fallback)
  let resolvedName = requestedName || ticker;

  // price caching (avoid spamming KIS when importing many tickers quickly)
  const forceRefresh = Boolean(body?.force_refresh ?? false);
  const priceTtlSec = Math.max(0, Number(body?.price_ttl_seconds ?? 60));
  let cacheHit = false;

  if (!forceRefresh && priceTtlSec > 0) {
    const { data: exStock } = await admin
      .from("stocks")
      .select("stock_id,name,market,currency,kis_prdt_type_cd,kis_excd,kis_tr_mket_cd")
      .eq("user_id", userId)
      .eq("ticker", ticker)
      .maybeSingle();

    if (exStock?.stock_id && String((exStock as any).market).toUpperCase() === market) {
      const { data: exPrice } = await admin
        .from("stock_prices")
        .select("price,updated_at_source,currency")
        .eq("user_id", userId)
        .eq("stock_id", String((exStock as any).stock_id))
        .maybeSingle();

      const updatedAt = (exPrice as any)?.updated_at_source ? new Date((exPrice as any).updated_at_source).getTime() : 0;
      if (updatedAt && (Date.now() - updatedAt) <= priceTtlSec * 1000) {
        resolvedName = String((exStock as any).name ?? resolvedName);
        currency = market === "KR" ? "KRW" : "USD";
        kis_prdt_type_cd = (exStock as any).kis_prdt_type_cd ?? null;
        kis_excd = (exStock as any).kis_excd ?? null;
        latestPrice = asNumber((exPrice as any)?.price) ?? null;
        cacheHit = latestPrice != null;
      }
    }
  }

  if (!cacheHit && market === "KR") {
    if (!/^\d{6}$/.test(ticker)) return json({ ok: false, error: "KR ticker must be 6 digits (예: 005930)" }, 400);
    const bi = await kisDomesticBasicInfo(accessToken, ticker);
    resolvedName = bi.name;
      if (looksMojibake(resolvedName) && requestedName) {
        resolvedName = requestedName;
      }
    latestPrice = await kisDomesticPrice(accessToken, ticker);
  } else if (!cacheHit) {
    if (isVts()) return json({ ok: false, error: "KIS_ENV=vts 환경에서는 US 현재가 조회 불가. prod로 변경 필요" }, 400);
    const detected = await tryDetectUsExcd(accessToken, ticker);
    kis_excd = detected.excd;
    kis_prdt_type_cd = detected.prdtType;
    latestPrice = detected.price;
  }

  const upsertPayload: any = {
    user_id: userId,
    ticker,
    name: resolvedName,
    market,
    currency,
    note,
    kis_excd,
    kis_prdt_type_cd,
  };

  const { data: saved, error: e2 } = await admin
    .from("stocks")
    .upsert(upsertPayload, { onConflict: "user_id,ticker" })
    .select("stock_id,user_id,ticker,name,market,currency,kis_prdt_type_cd,kis_excd,kis_tr_mket_cd,note")
    .single();
  if (e2) throw e2;

  if (latestPrice && latestPrice > 0) {
    await admin.from("stock_prices").upsert({
      user_id: userId,
      stock_id: saved.stock_id,
      price: latestPrice,
      currency,
      source: "KIS",
      updated_at_source: new Date().toISOString(),
    }, { onConflict: "user_id,stock_id" });
  }

  return json({ ok: true, mode: "server", stock: saved, latestPrice });
}



function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

// -------------------- op=sync_me (user manual sync; returns status) --------------------
async function syncMe(req: Request) {
  const auth = req.headers.get("authorization") ?? "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, error: "Unauthorized" }, 401);

  const url = new URL(req.url);
  const market = (url.searchParams.get("market") ?? "ALL").toUpperCase() as SyncMarket;
  if (!["KR", "US", "ALL"].includes(market)) return json({ ok: false, error: "market must be KR/US/ALL" }, 400);

  // Identify user via Supabase Auth
  const userClient = sbUser(req);
  const { data: u, error: ue } = await userClient.auth.getUser();
  if (ue || !u?.user) return json({ ok: false, error: "Unauthorized" }, 401);
  const userId = u.user.id;

  const admin = sbAdmin();

  // ---- 60s cooldown + in-progress guard ----
  const { data: lastRuns, error: lrErr } = await admin
    .from("market_data_sync_runs")
    .select("run_id,started_at,finished_at,status,mode,market")
    .eq("user_id", userId)
    .order("started_at", { ascending: false })
    .limit(1);

  if (lrErr) throw lrErr;

  const last = (lastRuns ?? [])[0] as any;
  if (last?.started_at) {
    const dt = Date.now() - new Date(last.started_at).getTime();
    const status = String(last.status ?? "").toUpperCase();

    // In progress (best-effort) - avoid duplicate long-running KIS calls
    if (!last.finished_at && status === "STARTED" && dt < 15 * 60_000) {
      return json({
        ok: true,
        skipped: true,
        reason: "in_progress",
        run_id: String(last.run_id ?? ""),
        since_ms: dt,
      }, 202);
    }

    // Cooldown (always enforced, even after failure)
    if (dt < 60_000) {
      return json({
        ok: true,
        skipped: true,
        reason: "cooldown",
        wait_ms: 60_000 - dt,
        last_run_id: String(last.run_id ?? ""),
      });
    }
  }

  // ---- Start run log ----
  const startedAt = new Date().toISOString();
  const runRow = await insertSyncRunWithFallback(admin, {
    user_id: userId,
    mode: "manual",
    market,
    status: "STARTED",
    started_at: startedAt,
    market_data_asof: null,
    provider: "frankfurter+KIS",
    detail: { kisEnv: kisEnv(), requestedBy: "user" },
  });
  const runId = String((runRow as any).run_id);

  const errors: string[] = [];
  let updatedWallet = 0;
  let updatedStocks = 0;

  try {
    // 1) FX
    const fxRate = await fetchUsdKrw();
    const fxAsOf = new Date().toISOString();

    const { error: fxErr } = await admin.from("fx_rates").upsert({
      user_id: userId,
      pair: "USDKRW",
      rate: fxRate,
      source: "frankfurter",
      updated_at_source: fxAsOf,
    }, { onConflict: "user_id,pair" });
    if (fxErr) throw fxErr;

    // 2) USD wallet revaluation
    const { data: wallets, error: wErr } = await admin
      .from("currency_wallet")
      .select("wallet_id,total_foreign_held,total_krw_invested")
      .eq("user_id", userId)
      .eq("currency", "USD");
    if (wErr) throw wErr;

    for (const w of wallets ?? []) {
      const held = asNumber((w as any).total_foreign_held) ?? 0;
      const invested = asNumber((w as any).total_krw_invested) ?? 0;
      const est = held * fxRate;
      const profit = est - invested;

      const { error: upErr } = await admin.from("currency_wallet").update({
        current_rate: fxRate,
        est_value_krw: est,
        profit_krw: profit,
        last_updated: new Date().toISOString(),
      }).eq("wallet_id", (w as any).wallet_id);
      if (upErr) throw upErr;

      updatedWallet++;
    }

    // 3) Stock prices for held stocks
    const { data: holds, error: hErr } = await admin
      .from("holdings")
      .select("stock_id")
      .eq("user_id", userId);
    if (hErr) throw hErr;

    const stockIds = Array.from(new Set((holds ?? []).map((r: any) => String(r.stock_id))));
    if (stockIds.length > 0) {
      const { data: stocks, error: sErr } = await admin
        .from("stocks")
        .select("stock_id,ticker,market,currency,kis_excd,kis_prdt_type_cd")
        .eq("user_id", userId)
        .in("stock_id", stockIds);
      if (sErr) throw sErr;

      const tokenMgr = new KisTokenManager(admin, Deno.env.get("KIS_TOKEN_OWNER") ?? "kis:default");
      const accessToken = await tokenMgr.getAccessToken();

      // Mild throttle to reduce KIS burst risk (token 1-min rule is handled by kis_token_* RPC)
      const KIS_CALL_DELAY_MS = 120;

      for (const s of stocks ?? []) {
        try {
          const sMarket = String((s as any).market ?? "").toUpperCase();
          if (market !== "ALL" && sMarket !== market) continue;

          if (sMarket === "KR") {
            const p = await kisDomesticPrice(accessToken, String((s as any).ticker));
            await sleep(KIS_CALL_DELAY_MS);

            const { error } = await admin.from("stock_prices").upsert({
              user_id: userId,
              stock_id: (s as any).stock_id,
              price: p,
              currency: "KRW",
              source: "KIS",
              updated_at_source: new Date().toISOString(),
            }, { onConflict: "user_id,stock_id" });
            if (error) throw error;

            updatedStocks++;
            continue;
          }

          if (sMarket === "US") {
            if (isVts()) {
              errors.push("KIS_ENV=vts: US price sync skipped (미지원)");
              continue;
            }

            let excd = String((s as any).kis_excd ?? "");
            let prdt = String((s as any).kis_prdt_type_cd ?? "");
            let price: number;

            if (!excd) {
              const detected = await tryDetectUsExcd(accessToken, String((s as any).ticker));
              excd = detected.excd;
              prdt = detected.prdtType ?? prdt;

              await admin.from("stocks").update({
                kis_excd: excd,
                kis_prdt_type_cd: prdt || null,
              }).eq("stock_id", (s as any).stock_id);

              price = detected.price;
            } else {
              price = await kisOverseasPrice(accessToken, excd, String((s as any).ticker));
            }

            await sleep(KIS_CALL_DELAY_MS);

            const { error } = await admin.from("stock_prices").upsert({
              user_id: userId,
              stock_id: (s as any).stock_id,
              price,
              currency: "USD",
              source: "KIS",
              updated_at_source: new Date().toISOString(),
            }, { onConflict: "user_id,stock_id" });
            if (error) throw error;

            updatedStocks++;
          }
        } catch (e) {
          errors.push(String(e));
        }
      }
    }

    // 4) refresh stats
    const { error: rsErr } = await admin.rpc("refresh_stats", { p_user_id: userId });
    if (rsErr) throw rsErr;

    const status = errors.length ? "PARTIAL" : "SUCCESS";

    await admin.from("market_data_sync_runs").update({
      status,
      finished_at: new Date().toISOString(),
      market_data_asof: fxAsOf,
      detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, counts: { updatedWallet, updatedStocks }, errors, kisEnv: kisEnv() },
    }).eq("run_id", runId);

    return json({
      ok: true,
      mode: "manual",
      status,
      run_id: runId,
      market,
      market_data_asof: fxAsOf,
      usdkrw: fxRate,
      counts: { updatedWallet, updatedStocks },
      errorCount: errors.length,
      errors,
    });
  } catch (e) {
    const err = String(e);

    try {
      await admin.from("market_data_sync_runs").update({
        status: "FAILED",
        finished_at: new Date().toISOString(),
        detail: { error: err, counts: { updatedWallet, updatedStocks }, errors, kisEnv: kisEnv() },
      }).eq("run_id", runId);
    } catch {
      // ignore
    }

    return json({ ok: false, mode: "manual", status: "FAILED", run_id: runId, error: err, errors }, 500);
  }
}


// -------------------- op=sync (server only) --------------------
async function syncMarket(req: Request) {
  const cronHeader = req.headers.get("x-cron-secret") ?? "";
  const cronSecret = env("CRON_SECRET");
  if (cronHeader !== cronSecret) return json({ ok: false, error: "Unauthorized" }, 401);

  const url = new URL(req.url);
  const market = (url.searchParams.get("market") ?? "ALL").toUpperCase() as SyncMarket;
  if (!["KR", "US", "ALL"].includes(market)) return json({ ok: false, error: "market must be KR/US/ALL" }, 400);

  const admin = sbAdmin();

  // global throttling (1 min)
  const { data: lastRuns } = await admin
    .from("market_data_sync_runs")
    .select("started_at")
    .is("user_id", null)
    .order("started_at", { ascending: false })
    .limit(1);

  if (lastRuns?.[0]?.started_at) {
    const dt = Date.now() - new Date(lastRuns[0].started_at as any).getTime();
    if (dt < 60_000) return json({ ok: true, skipped: true, reason: "recent run < 60s" });
  }

  const fxRate = await fetchUsdKrw();
  const fxAsOf = new Date().toISOString();

  const tokenMgr = new KisTokenManager(admin, Deno.env.get("KIS_TOKEN_OWNER") ?? "kis:default");
  const accessToken = await tokenMgr.getAccessToken();

  // Optional global run row (user_id=null) - ignore failure if user_id NOT NULL
  let globalRunId: string | null = null;
  try {
    const gr = await insertSyncRunWithFallback(admin, {
      user_id: null,
      mode: "scheduled",
      market,
      status: "STARTED",
      started_at: new Date().toISOString(),
      market_data_asof: fxAsOf,
      provider: "frankfurter+KIS",
      detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, kisEnv: kisEnv() },
    });
    globalRunId = gr?.run_id ? String(gr.run_id) : null;
  } catch {
    // ignore
  }

  // user list from holdings + currency_wallet
  const userIds = new Set<string>();
  for (const table of ["holdings", "currency_wallet"]) {
    const { data, error } = await admin.from(table).select("user_id");
    if (error) throw error;
    (data ?? []).forEach((r: any) => userIds.add(String(r.user_id)));
  }

  const users = Array.from(userIds);
  const results = await mapLimit(users, 2, async (userId) => {
    const startedAt = new Date().toISOString();
    const runRow = await insertSyncRunWithFallback(admin, {
      user_id: userId,
      mode: "scheduled",
      market,
      status: "STARTED",
      started_at: startedAt,
      market_data_asof: fxAsOf,
      provider: "frankfurter+KIS",
      detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, kisEnv: kisEnv() },
    });

    const runId = String(runRow.run_id);
    const errors: string[] = [];
    let updatedWallet = 0;
    let updatedStocks = 0;

    try {
      // 1) fx_rates
      const { error: fxErr } = await admin.from("fx_rates").upsert({
        user_id: userId,
        pair: "USDKRW",
        rate: fxRate,
        source: "frankfurter",
        updated_at_source: fxAsOf,
      }, { onConflict: "user_id,pair" });
      if (fxErr) throw fxErr;

      // 2) USD wallet revaluation
      const { data: wallets, error: wErr } = await admin
        .from("currency_wallet")
        .select("wallet_id,total_foreign_held,total_krw_invested")
        .eq("user_id", userId)
        .eq("currency", "USD");
      if (wErr) throw wErr;

      for (const w of wallets ?? []) {
        const held = asNumber((w as any).total_foreign_held) ?? 0;
        const invested = asNumber((w as any).total_krw_invested) ?? 0;
        const est = held * fxRate;
        const profit = est - invested;

        const { error: upErr } = await admin.from("currency_wallet").update({
          current_rate: fxRate,
          est_value_krw: est,
          profit_krw: profit,
          last_updated: new Date().toISOString(),
        }).eq("wallet_id", (w as any).wallet_id);
        if (upErr) throw upErr;

        updatedWallet++;
      }

      // 3) holdings -> stock_prices
      const { data: holds, error: hErr } = await admin
        .from("holdings")
        .select("stock_id")
        .eq("user_id", userId);
      if (hErr) throw hErr;

      const stockIds = Array.from(new Set((holds ?? []).map((r: any) => String(r.stock_id))));
      if (stockIds.length > 0) {
        const { data: stocks, error: sErr } = await admin
          .from("stocks")
          .select("stock_id,ticker,market,currency,kis_excd,kis_prdt_type_cd")
          .eq("user_id", userId)
          .in("stock_id", stockIds);
        if (sErr) throw sErr;

        for (const s of stocks ?? []) {
          try {
            if (market !== "ALL" && s.market !== market) continue;

            if (s.market === "KR") {
              const p = await kisDomesticPrice(accessToken, String(s.ticker));
              const { error } = await admin.from("stock_prices").upsert({
                user_id: userId,
                stock_id: s.stock_id,
                price: p,
                currency: "KRW",
                source: "KIS",
                updated_at_source: new Date().toISOString(),
              }, { onConflict: "user_id,stock_id" });
              if (error) throw error;
              updatedStocks++;
              continue;
            }

            if (s.market === "US") {
              if (isVts()) {
                errors.push("KIS_ENV=vts: US price sync skipped (미지원)");
                continue;
              }

              let excd = String(s.kis_excd ?? "");
              let prdt = String(s.kis_prdt_type_cd ?? "");
              let price: number;

              if (!excd) {
                const detected = await tryDetectUsExcd(accessToken, String(s.ticker));
                excd = detected.excd;
                prdt = detected.prdtType ?? prdt;

                await admin.from("stocks").update({
                  kis_excd: excd,
                  kis_prdt_type_cd: prdt || null,
                }).eq("stock_id", s.stock_id);

                price = detected.price;
              } else {
                price = await kisOverseasPrice(accessToken, excd, String(s.ticker));
              }

              const { error } = await admin.from("stock_prices").upsert({
                user_id: userId,
                stock_id: s.stock_id,
                price,
                currency: "USD",
                source: "KIS",
                updated_at_source: new Date().toISOString(),
              }, { onConflict: "user_id,stock_id" });
              if (error) throw error;
              updatedStocks++;
            }
          } catch (e) {
            errors.push(String(e));
          }
        }
      }

      // 4) refresh stats
      const { error: rsErr } = await admin.rpc("refresh_stats", { p_user_id: userId });
      if (rsErr) throw rsErr;

      const status = errors.length ? "PARTIAL" : "SUCCESS";
      await admin.from("market_data_sync_runs").update({
        status,
        finished_at: new Date().toISOString(),
        market_data_asof: fxAsOf,
        detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, counts: { updatedWallet, updatedStocks }, errors },
      }).eq("run_id", runId);

      return { userId, status, updatedWallet, updatedStocks, errorCount: errors.length };
    } catch (e) {
      await admin.from("market_data_sync_runs").update({
        status: "FAILED",
        finished_at: new Date().toISOString(),
        market_data_asof: fxAsOf,
        detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, counts: { updatedWallet, updatedStocks }, error: String(e), errors },
      }).eq("run_id", runId);

      return { userId, status: "FAILED", error: String(e) };
    }
  });

  if (globalRunId) {
    await admin.from("market_data_sync_runs").update({
      status: "SUCCESS",
      finished_at: new Date().toISOString(),
      market_data_asof: fxAsOf,
      detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, userCount: results.length },
    }).eq("run_id", globalRunId);
  }

  return json({ ok: true, usdkrw: fxRate, results });
}


// -------------------- KST Date Helpers --------------------
function kstIsoDate(d: Date = new Date()): string {
  const kst = new Date(d.getTime() + 9 * 60 * 60 * 1000);
  return kst.toISOString().slice(0, 10);
}
function addDaysIso(dateIso: string, days: number): string {
  const d = new Date(dateIso + "T00:00:00.000Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

// -------------------- Trading Day Resolution (Holiday/Weekend Guard) --------------------
// Goal: keep DB's trading_date semantic as "last market business day".
// We avoid maintaining holiday calendars; instead we ask KIS for the latest business date.

function isoToYmd(dateIso: string): string {
  // "YYYY-MM-DD" -> "YYYYMMDD"
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateIso)) throw new Error(`Bad ISO date: ${dateIso}`);
  return dateIso.replace(/-/g, "");
}
function ymdToIso(ymd: string): string {
  if (!/^\d{8}$/.test(ymd)) throw new Error(`Bad yyyymmdd: ${ymd}`);
  return `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6, 8)}`;
}

// Use a stable reference ticker to infer the KR market's last business date.
// NOTE: 005930 is used only as a market calendar proxy (not user-specific).
async function resolveKrTradingDateByKis(accessToken: string, intendedIso: string): Promise<string> {
  const url =
    `${kisBaseUrl()}/uapi/domestic-stock/v1/quotations/inquire-daily-price` +
    `?FID_COND_MRKT_DIV_CODE=J&FID_INPUT_ISCD=005930&FID_PERIOD_DIV_CODE=D&FID_ORG_ADJ_PRC=0`;

  const body = await fetchKisJson(url, { method: "GET", headers: kisHeaders(accessToken, "FHKST01010400") });
  const arr = Array.isArray(body?.output) ? body.output : [];
  const ymd = String(arr?.[0]?.stck_bsop_date ?? "").trim();
  if (!/^\d{8}$/.test(ymd)) throw new Error(`KIS KR daily-price missing stck_bsop_date: ${JSON.stringify(body)}`);

  return ymdToIso(ymd);
}

// Resolve US last business date via KIS "overseas index/FX daily chart" (uses .DJI).
// NOTE: this endpoint is suitable as a market-calendar proxy; it returns business dates in output2[].
async function resolveUsTradingDateByKis(accessToken: string, intendedIso: string): Promise<string> {
  if (isVts()) throw new Error("KIS_ENV=vts 환경에서는 해외지수/기간별시세 조회가 제한될 수 있습니다. prod로 실행하세요.");

  const date2 = isoToYmd(intendedIso);
  const date1 = isoToYmd(addDaysIso(intendedIso, -10)); // buffer for weekends/holidays
  const url =
    `${kisBaseUrl()}/uapi/overseas-price/v1/quotations/inquire-daily-chartprice` +
    `?FID_COND_MRKT_DIV_CODE=N&FID_INPUT_ISCD=${encodeURIComponent(".DJI")}` +
    `&FID_INPUT_DATE_1=${encodeURIComponent(date1)}&FID_INPUT_DATE_2=${encodeURIComponent(date2)}` +
    `&FID_PERIOD_DIV_CODE=D`;

  const body = await fetchKisJson(url, { method: "GET", headers: kisHeaders(accessToken, "FHKST03030100") });
  const arr = Array.isArray(body?.output2) ? body.output2 : [];
  const ymd = String(arr?.[0]?.stck_bsop_date ?? "").trim();
  if (!/^\d{8}$/.test(ymd)) throw new Error(`KIS US daily-chart missing stck_bsop_date: ${JSON.stringify(body)}`);

  return ymdToIso(ymd);
}

// -------------------- Daily Close (시장데이터 -> 일일 스냅샷) --------------------
async function dailyClose(req: Request) {
  const cronHeader = req.headers.get("x-cron-secret") ?? "";
  const cronSecret = env("CRON_SECRET");
  if (cronHeader !== cronSecret) return json({ ok: false, error: "Unauthorized" }, 401);

  const url = new URL(req.url);
  const market = (url.searchParams.get("market") ?? "ALL").toUpperCase() as SyncMarket;
  if (!["KR", "US", "ALL"].includes(market)) return json({ ok: false, error: "market must be KR/US/ALL" }, 400);

  const kstToday = kstIsoDate();
  const intendedTradingDate = url.searchParams.get("trading_date") ?? addDaysIso(kstToday, -1);
  let tradingDate = intendedTradingDate; // may be adjusted to last business date per market (KR/US)
  const source = url.searchParams.get("source") ?? "CRON";

  let tradingDateAdjusted = false;
  let tradingDateAdjustReason: string | null = null;

  const admin = sbAdmin();

  // 0) global throttling (safety)
  const { data: lastRuns } = await admin
    .from("market_data_sync_runs")
    .select("started_at")
    .is("user_id", null)
    .order("started_at", { ascending: false })
    .limit(1);

  if (lastRuns?.[0]?.started_at) {
    const dt = Date.now() - new Date(lastRuns[0].started_at as any).getTime();
    if (dt < 60_000) return json({ ok: true, skipped: true, reason: "recent run < 60s" });
  }

  // 1) Market sync (Frankfurter FX + KIS prices)
  const fxRate = await fetchUsdKrw();
  const fxAsOf = new Date().toISOString();

  const tokenMgr = new KisTokenManager(admin, Deno.env.get("KIS_TOKEN_OWNER") ?? "kis:default");
  const accessToken = await tokenMgr.getAccessToken();

  // 1.5) Resolve tradingDate to the last market business date (holiday/weekend guard)
  // Cron is configured to call KR and US separately, so this remains unambiguous.
  if (market === "KR") {
    try {
      const resolved = await resolveKrTradingDateByKis(accessToken, intendedTradingDate);
      if (resolved !== intendedTradingDate) {
        tradingDate = resolved;
        tradingDateAdjusted = true;
        tradingDateAdjustReason = `KR holiday/weekend detected. intended=${intendedTradingDate}, resolved=${resolved}`;
      }
    } catch (e) {
      // Fail-soft: do not block daily_close; keep intended date but record reason.
      tradingDateAdjustReason = `KR trading_date resolve failed; using intended. error=${String(e)}`;
    }
  } else if (market === "US") {
    try {
      const resolved = await resolveUsTradingDateByKis(accessToken, intendedTradingDate);
      if (resolved !== intendedTradingDate) {
        tradingDate = resolved;
        tradingDateAdjusted = true;
        tradingDateAdjustReason = `US holiday/weekend detected. intended=${intendedTradingDate}, resolved=${resolved}`;
      }
    } catch (e) {
      tradingDateAdjustReason = `US trading_date resolve failed; using intended. error=${String(e)}`;
    }
  } else {
    // market=ALL: keep as-is (ambiguous calendar). Prefer running KR/US separately via cron.
    tradingDateAdjustReason = "market=ALL: trading_date not auto-adjusted (run KR/US separately)";
  }

  // user list from stats (covers even users without holdings/wallet)
  const { data: statsUsers, error: suErr } = await admin.from("stats").select("user_id");
  if (suErr) throw suErr;
  const users = Array.from(new Set((statsUsers ?? []).map((r: any) => String(r.user_id))));

  // global run row (nullable user_id)
  let globalRunId: string | null = null;
  try {
    const gr = await insertSyncRunWithFallback(admin, {
      user_id: null,
      mode: "daily_close",
      market,
      status: "STARTED",
      started_at: new Date().toISOString(),
      market_data_asof: fxAsOf,
      provider: "frankfurter+KIS",
      detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, kisEnv: kisEnv(), intendedTradingDate, tradingDate, tradingDateAdjusted, tradingDateAdjustReason },
    });
    globalRunId = gr?.run_id ? String(gr.run_id) : null;
  } catch {
    // ignore (user_id NOT NULL constraint in some deployments)
  }

  const summaries = await mapLimit(users, 2, async (userId) => {
    const startedAt = new Date().toISOString();
    const runRow = await insertSyncRunWithFallback(admin, {
      user_id: userId,
      mode: "daily_close",
      market,
      status: "STARTED",
      started_at: startedAt,
      market_data_asof: fxAsOf,
      provider: "frankfurter+KIS",
      detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, kisEnv: kisEnv(), intendedTradingDate, tradingDate, tradingDateAdjusted, tradingDateAdjustReason },
    });
    const runId = String(runRow.run_id);
    const errors: string[] = [];
    let updatedWallet = 0;
    let updatedStocks = 0;

    try {
      // 1) fx_rates
      const { error: fxErr } = await admin.from("fx_rates").upsert(
        { user_id: userId, pair: "USDKRW", rate: fxRate, source: "frankfurter", updated_at_source: fxAsOf },
        { onConflict: "user_id,pair" },
      );
      if (fxErr) throw fxErr;

      // 2) USD wallet revaluation
      const { data: wallets, error: wErr } = await admin
        .from("currency_wallet")
        .select("wallet_id,total_foreign_held,total_krw_invested")
        .eq("user_id", userId)
        .eq("currency", "USD");
      if (wErr) throw wErr;

      for (const w of wallets ?? []) {
        const held = asNumber((w as any).total_foreign_held) ?? 0;
        const invested = asNumber((w as any).total_krw_invested) ?? 0;
        const est = held * fxRate;
        const profit = est - invested;

        const { error: upErr } = await admin.from("currency_wallet").update({
          current_rate: fxRate,
          est_value_krw: est,
          profit_krw: profit,
          last_updated: new Date().toISOString(),
        }).eq("wallet_id", (w as any).wallet_id);
        if (upErr) throw upErr;

        updatedWallet++;
      }

      // 3) holdings -> stock_prices
      const { data: holds, error: hErr } = await admin.from("holdings").select("stock_id").eq("user_id", userId);
      if (hErr) throw hErr;

      const stockIds = Array.from(new Set((holds ?? []).map((r: any) => String(r.stock_id))));
      if (stockIds.length > 0) {
        const { data: stocks, error: sErr } = await admin
          .from("stocks")
          .select("stock_id,ticker,market,currency,kis_excd,kis_prdt_type_cd")
          .eq("user_id", userId)
          .in("stock_id", stockIds);
        if (sErr) throw sErr;

        for (const s of stocks ?? []) {
          try {
            if (market !== "ALL" && String((s as any).market) !== market) continue;

            if ((s as any).market === "KR") {
              const p = await kisDomesticPrice(accessToken, String((s as any).ticker));
              const { error } = await admin.from("stock_prices").upsert({
                user_id: userId,
                stock_id: (s as any).stock_id,
                price: p,
                currency: "KRW",
                source: "KIS",
                updated_at_source: new Date().toISOString(),
              }, { onConflict: "user_id,stock_id" });
              if (error) throw error;
              updatedStocks++;
              continue;
            }

            if ((s as any).market === "US") {
              if (isVts()) {
                errors.push("KIS_ENV=vts: US price sync skipped (미지원)");
                continue;
              }

              let excd = String((s as any).kis_excd ?? "");
              let prdt = String((s as any).kis_prdt_type_cd ?? "");
              let price: number;

              if (!excd) {
                const detected = await tryDetectUsExcd(accessToken, String((s as any).ticker));
                excd = detected.excd;
                prdt = detected.prdtType ?? prdt;

                await admin.from("stocks").update({
                  kis_excd: excd,
                  kis_prdt_type_cd: prdt || null,
                }).eq("stock_id", (s as any).stock_id);

                price = detected.price;
              } else {
                price = await kisOverseasPrice(accessToken, excd, String((s as any).ticker));
              }

              const { error } = await admin.from("stock_prices").upsert({
                user_id: userId,
                stock_id: (s as any).stock_id,
                price,
                currency: "USD",
                source: "KIS",
                updated_at_source: new Date().toISOString(),
              }, { onConflict: "user_id,stock_id" });
              if (error) throw error;
              updatedStocks++;
            }
          } catch (e) {
            errors.push(String(e));
          }
        }
      }

      // 4) refresh_stats (current)
      const { error: rsErr } = await admin.rpc("refresh_stats", { p_user_id: userId });
      if (rsErr) throw rsErr;

      // 5) persist market data to daily tables for tradingDate
      const { error: pmErr } = await admin.rpc("persist_market_data_daily", {
        p_user_id: userId,
        p_trading_date: tradingDate,
        p_market_data_asof: fxAsOf,
        p_source: source,
      });
      if (pmErr) throw pmErr;

      // 6) daily snapshots (assets/liabilities/card usage)
      const calls = [
        admin.rpc("capture_account_snapshots", { p_user_id: userId, p_trading_date: tradingDate, p_market_data_asof: fxAsOf, p_source: source }),
        admin.rpc("capture_nav_snapshot", { p_user_id: userId, p_trading_date: tradingDate, p_market_data_asof: fxAsOf, p_source: source }),
        admin.rpc("capture_card_usage_snapshot", { p_user_id: userId, p_trading_date: tradingDate, p_market_data_asof: fxAsOf, p_source: source }),
      ];
      for (const c of calls) {
        const { error } = await c;
        if (error) throw error;
      }

      // 7) if there are queued past dates <= tradingDate, rebuild range once (earliest -> tradingDate)
      const { data: qMin, error: qErr } = await admin
        .from("daily_snapshot_recalc_queue")
        .select("trading_date")
        .eq("user_id", userId)
        .lte("trading_date", tradingDate)
        .order("trading_date", { ascending: true })
        .limit(1);
      if (qErr) throw qErr;

      if (qMin?.[0]?.trading_date) {
        const fromDate = String((qMin[0] as any).trading_date);
        const { error: rbErr } = await admin.rpc("rebuild_daily_snapshots", {
          p_user_id: userId,
          p_from_date: fromDate,
          p_to_date: tradingDate,
          p_source: "REBUILD",
        });
        if (rbErr) throw rbErr;

        const { error: delErr } = await admin
          .from("daily_snapshot_recalc_queue")
          .delete()
          .eq("user_id", userId)
          .lte("trading_date", tradingDate);
        if (delErr) throw delErr;
      }

      const status = errors.length ? "PARTIAL" : "SUCCESS";
      await admin.from("market_data_sync_runs").update({
        status,
        finished_at: new Date().toISOString(),
        market_data_asof: fxAsOf,
        detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, counts: { updatedWallet, updatedStocks }, errors, intendedTradingDate, tradingDate, tradingDateAdjusted, tradingDateAdjustReason },
      }).eq("run_id", runId);

      return { userId, status, updatedWallet, updatedStocks, errorCount: errors.length };
    } catch (e) {
      errors.push(String(e));
      await admin.from("market_data_sync_runs").update({
        status: "FAILED",
        finished_at: new Date().toISOString(),
        market_data_asof: fxAsOf,
        detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, errors, intendedTradingDate, tradingDate, tradingDateAdjusted, tradingDateAdjustReason },
      }).eq("run_id", runId);

      return { userId, status: "FAILED", updatedWallet, updatedStocks, errorCount: errors.length };
    }
  });

  if (globalRunId) {
    try {
      await admin.from("market_data_sync_runs").update({
        status: "SUCCESS",
        finished_at: new Date().toISOString(),
        market_data_asof: fxAsOf,
        detail: { fx: { provider: "frankfurter", usdkrw: fxRate }, intendedTradingDate, tradingDate, tradingDateAdjusted, tradingDateAdjustReason, users: users.length },
      }).eq("run_id", globalRunId);
    } catch {
      // ignore
    }
  }

  return json({ ok: true, intendedTradingDate, tradingDate, tradingDateAdjusted, tradingDateAdjustReason, fxRate, fxAsOf, users: users.length, summaries });
}


// -------------------- Router --------------------
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders() });

  try {
    const url = new URL(req.url);
    const op = (url.searchParams.get("op") ?? "sync").toLowerCase();

    if (op === "ensure_stock") return await ensureStock(req);
    if (op === "sync_me") return await syncMe(req);
    if (op === "daily_close") return await dailyClose(req);
    if (op === "sync") return await syncMarket(req);
    return json({ ok: false, error: "unknown op" }, 400);
  } catch (e) {
    return json({ ok: false, error: String(e) }, 500);
  }
});




## 기능설계서
- 원본: `PAD_v2.3.5_기능설계서_FULL_2026-01-29.FINAL.md`

## PAD v2.3.5 기능설계서 (FULL)
작성일: 2026-01-29 (KST)

---

### 0. 결론
- v2.3.5의 설계 핵심은 **“서버가 기록한 실행 로그/큐를 기준으로 UI 상태를 결정”**하는 것입니다.
- 특히 동기화/재계산은 멀티 디바이스 환경에서 동시에 눌릴 수 있으므로,
  앱은 “버튼 비활성”이 아니라 **상태 조회(로그) 중심 UX**로 동작해야 합니다.

---

### 1. 공통 플로우/표준 규격
#### 1.1 표준 에러 분류
- AUTH(401/403): 세션 만료/권한 부족 → 재로그인/접근 제한
- VALIDATION(400/422): 입력값 오류 → 폼 필드에 메시지 매핑
- BUSINESS(409 등): 잔액 부족/초과 매도 → 사용자 친화 메시지
- SERVER(500): 서버 장애 → 재시도 안내 + 로그/리포트 링크(개발자 모드)

#### 1.2 표준 재시도 정책
- 조회(GET/RPC read): 1~2회 지수 백오프 가능
- 쓰기(RPC write): **멱등성 보장 시에만 재시도**
  - 거래: `client_tx_id` 동일하면 재시도 OK
  - 동기화: 서버가 cooldown/in_progress 응답을 주므로 앱은 무리한 재시도 금지

#### 1.3 표준 상태 모델(UI)
- Loading / Ready / Error
- 동기화 상태: Unknown / Started / Success / Partial / Failed / Cooldown

---

### 2. 핵심 기능별 프로세스 설계(Flowchart + 검증 + 예외)
> P0/P1 중심으로 “바로 구현 가능한 수준”의 상세도를 제공합니다.

---

### 2.1 홈 대시보드 로딩 (IA-01)
```mermaid
flowchart TD
  A[Dashboard 진입] --> B[get_dashboard RPC]
  B --> C{성공?}
  C -->|Yes| D[UI: KPI/최근거래/상태 렌더]
  D --> D2[NAV 차트/지표: v_portfolio_nav_daily + v_portfolio_metrics 별도 로드]
  D --> E[동기화 배지: market_data_sync_runs 최신 표시]
  D --> F[정합성 배지: recalc_queue count 표시]
  C -->|No| G[캐시 표시 + ErrorBanner]
```

#### 입력값 검증
- 없음(세션만 유효하면 됨)

#### 예외 처리
- 401: 로그인 갱신 실패 시 로그인 화면으로
- 네트워크: 캐시 유지, “새로고침” 제공

---

### 2.2 수동 동기화 버튼 (SI-03 + SI-02)
```mermaid
flowchart TD
  A[사용자: 동기화 클릭] --> B[POST Edge pad-market-sync op=sync_me]
  B --> C{응답}
  C -->|cooldown| D[UI: 남은 시간 표시 + 버튼 잠금]
  C -->|in_progress| E[UI: 다른 기기/세션 진행중 표시]
  C -->|SUCCESS/PARTIAL| F[UI: 토스트 + get_dashboard 재호출]
  C -->|FAILED| G[UI: 에러 + 재시도 버튼]
  E --> H[market_data_sync_runs 최신 조회]
  H --> I{finished?}
  I -->|Yes| F
  I -->|No| E
```

#### 입력 검증
- market 파라미터는 KR/US/ALL만 허용

#### 성공/실패 시나리오
- SUCCESS: errors=0
- PARTIAL: errors>0 → 사용자에게 “일부 실패” + 상세보기
- FAILED: error 메시지 표시(민감정보 제외)

---

### 2.3 거래 생성 (CF-01)
```mermaid
flowchart TD
  A[거래 입력 폼] --> B[클라이언트 검증(DataAnnotations)]
  B --> C{Valid?}
  C -->|No| D[필드 에러 표시]
  C -->|Yes| E[RPC process_transaction_v2]
  E --> F{성공?}
  F -->|Yes| G[UI: 리스트/대시보드 새로고침]
  F -->|No| H[에러 분류: AUTH/VALIDATION/BUSINESS/SERVER]
  H --> I[사용자 메시지 변환]
```

#### 타입별 필수값(예시 규칙)
- 지출/수입: amount, currency, date, (category 또는 category_id)
- 이체: account_id + to_account_id + amount
- 주식_매수/매도: stock_id + qty + amount + account_id
- 환전: from/to 통화, fx_rate(정책에 따라), account_id

#### 예외 케이스
- 잔액 부족 / 초과 매도: BUSINESS로 처리, 사용자 안내
- 네트워크 실패: 동일 client_tx_id로 재시도 버튼 제공

---

### 2.4 거래 수정/취소 (CF-02/CF-03)
#### 수정(정정 체인)
```mermaid
flowchart TD
  A[거래 상세 -> 수정] --> B[폼 변경]
  B --> C[RPC edit_transaction_v2]
  C --> D{성공?}
  D -->|Yes| E[리스트/대시보드 갱신]
  D -->|No| F[에러 표시]
```

#### 취소(역거래)
```mermaid
flowchart TD
  A[거래 상세 -> 취소] --> B[확인 다이얼로그]
  B --> C[RPC reverse_transaction]
  C --> D{성공?}
  D -->|Yes| E[리스트/대시보드 갱신]
  D -->|No| F[에러 표시]
```

---

### 2.5 타임 머신(과거 시점 조회) (TS-01)
```mermaid
flowchart TD
  A[사용자: 날짜 선택] --> B{선택 날짜 < 오늘(KST)?}
  B -->|Yes| C[Daily 테이블/뷰 조회]
  B -->|No| D[최신 뷰/현재 데이터 조회]
  C --> E[UI: '과거' 배지 + 입력 제한]
  D --> F[UI: '현재' 배지]
```

#### UX 규칙
- 과거 모드에서는 “거래 입력” 비활성(또는 오늘로 복귀 유도)

---

### 2.6 정합성 센터(큐) + Rebuild 요청 (SI-01 + TS-09)
```mermaid
flowchart TD
  A[Integrity 화면 진입] --> B[recalc_queue 조회]
  B --> C{queue > 0?}
  C -->|No| D[정상 상태 표시]
  C -->|Yes| E[누락/실패 날짜 목록 + 사유]
  E --> F[사용자: 재계산 요청]
  F --> G[RPC request_snapshot_recalc(from,to,reason)]
  G --> H[UI: 요청 접수 + 상태 표시]
```

#### 검증/예외
- 기간 범위 제한: **최대 31일(하드 리밋)**
- 동일 날짜 중복 요청 방지(멱등)

---

### 2.7 Rebuild Worker 실행(서버) (TS-10)
```mermaid
flowchart TD
  A[Cron: 15분] --> B[Edge pad-recalc-worker op=run]
  B --> C[큐에서 유저/날짜 수집]
  C --> D[연속 구간 그룹화]
  D --> E[RPC rebuild_daily_snapshots(from,to)]
  E --> F[성공/실패 로그 기록]
  F --> G[응답 요약 반환]
```

#### 실패 시나리오
- Service Role 누락: 운영 설정 문제 → 즉시 대응 필요
- 일별 환율/종가 부족: daily_close/데이터 보강 필요 → 큐에 남아 UX로 노출

---

### 2.8 Daily Close(서버 배치) (SI-05)
```mermaid
flowchart TD
  A[Cron: 장마감 후] --> B[Edge daily_close]
  B --> C[FX/주가 동기화]
  C --> D[refresh_stats]
  D --> E[persist_*_daily + capture_*_snapshot]
  E --> F[결과 로그 기록]
  F --> G[응답 요약]
```

---

### 3. 화면/컴포넌트 설계(Blazor Hybrid)
#### 3.1 IA(대시보드/자산)
- KPI 카드: NetWorth, Cash(KRW), StockValue(KRW), USD Exposure, Liabilities
- Sync 패널: 상태 배지 + 마지막 완료 시각 + 버튼(동기화/새로고침)
- 차트:
  - NAV 라인(30/90/365/ALL)
  - 월별 히트맵(연도 선택)
  - 리스크 카드(MDD 등)

#### 3.2 거래
- 리스트: 서버 페이지네이션 + 필터(기간/타입/계정/카테고리)
- 입력: 타입 선택 → 동적 폼(필수 필드)
- 수정/취소: 상세 화면에서 처리, 감사로그 링크

#### 3.3 Integrity
- recalc_queue count, min/max date
- 재계산 요청 폼(from/to + reason)
- (선택) 최근 rebuild run 요약 표시

---

### 4. “반드시” 넣어야 하는 설계 메모(운영 사고 방지)
- 앱에는 cron secret/service role 절대 포함 금지
- 동기화 상태는 서버 run log 기준으로 표시(멀티 디바이스 안전)
- 거래 재시도는 동일 client_tx_id로만
- 과거 데이터는 daily 우선, REBUILD는 서버만

---

### 5. 테스트 시나리오(스모크)
- 대시보드 로딩 성공/401/네트워크 실패
- 동기화: SUCCESS / cooldown / in_progress / PARTIAL / FAILED
- 거래: 생성 성공 / 잔액부족 / 중복 client_tx_id / 수정/취소
- Integrity: 큐 없음 / 큐 있음 / 재계산 요청 적재

---
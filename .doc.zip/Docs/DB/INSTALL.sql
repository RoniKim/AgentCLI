-- =========================================================
-- PAD v2.3.5 INSTALL (FULL SCHEMA + PATCHES + CRON) — 2026-01-30
-- Bundle layout: PAD/DB, PAD/Doc, PAD/Edge
-- =========================================================

-- PAD v2.3.5 FULL SCHEMA FINAL (2026-01-30)
-- This file is PAD_v2.3.5_FULL_SCHEMA_FINAL_2026-01-29.sql + patches applied after that date:
--  - reverse_transaction correction category fix (2026-01-30)
--  - kis_token_cache align to Edge (2026-01-30)
-- Generated at: 2026-01-29 23:42:48Z

-- =========================================================
-- PAD v2.3.5 FULL SQL (Integrated)
-- Generated: 2026-01-29 (KST)
--
-- Includes:
--  - Reset public schema (DROP/CREATE public)
--  - Base schema objects (tables/views/functions/triggers/RLS)
--  - Rebuild Queue / Worker patch (v2.3.2)
--  - v2.3.5 operational indexes
--
-- Run: Supabase SQL Editor -> No limit -> execute top-to-bottom
-- WARNING: This DROPS public schema CASCADE (all public objects/data removed).
-- =========================================================

-- PAD Reset Public Schema — v2.3.0 — 2026-01-28
-- WARNING: Drops schema public CASCADE (all objects/data in public).

drop schema if exists public cascade;
create schema public;

grant usage on schema public to postgres, anon, authenticated, service_role;
alter default privileges in schema public grant all on tables to postgres, anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to postgres, anon, authenticated, service_role;
alter default privileges in schema public grant all on sequences to postgres, anon, authenticated, service_role;


-- =========================================================
-- PAD v2.3.0 FULL RESET (based on v2.1.2.2 known-good installer)
-- Date: 2026-01-28
-- Key v2.3 changes:
--  - Rebuild resilience: FX/Price FFILL (no whole rebuild abort due to one missing day)
--  - Historical pollution prevention: REBUILD path never falls back to current FX/Price
--  - KIS decoding hardening is in Edge TS (see pad-market-sync)
-- =========================================================

/* 
PAD All-SDK FULL CLEAN INSTALL + SECURITY HARDEN + PATCH
Version: v2.3.0
Patched: 2026-01-28 (KST)
 - Fix: KST month boundary for recalc_monthly_kpis (timestamptz-safe)
 - Fix: Normalize legacy process_transaction_v2 monthly window to KST
 - Fix: market_data_sync_runs.provider support for Edge Function inserts
Generated: 2026-01-27 (KST)
Base: PAD_All-SDK_v2.3.0_FULL_CLEAN_INSTALL_2026-01-26.sql
+ PAD_DB_SECURITY_HARDEN_v2.3.0sql
+ 2026-01-27 patch pack (policy idempotency + server-owned market data)
*/
-- =====================================================================
-- PAD All-SDK FULL (v2.3.0) - CLEAN INSTALL
-- Generated: 2026-01-26 12:00:00 +0900 (Asia/Seoul)
--
-- What’s new in v2.3.0 (핵심 변화)
--  1) 카드 정책 확정
--     - 카드 사용(지출/수수료/세금/환불 수입): card_id만 기록, 통장(account_balances)/순자산에는 영향 없음
--     - 카드 납부(type='카드_대금'): 통장에서 금액이 빠져 순자산 감소 (account_id + card_id 필요)
--  2) 고정지출(Fixed Expenses) 테이블/뷰 추가 (월 합계/리스트)
--  3) 거래내역 수정(edit_transaction_v2) 지원
--     - 원거래 VOID + 교정(역거래) + 새 거래 생성 → 잔액/보유/통계 정합성 유지
--  4) 거래 멱등성(client_tx_id) + 대시보드/카드 집계에서 VOID/CORRECTION 자동 제외
--
-- Recommended usage:
--  - Fresh install: run this file top-to-bottom.
--  - Existing DB: this file is designed to be mostly idempotent, but review before production.
-- =====================================================================

-- ===========================
-- SECTION 1: BASE ALL-SDK v1.3.6 PATCHED
-- ===========================

-- =====================================================================
-- PAD All-SDK (v1.3.5 patched) WITH FINAL TEST RUNNER PATCHES
-- Generated: 2026-01-24 00:00:00 +0900 (Asia/Seoul)
-- Includes:
--  - Base schema/functions/constraints (All-SDK)
--  - KIS token cache + rate-limit RPCs
--  - Finalized test runner patches:
--      * seed_test_data US KIS meta fix
--      * K4 deterministic MDD / 12M win-rate seed (9/12, MDD=-15%)
-- =====================================================================

-- =============================================================================
-- PAD All-SDK (All-in-One + KIS Token Cache + KIS Full Edge Test Runner)
-- Version : v1.3.1_patched_FINAL
-- Date    : 2026-01-23
--
-- 목적
--  - 빈 Supabase Postgres에 "한 방 설치"로 앱/Edge/MAUI 개발에 필요한 DB 오브젝트를 모두 생성
--  - KIS 토큰 캐시/레이트리밋(1분 1회) 대응용 RPC 포함
--  - KIS 전용 전체 테스트러너(public.run_full_edge_tests_kis) 포함 (시드/엣지/회귀)
--
-- 권장 실행 순서(초기화 후)
--  1) 이 파일 전체 실행
--  2) 테스트: select * from public.run_full_edge_tests_kis('<user_id>'::uuid) order by test_name;
--
-- 주의
--  - 이 파일은 개발/테스트 환경 기준. 운영 환경에서는 테스트러너/시드 함수 제거를 권장.
-- =============================================================================

-- =====================================================================
-- Personal Asset Dashboard (Supabase) - All-in-One SQL (FINAL)
-- Version: v1.3.1-backend (Full Install)
-- Includes:
--  - Extensions
--  - Enums
--  - Tables + Indexes + Constraints
--  - updated_at trigger function + triggers
--  - RLS enable + Owner-only policies
--  - Grants for authenticated
--  - v1.3 Patch: transfers(to_account_id), account_balances, stock_prices
--  - RPC: ensure helpers, refresh_stats, process_transaction_v2
--  - Ops: new-user stats trigger, reset_monthly_stats, dashboard view
--
-- Usage:
--  1) Paste into Supabase SQL Editor
--  2) Run (one shot)
-- =====================================================================

-- =========================================================
-- 0) Extensions
-- =========================================================
create extension if not exists "pgcrypto";

-- =========================================================
-- 1) Enum Types
-- =========================================================
do $$ begin
  if not exists (select 1 from pg_type where typname = 'currency_code') then
    create type currency_code as enum ('KRW', 'USD');
  end if;

  if not exists (select 1 from pg_type where typname = 'account_type') then
    create type account_type as enum ('Cash', 'Bank', 'Securities', 'Etc');
  end if;

  if not exists (select 1 from pg_type where typname = 'stock_market') then
    create type stock_market as enum ('KR', 'US');
  end if;

  if not exists (select 1 from pg_type where typname = 'liability_type') then
    create type liability_type as enum ('Jeonse', 'Mortgage', 'Credit', 'Etc');
  end if;

  if not exists (select 1 from pg_type where typname = 'transaction_type') then
    create type transaction_type as enum (
      '지출',
      '수입',
      '이체',
      '주식_매수',
      '주식_매도',
      '배당금',
      '수수료',
      '세금',
      '환전_매수',
      '환전_매도',
      '대출_실행',
      '대출_상환_원금',
      '대출_상환_이자',
      '교정',
      '카드_대금'
    );
  end if;
end $$;

-- =========================================================
-- 2) Common Trigger Function: updated_at auto set
-- =========================================================
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- =========================================================
-- 3) Master Tables
-- =========================================================

-- 3.1 Accounts
create table if not exists public.accounts (
  account_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  account_name text not null,
  account_type account_type not null,
  default_currency currency_code not null default 'KRW',
  is_include_in_networth boolean not null default true,

  memo text null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_accounts_user on public.accounts(user_id);

drop trigger if exists trg_accounts_updated_at on public.accounts;
create trigger trg_accounts_updated_at
before update on public.accounts
for each row execute function public.set_updated_at();


-- 3.2 Cards
create table if not exists public.cards (
  card_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  card_name text not null,
  payment_day int not null,
  month_lag int not null default 1,

  linked_account_id uuid not null references public.accounts(account_id) on delete cascade,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint chk_cards_payment_day check (payment_day between 1 and 31),
  constraint chk_cards_month_lag check (month_lag in (0, 1))
);

create index if not exists idx_cards_user on public.cards(user_id);
create index if not exists idx_cards_linked_account on public.cards(linked_account_id);

drop trigger if exists trg_cards_updated_at on public.cards;
create trigger trg_cards_updated_at
before update on public.cards
for each row execute function public.set_updated_at();


-- 3.3 Stocks (per-user)
create table if not exists public.stocks (
  stock_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  ticker text not null,
  name text not null,
  market stock_market not null,
  currency currency_code not null,
  note text null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_stocks_user_ticker unique (user_id, ticker)
);

create index if not exists idx_stocks_user on public.stocks(user_id);
create index if not exists idx_stocks_ticker on public.stocks(ticker);

drop trigger if exists trg_stocks_updated_at on public.stocks;
create trigger trg_stocks_updated_at
before update on public.stocks
for each row execute function public.set_updated_at();


-- =========================================================
-- 4) State Tables
-- =========================================================

-- 4.1 Holdings
create table if not exists public.holdings (
  holding_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  stock_id uuid not null references public.stocks(stock_id) on delete cascade,
  holdings_qty numeric(18,6) not null default 0,
  avg_buy_price numeric(18,6) null,

  last_updated timestamptz not null default now(),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_holdings_user_stock unique (user_id, stock_id),
  constraint chk_holdings_non_negative check (holdings_qty >= 0)
);

create index if not exists idx_holdings_user on public.holdings(user_id);
create index if not exists idx_holdings_stock on public.holdings(stock_id);

drop trigger if exists trg_holdings_updated_at on public.holdings;
create trigger trg_holdings_updated_at
before update on public.holdings
for each row execute function public.set_updated_at();


-- 4.2 FX Rates (current)
create table if not exists public.fx_rates (
  fx_rate_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  pair text not null, -- e.g. 'USDKRW'
  rate numeric(18,6) not null,

  source text null,
  updated_at_source timestamptz not null default now(),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_fx_rates_user_pair unique (user_id, pair),
  constraint chk_fx_rate_positive check (rate > 0)
);

create index if not exists idx_fx_rates_user on public.fx_rates(user_id);
create index if not exists idx_fx_rates_pair on public.fx_rates(pair);

drop trigger if exists trg_fx_rates_updated_at on public.fx_rates;
create trigger trg_fx_rates_updated_at
before update on public.fx_rates
for each row execute function public.set_updated_at();


-- 4.3 Currency Wallet (USD)
create table if not exists public.currency_wallet (
  wallet_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  currency currency_code not null default 'USD',

  total_foreign_held numeric(18,6) not null default 0,
  total_krw_invested numeric(18,2) not null default 0,

  avg_rate numeric(18,6) null,
  current_rate numeric(18,6) null,
  est_value_krw numeric(18,2) null,
  profit_krw numeric(18,2) null,

  last_updated timestamptz not null default now(),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_currency_wallet_user_currency unique (user_id, currency),
  constraint chk_foreign_non_negative check (total_foreign_held >= 0),
  constraint chk_krw_invested_non_negative check (total_krw_invested >= 0)
);

create index if not exists idx_currency_wallet_user on public.currency_wallet(user_id);

drop trigger if exists trg_currency_wallet_updated_at on public.currency_wallet;
create trigger trg_currency_wallet_updated_at
before update on public.currency_wallet
for each row execute function public.set_updated_at();


-- 4.4 Liabilities
create table if not exists public.liabilities (
  liability_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  liability_name text not null,
  liability_type liability_type not null,

  principal_original numeric(18,2) null,
  principal_remaining numeric(18,2) not null default 0,

  interest_rate_annual numeric(8,4) null,  -- e.g. 4.2 (%)
  interest_day int null,                   -- 1~31
  start_date date null,
  end_date date null,

  lender text null,
  currency currency_code not null default 'KRW',
  is_include_in_networth boolean not null default true,

  last_updated timestamptz not null default now(),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint chk_liabilities_principal_non_negative check (principal_remaining >= 0),
  constraint chk_liabilities_interest_day check (interest_day is null or (interest_day between 1 and 31)),
  constraint chk_interest_rate_valid check (interest_rate_annual is null or interest_rate_annual >= 0)
);

create index if not exists idx_liabilities_user on public.liabilities(user_id);

drop trigger if exists trg_liabilities_updated_at on public.liabilities;
create trigger trg_liabilities_updated_at
before update on public.liabilities
for each row execute function public.set_updated_at();


-- 4.5 Stats (one row per user)
create table if not exists public.stats (
  user_id uuid primary key references auth.users(id) on delete cascade default auth.uid(),

  total_networth_krw numeric(18,2) not null default 0,
  krw_cash_total numeric(18,2) not null default 0,
  usd_value_krw numeric(18,2) not null default 0,
  stock_value_krw numeric(18,2) not null default 0,

  total_liability_krw numeric(18,2) not null default 0,
  interest_cost_this_month numeric(18,2) not null default 0,

  card_bill_this_month numeric(18,2) not null default 0,
  expense_this_month numeric(18,2) not null default 0,
  income_this_month numeric(18,2) not null default 0,

  updated_at timestamptz not null default now()
);

drop trigger if exists trg_stats_updated_at on public.stats;
create trigger trg_stats_updated_at
before update on public.stats
for each row execute function public.set_updated_at();


-- =========================================================
-- 5) Transactions (Ledger)
-- =========================================================

-- =========================================================
-- 3.X Categories (user-scoped; for dropdown & FK validation)
-- =========================================================
create table if not exists public.categories (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  category_id uuid not null default gen_random_uuid(),

  category_name text not null,
  category_kind text not null default '공용'
    constraint chk_categories_kind check (category_kind in ('지출','수입','공용')),

  is_active boolean not null default true,
  sort_order int not null default 0,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint pk_categories primary key (user_id, category_id),
  constraint uq_categories_user_name unique (user_id, category_name)
);

create index if not exists idx_categories_user_active_sort
  on public.categories(user_id, is_active, sort_order, category_name);

drop trigger if exists trg_categories_updated_at on public.categories;
create trigger trg_categories_updated_at
before update on public.categories
for each row execute function public.set_updated_at();

-- Patch-safe: ensure categories RLS/policy/grants can be applied later in section 7/8/9


create table if not exists public.transactions (
  transaction_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  date timestamptz not null,
  type transaction_type not null,

  category_id uuid null,
  category text null, -- legacy display (category_name snapshot)
  merchant text null,
  memo text null,

  amount numeric(18,2) not null,
  currency currency_code not null,

  account_id uuid null references public.accounts(account_id) on delete set null,
  to_account_id uuid null references public.accounts(account_id) on delete set null, -- v1.3 transfer support

  card_id uuid null references public.cards(card_id) on delete set null,
  stock_id uuid null references public.stocks(stock_id) on delete set null,

  qty numeric(18,6) null,
  fx_rate numeric(18,6) null,

  liability_id uuid null references public.liabilities(liability_id) on delete set null,

  is_correction boolean not null default false,
  linked_transaction_id uuid null references public.transactions(transaction_id) on delete set null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- category enforcement (expense/income must reference categories)
  constraint fk_transactions_category
    foreign key (user_id, category_id)
    references public.categories(user_id, category_id)
    on delete restrict,
  constraint chk_transactions_category_required
    check (case when type in ('지출','수입') then category_id is not null else true end),

  constraint chk_transactions_amount_positive check (amount >= 0),
  constraint chk_transactions_fx_rate_positive check (fx_rate is null or fx_rate > 0)
);

create index if not exists idx_transactions_user_date
  on public.transactions(user_id, date desc);

create index if not exists idx_transactions_user_type_date
  on public.transactions(user_id, type, date desc);


create index if not exists idx_transactions_user_category_date
  on public.transactions(user_id, category_id, date desc)
  where category_id is not null;

create index if not exists idx_transactions_user_merchant_date
  on public.transactions(user_id, merchant, date desc)
  where merchant is not null;

create index if not exists idx_transactions_user_stock_date
  on public.transactions(user_id, stock_id, date desc)
  where stock_id is not null;

create index if not exists idx_transactions_user_liability_date
  on public.transactions(user_id, liability_id, date desc)
  where liability_id is not null;

create index if not exists idx_transactions_user_to_account_date
  on public.transactions(user_id, to_account_id, date desc)
  where to_account_id is not null;

drop trigger if exists trg_transactions_updated_at on public.transactions;
create trigger trg_transactions_updated_at
before update on public.transactions
for each row execute function public.set_updated_at();


-- =========================================================
-- 6) v1.3 Added Tables
-- =========================================================

-- 6.1 Account Balances
create table if not exists public.account_balances (
  balance_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  account_id uuid not null references public.accounts(account_id) on delete cascade,
  currency currency_code not null default 'KRW',

  balance numeric(18,2) not null default 0,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_account_balances_user_account_currency unique (user_id, account_id, currency)
);

create index if not exists idx_account_balances_user on public.account_balances(user_id);
create index if not exists idx_account_balances_account on public.account_balances(account_id);

drop trigger if exists trg_account_balances_updated_at on public.account_balances;
create trigger trg_account_balances_updated_at
before update on public.account_balances
for each row execute function public.set_updated_at();


-- 6.2 Stock Prices (per-user)
create table if not exists public.stock_prices (
  stock_price_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  stock_id uuid not null references public.stocks(stock_id) on delete cascade,

  price numeric(18,6) not null,
  currency currency_code not null,

  source text null,
  updated_at_source timestamptz not null default now(),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_stock_prices_user_stock unique (user_id, stock_id),
  constraint chk_stock_prices_positive check (price > 0)
);

create index if not exists idx_stock_prices_user on public.stock_prices(user_id);
create index if not exists idx_stock_prices_stock on public.stock_prices(stock_id);

drop trigger if exists trg_stock_prices_updated_at on public.stock_prices;
create trigger trg_stock_prices_updated_at
before update on public.stock_prices
for each row execute function public.set_updated_at();


-- =========================================================
-- 7) RLS Enable
-- =========================================================
alter table public.accounts enable row level security;
alter table public.cards enable row level security;
alter table public.stocks enable row level security;
alter table public.holdings enable row level security;
alter table public.fx_rates enable row level security;
alter table public.currency_wallet enable row level security;
alter table public.liabilities enable row level security;
alter table public.stats enable row level security;
alter table public.categories enable row level security;
alter table public.transactions enable row level security;
alter table public.account_balances enable row level security;
alter table public.stock_prices enable row level security;

-- =========================================================
-- 8) Policies (owner-only)
-- NOTE: using + with check are required to allow inserts
-- =========================================================

-- Accounts
drop policy if exists "accounts_owner_all" on public.accounts;
create policy "accounts_owner_all" on public.accounts
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Cards
drop policy if exists "cards_owner_all" on public.cards;
create policy "cards_owner_all" on public.cards
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Stocks
drop policy if exists "stocks_owner_all" on public.stocks;
create policy "stocks_owner_all" on public.stocks
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Holdings
drop policy if exists "holdings_owner_all" on public.holdings;
create policy "holdings_owner_all" on public.holdings
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- FX Rates
drop policy if exists "fx_rates_owner_all" on public.fx_rates;
create policy "fx_rates_owner_all" on public.fx_rates
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Currency Wallet
drop policy if exists "currency_wallet_owner_all" on public.currency_wallet;
create policy "currency_wallet_owner_all" on public.currency_wallet
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Liabilities
drop policy if exists "liabilities_owner_all" on public.liabilities;
create policy "liabilities_owner_all" on public.liabilities
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Stats
drop policy if exists "stats_owner_all" on public.stats;
create policy "stats_owner_all" on public.stats
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);


-- Categories
drop policy if exists "categories_owner_all" on public.categories;
create policy "categories_owner_all" on public.categories
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Transactions
drop policy if exists "transactions_owner_all" on public.transactions;
create policy "transactions_owner_all" on public.transactions
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Account Balances
drop policy if exists "account_balances_owner_all" on public.account_balances;
create policy "account_balances_owner_all" on public.account_balances
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Stock Prices
drop policy if exists "stock_prices_owner_all" on public.stock_prices;
create policy "stock_prices_owner_all" on public.stock_prices
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);


-- =========================================================
-- 9) Grants (authenticated role)
-- =========================================================
grant usage on schema public to authenticated;

grant select, insert, update, delete on public.accounts to authenticated;
grant select, insert, update, delete on public.cards to authenticated;
grant select, insert, update, delete on public.stocks to authenticated;
grant select, insert, update, delete on public.holdings to authenticated;
grant select, insert, update, delete on public.fx_rates to authenticated;
grant select, insert, update, delete on public.currency_wallet to authenticated;
grant select, insert, update, delete on public.liabilities to authenticated;
grant select, insert, update, delete on public.stats to authenticated;
grant select, insert, update, delete on public.categories to authenticated;
grant select, insert, update, delete on public.transactions to authenticated;
grant select, insert, update, delete on public.account_balances to authenticated;
grant select, insert, update, delete on public.stock_prices to authenticated;


-- =========================================================
-- 10) RPC Helpers
-- =========================================================

-- 10.1 Ensure stats row exists
create or replace function public.ensure_stats_row(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.stats(user_id)
  values (p_user_id)
  on conflict (user_id) do nothing;
end;
$$;

grant execute on function public.ensure_stats_row(uuid) to authenticated;


-- 10.2 Ensure account balance row exists
create or replace function public.ensure_account_balance_row(
  p_user_id uuid,
  p_account_id uuid,
  p_currency currency_code
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.account_balances(user_id, account_id, currency, balance)
  values (p_user_id, p_account_id, p_currency, 0)
  on conflict (user_id, account_id, currency) do nothing;
end;
$$;

grant execute on function public.ensure_account_balance_row(uuid, uuid, currency_code) to authenticated;


-- =========================================================
-- 11) Stats Recalculation
-- =========================================================
create or replace function public.refresh_stats(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_krw_cash numeric(18,2);
  v_usd_value_krw numeric(18,2);
  v_stock_value_krw numeric(18,2);
  v_total_liability numeric(18,2);
  v_usdkrw numeric(18,6);
begin
  -- KRW cash total (only included accounts)
  select coalesce(sum(ab.balance), 0)
    into v_krw_cash
  from public.account_balances ab
  join public.accounts a on a.account_id = ab.account_id
  where ab.user_id = p_user_id
    and ab.currency = 'KRW'
    and a.is_include_in_networth = true;

  -- USD value in KRW (wallet)
  select coalesce(sum(est_value_krw), 0)
    into v_usd_value_krw
  from public.currency_wallet
  where user_id = p_user_id;

  -- USDKRW rate
  select rate into v_usdkrw
  from public.fx_rates
  where user_id = p_user_id and pair = 'USDKRW'
  limit 1;

  if v_usdkrw is null then
    v_usdkrw := 0;
  end if;

  -- Stock value in KRW (requires stock_prices)
  select coalesce(sum(
      case
        when sp.currency = 'KRW' then h.holdings_qty * sp.price
        when sp.currency = 'USD' then h.holdings_qty * sp.price * v_usdkrw
        else 0
      end
    ), 0)
    into v_stock_value_krw
  from public.holdings h
  join public.stock_prices sp
    on sp.user_id = h.user_id and sp.stock_id = h.stock_id
  where h.user_id = p_user_id;

  -- Total liabilities
  select coalesce(sum(principal_remaining), 0)
    into v_total_liability
  from public.liabilities
  where user_id = p_user_id
    and is_include_in_networth = true;

  -- Update stats
  update public.stats
  set
    krw_cash_total = v_krw_cash,
    usd_value_krw = v_usd_value_krw,
    stock_value_krw = v_stock_value_krw,
    total_liability_krw = v_total_liability,
    total_networth_krw = v_krw_cash + v_usd_value_krw + v_stock_value_krw - v_total_liability,
    updated_at = now()
  where user_id = p_user_id;
end;
$$;

grant execute on function public.refresh_stats(uuid) to authenticated;


-- =========================================================
-- 12) Main RPC: process_transaction_v2 (Atomic)
-- =========================================================
create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  -- v1.3.2: category FK + merchant
  p_category_id uuid default null,
  p_merchant text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;

  -- v1.3.2: category FK enforcement
  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_month_start timestamptz := (date_trunc('month', timezone('Asia/Seoul', now())) at time zone 'Asia/Seoul');
  v_month_end timestamptz := ((date_trunc('month', timezone('Asia/Seoul', now())) + interval '1 month') at time zone 'Asia/Seoul');

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;

  v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;


  -- Resolve & validate category (FK)
  -- NOTE: DB constraint also enforces category_id for 지출/수입. This keeps error messages user-friendly.
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    -- Other types: category is optional; if category_id is provided, validate it.
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- [v1.3.1] Currency guard:
    -- Prevent KRW account -> USD account transfer without explicit FX transaction.
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  if p_type in ('지출','수입','수수료','세금','배당금') then
    if p_account_id is null then
      raise exception 'account_id is required for this transaction type';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id
  )
  returning transaction_id into v_tx_id;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates
  if p_type = '주식_매수' then
    v_delta_qty := p_qty;
  elsif p_type = '주식_매도' then
    v_delta_qty := -p_qty;
  end if;

  if v_delta_qty <> 0 then
    insert into public.holdings(user_id, stock_id, holdings_qty, last_updated)
    values (v_user_id, p_stock_id, greatest(v_delta_qty, 0), now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = public.holdings.holdings_qty + v_delta_qty,
      last_updated = now();

    if exists (
      select 1 from public.holdings
      where user_id = v_user_id and stock_id = p_stock_id and holdings_qty < 0
    ) then
      raise exception 'Holdings cannot be negative (stock_id=%)', p_stock_id;
    end if;
  end if;

  -- Liabilities principal update
  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Monthly KPI accumulation (simple)
  if p_date >= v_month_start and p_date < v_month_end then
    if p_type in ('지출','수수료','세금','대출_상환_이자') then
      update public.stats
      set expense_this_month = expense_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type in ('수입','배당금') then
      update public.stats
      set income_this_month = income_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type = '대출_상환_이자' then
      update public.stats
      set interest_cost_this_month = interest_cost_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);

  return v_tx_id;
end;
$$;

grant execute on function public.process_transaction_v2(
  timestamptz,
  transaction_type,
  numeric,
  currency_code,
  uuid,
  uuid,
  uuid,
  uuid,
  numeric,
  numeric,
  uuid,
  text,
  text,
  boolean,
  uuid,
  uuid,
  text
) to authenticated;


-- =========================================================
-- 12B) RPC: reverse_transaction (Safe cancellation)
-- =========================================================
create or replace function public.reverse_transaction(
  p_transaction_id uuid,
  p_reason text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;

  v_reverse_type transaction_type;
  v_reverse_account_id uuid;
  v_reverse_to_account_id uuid;
  v_reverse_memo text;

  v_new_tx_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_org
  from public.transactions
  where transaction_id = p_transaction_id
    and user_id = v_user_id;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot reverse a correction transaction';
  end if;

  -- Determine reverse mapping
  v_reverse_account_id := v_org.account_id;
  v_reverse_to_account_id := v_org.to_account_id;

  if v_org.type = '지출' then
    v_reverse_type := '수입';
  elsif v_org.type = '수입' then
    v_reverse_type := '지출';
  elsif v_org.type = '배당금' then
    v_reverse_type := '지출';
  elsif v_org.type in ('수수료','세금','대출_상환_이자') then
    v_reverse_type := '수입';
  elsif v_org.type = '대출_실행' then
    v_reverse_type := '대출_상환_원금';
  elsif v_org.type = '대출_상환_원금' then
    v_reverse_type := '대출_실행';
  elsif v_org.type = '주식_매수' then
    v_reverse_type := '주식_매도';
  elsif v_org.type = '주식_매도' then
    v_reverse_type := '주식_매수';
  elsif v_org.type = '환전_매수' then
    v_reverse_type := '환전_매도';
  elsif v_org.type = '환전_매도' then
    v_reverse_type := '환전_매수';
  elsif v_org.type = '이체' then
    v_reverse_type := '이체';
    -- swap directions
    v_reverse_account_id := v_org.to_account_id;
    v_reverse_to_account_id := v_org.account_id;
  else
    raise exception 'Unsupported reverse mapping for type=%', v_org.type;
  end if;

  v_reverse_memo :=
    coalesce('[REVERSAL] ' || p_reason, '[REVERSAL]') ||
    ' (orig=' || v_org.transaction_id::text || ')';

  -- Create opposite entry via main RPC
  v_new_tx_id := public.process_transaction_v2(
    v_org.date,                    -- same date (or now() if preferred)
    v_reverse_type,
    v_org.amount,
    v_org.currency,
    v_reverse_account_id,
    v_reverse_to_account_id,
    v_org.card_id,
    v_org.stock_id,
    v_org.qty,
    v_org.fx_rate,
    v_org.liability_id,
    v_org.category,
    v_reverse_memo,
    true,                          -- is_correction
    v_org.transaction_id,          -- linked_transaction_id
    v_org.category_id,             -- category_id (v1.3.2)
    v_org.merchant                 -- merchant (v1.3.2)
  );

  return v_new_tx_id;
end;
$$;

grant execute on function public.reverse_transaction(uuid, text) to authenticated;



-- =========================================================
-- 13) Ops: New user trigger -> create stats row
-- =========================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.stats(user_id)
  values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();


-- =========================================================
-- 14) Ops: Reset monthly KPI (manual/app-triggered)
-- =========================================================
create or replace function public.reset_monthly_stats()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  update public.stats
  set
    expense_this_month = 0,
    income_this_month = 0,
    card_bill_this_month = 0,
    interest_cost_this_month = 0,
    updated_at = now()
  where user_id = v_user_id;
end;
$$;

grant execute on function public.reset_monthly_stats() to authenticated;


-- =========================================================
-- 15) Convenience View: Dashboard
-- =========================================================
create or replace view public.v_dashboard as
select
  s.user_id,
  s.total_networth_krw,
  s.krw_cash_total,
  s.usd_value_krw,
  s.stock_value_krw,
  s.total_liability_krw,

  s.expense_this_month,
  s.income_this_month,
  s.card_bill_this_month,
  s.interest_cost_this_month,

  fr.rate as usdkrw_rate,
  s.updated_at
from public.stats s
left join public.fx_rates fr
  on fr.user_id = s.user_id and fr.pair = 'USDKRW';

grant select on public.v_dashboard to authenticated;

-- =====================================================================
-- END OF All-in-One SQL
-- =====================================================================

-- =====================================================================
-- PATCH: v1.3.1_patch_and_edge_tests (applied)
-- =====================================================================

create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  -- v1.3.2: category FK + merchant
  p_category_id uuid default null,
  p_merchant text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;

  -- v1.3.2: category FK enforcement
  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_month_start timestamptz := (date_trunc('month', timezone('Asia/Seoul', now())) at time zone 'Asia/Seoul');
  v_month_end timestamptz := ((date_trunc('month', timezone('Asia/Seoul', now())) + interval '1 month') at time zone 'Asia/Seoul');

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;
  v_current_holdings numeric := 0;

  v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;


  -- Resolve & validate category (FK)
  -- NOTE: DB constraint also enforces category_id for 지출/수입. This keeps error messages user-friendly.
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    -- Other types: category is optional; if category_id is provided, validate it.
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- [v1.3.1] Currency guard:
    -- Prevent KRW account -> USD account transfer without explicit FX transaction.
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  if p_type in ('지출','수입','수수료','세금','배당금') then
    if p_account_id is null then
      raise exception 'account_id is required for this transaction type';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id
  )
  returning transaction_id into v_tx_id;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates (patched: prevent sell without holdings row)
  if p_type = '주식_매수' then
    insert into public.holdings(user_id, stock_id, holdings_qty, last_updated)
    values (v_user_id, p_stock_id, p_qty, now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = public.holdings.holdings_qty + excluded.holdings_qty,
      last_updated = now();

  elsif p_type = '주식_매도' then
    select holdings_qty into v_current_holdings
    from public.holdings
    where user_id = v_user_id and stock_id = p_stock_id
    for update;

    if not found then
      raise exception 'Insufficient holdings (stock_id=% current=0 sell=%)', p_stock_id, p_qty;
    end if;

    if v_current_holdings < p_qty then
      raise exception 'Insufficient holdings (stock_id=% current=% sell=%)', p_stock_id, v_current_holdings, p_qty;
    end if;

    update public.holdings
    set holdings_qty = holdings_qty - p_qty,
        last_updated = now()
    where user_id = v_user_id and stock_id = p_stock_id;
  end if;

  -- Liabilities principal update

  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Monthly KPI accumulation (simple)
  if p_date >= v_month_start and p_date < v_month_end then
    if p_type in ('지출','수수료','세금','대출_상환_이자') then
      update public.stats
      set expense_this_month = expense_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type in ('수입','배당금') then
      update public.stats
      set income_this_month = income_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type = '대출_상환_이자' then
      update public.stats
      set interest_cost_this_month = interest_cost_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);

  return v_tx_id;
end;
$$;

create or replace function public.run_edge_tests(p_user_id uuid)
returns table(test_name text, status text, detail text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_acc_bank uuid;
  v_acc_sec  uuid;
  v_stock_id uuid;
  v_liab_id  uuid;
  v_usd_acc  uuid;
  v_tx_id    uuid;
begin
  -- SQL Editor에서도 auth.uid() 인식시키기 (테스트용)
  perform set_config('request.jwt.claim.sub',  p_user_id::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);

  -- 테스트 대상 엔티티 찾기 (기본 테스트 데이터 기준)
  select account_id into v_acc_bank
  from public.accounts
  where user_id = p_user_id and account_name = '주거래계좌'
  limit 1;

  select account_id into v_acc_sec
  from public.accounts
  where user_id = p_user_id and account_name = '증권계좌'
  limit 1;

  select stock_id into v_stock_id
  from public.stocks
  where user_id = p_user_id and ticker = '005930'
  limit 1;

  select liability_id into v_liab_id
  from public.liabilities
  where user_id = p_user_id and liability_name = '주택담보대출'
  limit 1;

  if v_acc_bank is null or v_acc_sec is null or v_stock_id is null or v_liab_id is null then
    return query
    select
      'PRECHECK'::text,
      'FAIL'::text,
      '필수 데이터 없음 (주거래계좌/증권계좌/005930/주택담보대출 확인)'::text;
    return;
  end if;


  -- Ensure required category exists for tests (category FK enforcement)
  insert into public.categories(user_id, category_name, category_kind, is_active, sort_order)
  values (p_user_id, '테스트', '공용', true, 0)
  on conflict (user_id, category_name) do update
  set is_active = true;

  ------------------------------------------------------------------
  -- T1) 계좌 잔액 음수 방지: 잔액 0에서 1원 지출은 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 0)
    on conflict (user_id, account_id, currency) do update set balance = 0;

    v_tx_id := public.process_transaction_v2(
      now(), '지출', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      null,
      '테스트', 'T1: 잔액음수',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id; -- 성공하면 일부러 예외로 롤백
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T1 잔액 음수 방지', 'FAIL', sqlerrm;
    else
      return query select 'T1 잔액 음수 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T2) 주식 초과 매도 방지: 보유 1에서 2 매도는 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.holdings(user_id, stock_id, holdings_qty)
    values (p_user_id, v_stock_id, 1)
    on conflict (user_id, stock_id) do update set holdings_qty = 1;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_id,
      2, null,
      null,
      '테스트', 'T2: 초과매도',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T2 초과 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T2 초과 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T3) 보유 row가 없는데 매도 방지: 보유 삭제 후 매도는 "막혀야"
  ------------------------------------------------------------------
  begin
    delete from public.holdings
    where user_id = p_user_id and stock_id = v_stock_id;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_id,
      1, null,
      null,
      '테스트', 'T3: 보유없는데 매도',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T3 보유없음 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T3 보유없음 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T4) 이체 통화 불일치 방지: KRW -> USD 계좌로 KRW 이체는 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.accounts (user_id, account_name, account_type, default_currency)
    values (p_user_id, 'USD테스트계좌', 'Bank', 'USD')
    returning account_id into v_usd_acc;

    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_usd_acc,
      null, null,
      null, null,
      null,
      '테스트', 'T4: 통화불일치이체',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T4 이체 통화불일치 방지', 'FAIL', sqlerrm;
    else
      return query select 'T4 이체 통화불일치 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T5) USD 지갑 음수 방지: USD=0인데 1 매도는 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested)
    values (p_user_id, 'USD', 0, 0)
    on conflict (user_id, currency) do update
    set total_foreign_held = 0, total_krw_invested = 0;

    -- bank 잔액쪽으로 실패하지 않게 잔액 충분히
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 999999999)
    on conflict (user_id, account_id, currency) do update set balance = 999999999;

    v_tx_id := public.process_transaction_v2(
      now(), '환전_매도', 1300, 'KRW',
      v_acc_bank, null,
      null, null,
      1, 1300,
      null,
      '테스트', 'T5: USD초과매도',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T5 USD 초과매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T5 USD 초과매도 방지', 'PASS', sqlerrm;
    end if;
  end;


  ------------------------------------------------------------------
  -- T6) 카테고리 유효성 강제: 존재하지 않는 카테고리로 지출 입력은 "막혀야"
  ------------------------------------------------------------------
  begin
    -- bank 잔액쪽으로 실패하지 않게 잔액 충분히
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 999999999)
    on conflict (user_id, account_id, currency) do update set balance = 999999999;

    v_tx_id := public.process_transaction_v2(
      now(), '지출', 1000, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      null,
      '없는카테고리', 'T6: 카테고리없음',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T6 카테고리 유효성(없음) 방지', 'FAIL', sqlerrm;
    else
      return query select 'T6 카테고리 유효성(없음) 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T6) 대출 원금 초과 상환 방지: principal=0인데 1 상환은 "막혀야"
  ------------------------------------------------------------------
  begin
    update public.liabilities
    set principal_remaining = 0
    where user_id = p_user_id and liability_id = v_liab_id;

    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 1000000)
    on conflict (user_id, account_id, currency) do update set balance = 1000000;

    v_tx_id := public.process_transaction_v2(
      now(), '대출_상환_원금', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      v_liab_id,
      '테스트', 'T6: 원금초과상환',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T6 원금 초과상환 방지', 'FAIL', sqlerrm;
    else
      return query select 'T6 원금 초과상환 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T7) 동일 계좌 이체 방지: from=to는 "막혀야"
  ------------------------------------------------------------------
  begin
    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_acc_bank,
      null, null,
      null, null,
      null,
      '테스트', 'T7: 동일계좌이체',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T7 동일계좌 이체 방지', 'FAIL', sqlerrm;
    else
      return query select 'T7 동일계좌 이체 방지', 'PASS', sqlerrm;
    end if;
  end;

end $$;

-- =====================================================================
-- ADD-ON: KIS Integration & Performance
-- =====================================================================

-- =====================================================================
-- PAD v1.3.1 (patched) - KIS Integration & Performance Add-on
-- Base required:
--   - Personal_Asset_Dashboard_All-in-One_v1.3.1_FINAL.sql applied
--   - PAD_v1.3.1_patch_and_edge_tests.md patch applied (process_transaction_v2 fix + run_edge_tests)
--
-- Purpose:
--   - Store KIS identifiers for US stocks (exchange/market/product-type) to remove guesswork.
--   - Add NAV daily snapshots and performance metrics (MDD, 12M win-rate) with integrity guarantees.
--   - Provide DB-side functions that Edge Functions can call AFTER they upsert stock_prices/fx_rates.
--
-- Notes (integrity-first):
--   - External calls to KIS are NOT done in DB. Edge Functions only.
--   - NAV snapshots are derived from public.stats.total_networth_krw AFTER refresh_stats().
--   - US-stock KIS fields are enforced via NOT VALID constraint (safe for existing data).
-- =====================================================================

begin;

-- 0) Helper: detect service_role (Edge Function with service key)
create or replace function public.is_service_role()
returns boolean
language sql
stable
as $$
  select coalesce(current_setting('request.jwt.claim.role', true), '') in ('service_role', 'supabase_admin');
$$;

-- 1) stocks: add KIS master fields (US uses these to fetch quotes reliably)
alter table public.stocks
  add column if not exists kis_prdt_type_cd text null,
  add column if not exists kis_excd text null,
  add column if not exists kis_tr_mket_cd text null;

comment on column public.stocks.kis_prdt_type_cd is
  'KIS 해외주식 상품유형코드(PRDT_TYPE_CD). 예: 512(US NASDAQ), 513(US NYSE), 529(US AMEX)';
comment on column public.stocks.kis_excd is
  'KIS 해외주식 현재가상세(PRICE-DETAIL) API EXCD. 예: NAS/NYS/AMS/HKS...';
comment on column public.stocks.kis_tr_mket_cd is
  'KIS 해외주식 상품기본정보(search-info) 응답의 거래시장코드(tr_mket_cd)';

-- US 종목은 KIS 식별자 없이 시세 갱신이 불가능하므로, 제약으로 강제(기존 데이터 보호 위해 NOT VALID)
alter table public.stocks
  drop constraint if exists chk_stocks_us_kis_required;

alter table public.stocks
  add constraint chk_stocks_us_kis_required
  check (
    market <> 'US'
    or (kis_prdt_type_cd is not null and kis_excd is not null)
  ) not valid;

-- 2) Optional: FX pair mapping (KIS FX daily chart requires master code as FID_INPUT_ISCD)
create table if not exists public.fx_pair_map (
  pair text primary key,           -- e.g. 'USDKRW'
  kis_fid_input_iscd text not null, -- master code from KIS 해외주식 마스터 (환율)
  description text null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.fx_pair_map enable row level security;

drop policy if exists "fx_pair_map_owner_all" on public.fx_pair_map;
create policy "fx_pair_map_owner_all" on public.fx_pair_map
for all
using ((select public.is_service_role()) or (select auth.uid()) is not null) -- read/write is typically admin; keep open for authenticated for setup
with check ((select public.is_service_role()) or (select auth.uid()) is not null);

grant select, insert, update, delete on public.fx_pair_map to authenticated;

drop trigger if exists trg_fx_pair_map_updated_at on public.fx_pair_map;
create trigger trg_fx_pair_map_updated_at
before update on public.fx_pair_map
for each row execute function public.set_updated_at();

-- 3) Audit log for market data sync runs (optional but recommended for integrity & debugging)
create table if not exists public.market_data_sync_runs (
  run_id uuid primary key default gen_random_uuid(),
  user_id uuid null references auth.users(id) on delete cascade, -- null when 'all users'
  mode text not null,              -- 'manual' | 'scheduled'
  market text not null,            -- 'KR' | 'US' | 'ALL'
  status text not null,            -- 'STARTED' | 'SUCCESS' | 'FAILED' | 'PARTIAL'
  started_at timestamptz not null default now(),
  finished_at timestamptz null,
  market_data_asof timestamptz null,
  provider text null,
  detail jsonb null
);

alter table public.market_data_sync_runs enable row level security;

drop policy if exists "market_data_sync_runs_owner_read" on public.market_data_sync_runs;
create policy "market_data_sync_runs_owner_read" on public.market_data_sync_runs
for select
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

drop policy if exists "market_data_sync_runs_service_write" on public.market_data_sync_runs;
create policy "market_data_sync_runs_service_write" on public.market_data_sync_runs
for insert
with check ((select public.is_service_role()));

drop policy if exists "market_data_sync_runs_service_update" on public.market_data_sync_runs;
create policy "market_data_sync_runs_service_update" on public.market_data_sync_runs
for update
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

grant select on public.market_data_sync_runs to authenticated;
grant insert, update on public.market_data_sync_runs to authenticated;

-- 4) NAV daily snapshots (derived from stats AFTER refresh_stats)
create table if not exists public.portfolio_nav_daily (
  nav_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  trading_date date not null,
  nav_krw numeric(18,2) not null,
  market_data_asof timestamptz not null,
  source text null default 'KIS',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint uq_portfolio_nav_daily unique (user_id, trading_date),
  constraint chk_nav_non_negative check (nav_krw >= 0)
);

create index if not exists idx_portfolio_nav_daily_user_date
  on public.portfolio_nav_daily(user_id, trading_date desc);

alter table public.portfolio_nav_daily enable row level security;

drop policy if exists "portfolio_nav_daily_owner_all" on public.portfolio_nav_daily;
create policy "portfolio_nav_daily_owner_all" on public.portfolio_nav_daily
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.portfolio_nav_daily to authenticated;

drop trigger if exists trg_portfolio_nav_daily_updated_at on public.portfolio_nav_daily;
create trigger trg_portfolio_nav_daily_updated_at
before update on public.portfolio_nav_daily
for each row execute function public.set_updated_at();

-- 5) Monthly returns cache (for win-rate)
create table if not exists public.portfolio_returns_monthly (
  month_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  month_start date not null, -- first day of month
  nav_start_krw numeric(18,2) not null,
  nav_end_krw numeric(18,2) not null,
  return_pct numeric(10,6) not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint uq_portfolio_returns_monthly unique (user_id, month_start),
  constraint chk_monthly_nav_non_negative check (nav_start_krw >= 0 and nav_end_krw >= 0)
);

create index if not exists idx_portfolio_returns_monthly_user_month
  on public.portfolio_returns_monthly(user_id, month_start desc);

alter table public.portfolio_returns_monthly enable row level security;

drop policy if exists "portfolio_returns_monthly_owner_all" on public.portfolio_returns_monthly;
create policy "portfolio_returns_monthly_owner_all" on public.portfolio_returns_monthly
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.portfolio_returns_monthly to authenticated;

drop trigger if exists trg_portfolio_returns_monthly_updated_at on public.portfolio_returns_monthly;
create trigger trg_portfolio_returns_monthly_updated_at
before update on public.portfolio_returns_monthly
for each row execute function public.set_updated_at();

-- 6) Current metrics (MDD, win-rate)
create table if not exists public.portfolio_metrics (
  user_id uuid primary key references auth.users(id) on delete cascade default auth.uid(),
  asof_date date not null default current_date,
  mdd_pct numeric(10,6) null, -- negative (e.g. -0.1532)
  lookback_days int not null default 365,
  months_count_12m int null,
  positive_months_12m int null,
  win_rate_12m numeric(10,6) null,
  updated_at timestamptz not null default now()
);

alter table public.portfolio_metrics enable row level security;

drop policy if exists "portfolio_metrics_owner_all" on public.portfolio_metrics;
create policy "portfolio_metrics_owner_all" on public.portfolio_metrics
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.portfolio_metrics to authenticated;

-- 7) Functions: capture snapshot + rebuild monthly + update metrics
create or replace function public.capture_nav_snapshot(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'KIS'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_usdkrw numeric(18,6);
  v_cash_krw numeric(18,2);
  v_usd_qty numeric(18,6);
  v_usd_value_krw numeric(18,2);
  v_stock_value_krw numeric(18,2);
  v_liability_krw numeric(18,2);
  v_nav numeric(18,2);
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  -- USDKRW rate (strict for rebuild)
  if p_source = 'REBUILD' then
    select rate into v_usdkrw
    from public.fx_rates_daily
    where user_id = p_user_id and trading_date = p_trading_date and pair='USDKRW'
    limit 1;

    if v_usdkrw is null then
      raise exception 'Missing fx_rates_daily (USDKRW) for % (user_id=%). Backfill daily FX rates before rebuild.', p_trading_date, p_user_id;
    end if;
  else
    select coalesce(
      (select rate from public.fx_rates_daily where user_id=p_user_id and trading_date=p_trading_date and pair='USDKRW' limit 1),
      (select rate from public.fx_rates where user_id=p_user_id and pair='USDKRW' limit 1),
      0
    ) into v_usdkrw;
  end if;

  -- Cash total (as-of) from ledger deltas, only included accounts
  with out_tx as (
    select
      t.account_id,
      t.currency,
      sum(case
        when t.type in ('지출','수수료','세금','카드_대금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then -t.amount
        when t.type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then +t.amount
        when t.type = '이체' then -t.amount
        else 0
      end) as delta
    from public.transactions t
    join public.accounts a
      on a.user_id = t.user_id and a.account_id = t.account_id and a.is_include_in_networth = true
    where t.user_id = p_user_id
      and t.account_id is not null
      and t.is_voided = false
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.account_id, t.currency
  ),
  in_tx as (
    select
      t.to_account_id as account_id,
      t.currency,
      sum(t.amount) as delta
    from public.transactions t
    join public.accounts a
      on a.user_id = t.user_id and a.account_id = t.to_account_id and a.is_include_in_networth = true
    where t.user_id = p_user_id
      and t.type = '이체'
      and t.to_account_id is not null
      and t.is_voided = false
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.to_account_id, t.currency
  ),
  balances as (
    select account_id, currency, sum(delta) as balance
    from (
      select * from out_tx
      union all
      select * from in_tx
    ) u
    group by account_id, currency
  )
  select round(coalesce(sum(
    case
      when currency='KRW' then balance
      when currency='USD' then balance * v_usdkrw
      else 0
    end
  ),0),2) into v_cash_krw
  from balances;

  -- USD wallet (as-of) from FX trades qty, valued at daily usdkrw
  select coalesce(sum(
    case
      when t.type='환전_매수' then t.qty
      when t.type='환전_매도' then -t.qty
      else 0
    end
  ),0) into v_usd_qty
  from public.transactions t
  where t.user_id = p_user_id
    and t.is_voided = false
    and t.is_correction = false
    and t.type in ('환전_매수','환전_매도')
    and t.qty is not null
    and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date;

  v_usd_value_krw := round(coalesce(v_usd_qty,0) * v_usdkrw, 2);

  -- Stock value (as-of) from account_stock_nav_daily (should be captured first)
  select round(coalesce(sum(value_krw),0),2) into v_stock_value_krw
  from public.account_stock_nav_daily
  where user_id = p_user_id and trading_date = p_trading_date;

  -- Loan liabilities (as-of) from ledger (principal only)
  with loan as (
    select
      t.liability_id,
      sum(case
        when t.type='대출_실행' then t.amount
        when t.type='대출_상환_원금' then -t.amount
        else 0
      end) as principal
    from public.transactions t
    where t.user_id = p_user_id
      and t.liability_id is not null
      and t.is_voided = false
      and t.type in ('대출_실행','대출_상환_원금')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.liability_id
  )
  select round(coalesce(sum(
    case
      when l.currency='KRW' then loan.principal
      when l.currency='USD' then loan.principal * v_usdkrw
      else 0
    end
  ),0),2) into v_liability_krw
  from loan
  join public.liabilities l
    on l.user_id = p_user_id and l.liability_id = loan.liability_id
  where l.is_include_in_networth = true;

  v_nav := v_cash_krw + v_usd_value_krw + v_stock_value_krw - v_liability_krw;

  insert into public.portfolio_nav_daily(user_id, trading_date, nav_krw, market_data_asof, source)
  values (p_user_id, p_trading_date, v_nav, p_market_data_asof, p_source)
  on conflict (user_id, trading_date)
  do update set
    nav_krw = excluded.nav_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();
end;
$$;


grant execute on function public.capture_nav_snapshot(uuid, date, timestamptz, text) to authenticated;

create or replace function public.rebuild_monthly_returns(
  p_user_id uuid,
  p_months int default 24
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_start date;
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_months is null or p_months < 1 then raise exception 'p_months must be >= 1'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  v_start := (date_trunc('month', current_date)::date - (p_months || ' months')::interval)::date;

  with nav as (
    select trading_date, nav_krw
    from public.portfolio_nav_daily
    where user_id = p_user_id and trading_date >= v_start
  ),
  per_month as (
    select
      date_trunc('month', trading_date)::date as month_start,
      (array_agg(nav_krw order by trading_date asc))[1] as nav_start,
      (array_agg(nav_krw order by trading_date asc))[array_length(array_agg(nav_krw), 1)] as nav_end
    from nav
    group by 1
  )
  insert into public.portfolio_returns_monthly(user_id, month_start, nav_start_krw, nav_end_krw, return_pct)
  select
    p_user_id,
    month_start,
    nav_start,
    nav_end,
    case when nav_start > 0 then (nav_end / nav_start - 1) else 0 end
  from per_month
  on conflict (user_id, month_start)
  do update set
    nav_start_krw = excluded.nav_start_krw,
    nav_end_krw = excluded.nav_end_krw,
    return_pct = excluded.return_pct,
    updated_at = now();
end;
$$;

grant execute on function public.rebuild_monthly_returns(uuid, int) to authenticated;

create or replace function public.update_portfolio_metrics(
  p_user_id uuid,
  p_asof_date date default current_date,
  p_lookback_days int default 365
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_mdd numeric(10,6);
  v_months_count int;
  v_pos_months int;
  v_win_rate numeric(10,6);
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_asof_date is null then raise exception 'p_asof_date is required'; end if;
  if p_lookback_days is null or p_lookback_days < 1 then raise exception 'p_lookback_days must be >= 1'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  -- MDD over lookback window
  with nav as (
    select trading_date, nav_krw,
           max(nav_krw) over (order by trading_date rows between unbounded preceding and current row) as peak
    from public.portfolio_nav_daily
    where user_id = p_user_id
      and trading_date <= p_asof_date
      and trading_date >= (p_asof_date - p_lookback_days)
  ),
  dd as (
    select case when peak > 0 then (nav_krw / peak - 1) else 0 end as drawdown
    from nav
  )
  select min(drawdown) into v_mdd from dd;

  perform public.rebuild_monthly_returns(p_user_id, 24);

  with m as (
    select return_pct
    from public.portfolio_returns_monthly
    where user_id = p_user_id
      and month_start >= (date_trunc('month', p_asof_date)::date - interval '11 months')::date
      and month_start <= date_trunc('month', p_asof_date)::date
  )
  select count(*)::int,
         count(*) filter (where return_pct > 0)::int
    into v_months_count, v_pos_months
  from m;

  if v_months_count is null or v_months_count = 0 then
    v_win_rate := null;
  else
    v_win_rate := (v_pos_months::numeric / v_months_count::numeric);
  end if;

  insert into public.portfolio_metrics(
    user_id, asof_date, mdd_pct, lookback_days,
    months_count_12m, positive_months_12m, win_rate_12m, updated_at
  )
  values (p_user_id, p_asof_date, v_mdd, p_lookback_days, v_months_count, v_pos_months, v_win_rate, now())
  on conflict (user_id)
  do update set
    asof_date = excluded.asof_date,
    mdd_pct = excluded.mdd_pct,
    lookback_days = excluded.lookback_days,
    months_count_12m = excluded.months_count_12m,
    positive_months_12m = excluded.positive_months_12m,
    win_rate_12m = excluded.win_rate_12m,
    updated_at = now();
end;
$$;

grant execute on function public.update_portfolio_metrics(uuid, date, int) to authenticated;

-- 8) View for MAUI dashboard
create or replace view public.v_portfolio_metrics as
select
  user_id,
  asof_date,
  mdd_pct,
  lookback_days,
  months_count_12m,
  positive_months_12m,
  win_rate_12m,
  updated_at
from public.portfolio_metrics;

grant select on public.v_portfolio_metrics to authenticated;

commit;

-- Post-migration step:
--   After you backfill US stocks with kis_prdt_type_cd/kis_excd, run:
--     ALTER TABLE public.stocks VALIDATE CONSTRAINT chk_stocks_us_kis_required;

-- =====================================================================
-- PAD v1.3.1 (patched) + KIS Add-on — Token Cache / 1-min RateLimit 대응 Add-on Migration
-- Generated: 2026-01-24 (Asia/Seoul)
-- Bundled into All-in-One
-- =====================================================================

-- 0) Safety
set statement_timeout = 0;
set lock_timeout = '10s';

begin;

-- 1) Token cache table (single row, id=1)
create table if not exists public.kis_token_cache (
  id int primary key check (id = 1),
  access_token text null,
  expires_at timestamptz null,
  -- last_issued_at: 성공적으로 토큰을 저장한 시각
  last_issued_at timestamptz null,
  -- last_attempt_at: 발급 시도(REFRESH_ALLOWED) 시각 (1분 제한 방어용)
  last_attempt_at timestamptz null,
  -- refresh_deadline: 다른 인스턴스가 갱신 중일 때 기다릴 기준시각(짧게)
  refresh_deadline timestamptz null,
  refresh_owner text null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- single row ensure
insert into public.kis_token_cache(id) values (1)
on conflict (id) do nothing;

-- RLS: service_role만 접근(Edge Function은 service_role 사용 전제)
alter table public.kis_token_cache enable row level security;
-- NOTE: 정책을 만들지 않으면 authenticated/anon은 접근 불가. service_role은 RLS bypass.

comment on table public.kis_token_cache is 'KIS access token global cache (single row). Edge Function service_role only.';

-- 2) RPC: decide token usage / refresh permission
-- 반환 JSON:
--  - action: USE_CACHE | REFRESH_ALLOWED | WAIT
--  - access_token, expires_at (USE_CACHE일 때)
--  - wait_seconds (WAIT일 때)

-- v2.3.0: Ensure token RPC signatures can be redefined (parameter name changes require DROP)
drop function if exists public.kis_token_decide(text);
drop function if exists public.kis_token_finish_refresh(text, text, timestamptz);
drop function if exists public.kis_token_fail_refresh(text, text);

create or replace function public.kis_token_decide(
  p_owner text default null,
  p_safety_seconds int default 60,
  p_min_interval_seconds int default 60,
  p_refresh_deadline_seconds int default 20
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_access_token text;
  v_expires_at timestamptz;
  v_last_attempt timestamptz;
  v_refresh_deadline timestamptz;
  v_wait int;
begin
  -- Ensure row exists
  insert into public.kis_token_cache(id) values (1)
  on conflict (id) do nothing;

  -- Serialize decision update (short critical section)
  perform pg_advisory_lock(73001331); -- project-specific constant

  select access_token, expires_at, last_attempt_at, refresh_deadline
    into v_access_token, v_expires_at, v_last_attempt, v_refresh_deadline
  from public.kis_token_cache
  where id = 1;

  -- 1) valid cache?
  if v_access_token is not null and v_expires_at is not null
     and (extract(epoch from (v_expires_at - v_now)) > p_safety_seconds)
  then
    perform pg_advisory_unlock(73001331);
    return jsonb_build_object(
      'action', 'USE_CACHE',
      'access_token', v_access_token,
      'expires_at', v_expires_at
    );
  end if;

  -- 2) someone refreshing?
  if v_refresh_deadline is not null and v_refresh_deadline > v_now then
    v_wait := ceil(extract(epoch from (v_refresh_deadline - v_now)))::int;
    perform pg_advisory_unlock(73001331);
    return jsonb_build_object('action','WAIT','wait_seconds', greatest(v_wait, 1));
  end if;

  -- 3) min interval defense (1-minute rule)
  if v_last_attempt is not null and (extract(epoch from (v_now - v_last_attempt)) < p_min_interval_seconds) then
    v_wait := ceil(p_min_interval_seconds - extract(epoch from (v_now - v_last_attempt)))::int;
    perform pg_advisory_unlock(73001331);
    return jsonb_build_object('action','WAIT','wait_seconds', greatest(v_wait, 1));
  end if;

  -- 4) allow refresh: mark short deadline & attempt time
  update public.kis_token_cache
     set refresh_deadline = v_now + make_interval(secs => p_refresh_deadline_seconds),
         refresh_owner = p_owner,
         last_attempt_at = v_now,
         updated_at = v_now
   where id = 1;

  perform pg_advisory_unlock(73001331);

  return jsonb_build_object('action','REFRESH_ALLOWED','wait_seconds',0);
exception
  when others then
    -- unlock best-effort
    begin
      perform pg_advisory_unlock(73001331);
    exception when others then
      null;
    end;
    raise;
end;
$$;

grant execute on function public.kis_token_decide(text,int,int,int) to authenticated;

-- 3) RPC: finish refresh (save token)
create or replace function public.kis_token_finish_refresh(
  p_owner text,
  p_access_token text,
  p_expires_at timestamptz
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
begin
  if p_access_token is null or length(p_access_token) = 0 then
    raise exception 'p_access_token is required';
  end if;
  if p_expires_at is null then
    raise exception 'p_expires_at is required';
  end if;

  perform pg_advisory_lock(73001331);

  update public.kis_token_cache
     set access_token = p_access_token,
         expires_at = p_expires_at,
         last_issued_at = v_now,
         refresh_deadline = null,
         refresh_owner = null,
         updated_at = v_now
   where id = 1;

  perform pg_advisory_unlock(73001331);
end;
$$;

grant execute on function public.kis_token_finish_refresh(text,text,timestamptz) to authenticated;

-- 4) RPC: fail refresh (clear deadline; keep last_attempt_at to throttle)
create or replace function public.kis_token_fail_refresh(
  p_owner text,
  p_error text default null
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
begin
  perform pg_advisory_lock(73001331);

  update public.kis_token_cache
     set refresh_deadline = null,
         refresh_owner = null,
         updated_at = v_now
   where id = 1;

  perform pg_advisory_unlock(73001331);
end;
$$;

grant execute on function public.kis_token_fail_refresh(text,text) to authenticated;

-- 5) Optional: expand sync run log columns (non-breaking)
alter table public.market_data_sync_runs
  add column if not exists provider text,
  add column if not exists job_type text,
  add column if not exists requested_by text,
  add column if not exists error_code text,
  add column if not exists error_message text,
  add column if not exists items_total int,
  add column if not exists items_success int,
  add column if not exists items_failed int;

comment on column public.market_data_sync_runs.job_type is 'METADATA|PRICE|FX|FULL (optional)';
comment on column public.market_data_sync_runs.requested_by is 'MANUAL|SCHEDULED (optional)';

-- Done

commit;

-- =============================================================================
-- KIS Full Edge Test Runner (patched: US KIS meta seed + K4 date-collision fix)
-- =============================================================================

-- =====================================================================
-- PAD v1.3.1 (patched) + KIS Add-on — Test Runner
-- =====================================================================

create or replace function public.cleanup_test_data(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from public.transactions             where user_id = p_user_id;
  delete from public.account_balances         where user_id = p_user_id;
  delete from public.holdings                 where user_id = p_user_id;
  delete from public.stock_prices             where user_id = p_user_id;
  delete from public.fx_rates                 where user_id = p_user_id;
  delete from public.currency_wallet          where user_id = p_user_id;
  delete from public.liabilities              where user_id = p_user_id;
  delete from public.cards                    where user_id = p_user_id;

  delete from public.categories               where user_id = p_user_id;

  delete from public.portfolio_nav_daily       where user_id = p_user_id;
  delete from public.portfolio_returns_monthly where user_id = p_user_id;
  delete from public.portfolio_metrics         where user_id = p_user_id;

  delete from public.market_data_sync_runs     where user_id = p_user_id;

  delete from public.accounts                 where user_id = p_user_id;
  delete from public.stocks                   where user_id = p_user_id;

  delete from public.stats                    where user_id = p_user_id;
end;
$$;

grant execute on function public.cleanup_test_data(uuid) to authenticated;

create or replace function public.seed_test_data(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_acc_bank uuid;
  v_acc_sec  uuid;
  v_stock_kr uuid;
  v_stock_us uuid;
begin
  if p_user_id is null then
    raise exception 'p_user_id is required';
  end if;

  perform set_config('request.jwt.claim.sub',  p_user_id::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);

  perform public.ensure_stats_row(p_user_id);


  -- Seed default categories (user-scoped)
  insert into public.categories(user_id, category_name, category_kind, is_active, sort_order)
  values
    (p_user_id, '테스트', '공용', true, 0),
    (p_user_id, '쇼핑',  '지출', true, 10),
    (p_user_id, '식비',  '지출', true, 20)
  on conflict (user_id, category_name) do update
  set
    category_kind = excluded.category_kind,
    is_active = true;

  insert into public.accounts(user_id, account_name, account_type, default_currency, is_include_in_networth)
  values
    (p_user_id, '주거래계좌', 'Bank', 'KRW', true),
    (p_user_id, '증권계좌',   'Securities', 'KRW', true)
  on conflict do nothing;

  select account_id into v_acc_bank
  from public.accounts
  where user_id = p_user_id and account_name = '주거래계좌'
  limit 1;

  select account_id into v_acc_sec
  from public.accounts
  where user_id = p_user_id and account_name = '증권계좌'
  limit 1;

  insert into public.liabilities(
    user_id, liability_name, liability_type, principal_original, principal_remaining, currency, is_include_in_networth
  )
  values
    (p_user_id, '주택담보대출', 'Mortgage', 100000000, 50000000, 'KRW', true)
  on conflict do nothing;

  insert into public.stocks(user_id, ticker, name, market, currency, note, kis_prdt_type_cd, kis_excd, kis_tr_mket_cd)
  values
    (p_user_id, '005930', '삼성전자',  'KR', 'KRW', '테스트용', null,  null,   null),
    (p_user_id, 'AAPL',   'Apple Inc.', 'US', 'USD', '테스트용', '512', 'NASD', '01')
  on conflict (user_id, ticker) do nothing;

  -- Ensure required KIS fields on US stock (new inserts are validated even if constraint is NOT VALID)
  update public.stocks
  set
    kis_prdt_type_cd = coalesce(kis_prdt_type_cd, '512'),
    kis_excd         = coalesce(kis_excd, 'NAS'),
    kis_tr_mket_cd   = coalesce(kis_tr_mket_cd, 'NASD')
  where user_id = p_user_id and ticker = 'AAPL';

  select stock_id into v_stock_kr
  from public.stocks
  where user_id = p_user_id and ticker = '005930'
  limit 1;

  select stock_id into v_stock_us
  from public.stocks
  where user_id = p_user_id and ticker = 'AAPL'
  limit 1;

  insert into public.account_balances(user_id, account_id, currency, balance)
  values
    (p_user_id, v_acc_bank, 'KRW', 100000000),
    (p_user_id, v_acc_sec,  'KRW', 0)
  on conflict (user_id, account_id, currency)
  do update set balance = excluded.balance;

  insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, est_value_krw)
  values (p_user_id, 'USD', 0, 0, 0)
  on conflict (user_id, currency) do update
  set total_foreign_held = 0, total_krw_invested = 0, est_value_krw = 0;

  insert into public.holdings(user_id, stock_id, holdings_qty)
  values
    (p_user_id, v_stock_kr, 10),
    (p_user_id, v_stock_us, 2)
  on conflict (user_id, stock_id) do update
  set holdings_qty = excluded.holdings_qty;

  insert into public.stock_prices(user_id, stock_id, price, currency, updated_at_source)
  values
    (p_user_id, v_stock_kr, 70000, 'KRW', now()),
    (p_user_id, v_stock_us, 200,   'USD', now())
  on conflict (user_id, stock_id) do update
  set price = excluded.price, currency = excluded.currency, updated_at_source = excluded.updated_at_source, updated_at = now();

  insert into public.fx_rates(user_id, pair, rate, updated_at_source)
  values
    (p_user_id, 'USDKRW', 1300, now())
  on conflict (user_id, pair) do update
  set rate = excluded.rate, updated_at_source = excluded.updated_at_source, updated_at = now();

  insert into public.fx_pair_map(pair, kis_fid_input_iscd, description)
  values ('USDKRW', 'DUMMY_CODE_SET_ME', '테스트/초기 설정 필요: KIS 환율 마스터 코드')
  on conflict (pair) do nothing;

end;
$$;

grant execute on function public.seed_test_data(uuid) to authenticated;

create or replace function public.run_full_edge_tests_kis(p_user_id uuid)
returns table(test_name text, status text, detail text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_acc_bank uuid;
  v_acc_sec  uuid;
  v_stock_kr uuid;
  v_stock_us uuid;
  v_liab_id  uuid;
  v_usd_acc  uuid;
  v_tx_id    uuid;

  v_expected_stock numeric(18,2);
  v_actual_stock numeric(18,2);
  v_actual_net numeric(18,2);

  v_today date := (now() at time zone 'Asia/Seoul')::date;

  -- K4 variables
  i int;
  m_start date;
  nav_start numeric(18,2);
  nav_end numeric(18,2);
  v_mdd numeric(10,6);
  v_months int;
  v_pos int;
  v_wr numeric(10,6);
begin
  if p_user_id is null then
    return query select 'PRECHECK', 'FAIL', 'p_user_id is required';
    return;
  end if;

  perform public.cleanup_test_data(p_user_id);
  perform public.seed_test_data(p_user_id);

  perform set_config('request.jwt.claim.sub',  p_user_id::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);

  select account_id into v_acc_bank from public.accounts where user_id = p_user_id and account_name = '주거래계좌' limit 1;
  select account_id into v_acc_sec  from public.accounts where user_id = p_user_id and account_name = '증권계좌' limit 1;
  select stock_id   into v_stock_kr from public.stocks   where user_id = p_user_id and ticker = '005930' limit 1;
  select stock_id   into v_stock_us from public.stocks   where user_id = p_user_id and ticker = 'AAPL'   limit 1;
  select liability_id into v_liab_id from public.liabilities where user_id = p_user_id and liability_name = '주택담보대출' limit 1;

  if v_acc_bank is null or v_acc_sec is null or v_stock_kr is null or v_liab_id is null then
    return query select 'PRECHECK', 'FAIL', '필수 데이터 없음 (주거래계좌/증권계좌/005930/주택담보대출)';
    return;
  end if;

  -- T1
  begin
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 0)
    on conflict (user_id, account_id, currency) do update set balance = 0;

    v_tx_id := public.process_transaction_v2(
      now(), '지출', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      null,
      '테스트', 'T1: 잔액음수',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T1 잔액 음수 방지', 'FAIL', sqlerrm;
    else
      return query select 'T1 잔액 음수 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T2
  begin
    insert into public.holdings(user_id, stock_id, holdings_qty)
    values (p_user_id, v_stock_kr, 1)
    on conflict (user_id, stock_id) do update set holdings_qty = 1;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_kr,
      2, null,
      null,
      '테스트', 'T2: 초과매도',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T2 초과 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T2 초과 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T3
  begin
    delete from public.holdings where user_id = p_user_id and stock_id = v_stock_kr;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_kr,
      1, null,
      null,
      '테스트', 'T3: 보유없음매도',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T3 보유없음 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T3 보유없음 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T4
  begin
    insert into public.accounts (user_id, account_name, account_type, default_currency)
    values (p_user_id, 'USD테스트계좌', 'Bank', 'USD')
    returning account_id into v_usd_acc;

    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_usd_acc,
      null, null,
      null, null,
      null,
      '테스트', 'T4: 통화불일치이체',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T4 이체 통화불일치 방지', 'FAIL', sqlerrm;
    else
      return query select 'T4 이체 통화불일치 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T5
  begin
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, est_value_krw)
    values (p_user_id, 'USD', 0, 0, 0)
    on conflict (user_id, currency) do update
    set total_foreign_held = 0, total_krw_invested = 0, est_value_krw = 0;

    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 999999999)
    on conflict (user_id, account_id, currency) do update set balance = 999999999;

    v_tx_id := public.process_transaction_v2(
      now(), '환전_매도', 1300, 'KRW',
      v_acc_bank, null,
      null, null,
      1, 1300,
      null,
      '테스트', 'T5: USD초과매도',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T5 USD 초과매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T5 USD 초과매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T6
  begin
    update public.liabilities
    set principal_remaining = 0
    where user_id = p_user_id and liability_id = v_liab_id;

    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 1000000)
    on conflict (user_id, account_id, currency) do update set balance = 1000000;

    v_tx_id := public.process_transaction_v2(
      now(), '대출_상환_원금', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      v_liab_id,
      '테스트', 'T6: 원금초과상환',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T6 원금 초과상환 방지', 'FAIL', sqlerrm;
    else
      return query select 'T6 원금 초과상환 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T7
  begin
    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_acc_bank,
      null, null,
      null, null,
      null,
      '테스트', 'T7: 동일계좌이체',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T7 동일계좌 이체 방지', 'FAIL', sqlerrm;
    else
      return query select 'T7 동일계좌 이체 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- K1
  begin
    insert into public.stocks(user_id, ticker, name, market, currency)
    values (p_user_id, 'DUMMY', 'Dummy US', 'US', 'USD');
    raise exception 'UNEXPECTED_SUCCESS inserted US stock without KIS fields';
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'K1 US 종목 KIS 메타 필수', 'FAIL', sqlerrm;
    else
      return query select 'K1 US 종목 KIS 메타 필수', 'PASS', sqlerrm;
    end if;
  end;

  -- K2
  begin
    insert into public.holdings(user_id, stock_id, holdings_qty)
    values
      (p_user_id, v_stock_kr, 10),
      (p_user_id, v_stock_us, 2)
    on conflict (user_id, stock_id) do update set holdings_qty = excluded.holdings_qty;

    insert into public.stock_prices(user_id, stock_id, price, currency, updated_at_source)
    values
      (p_user_id, v_stock_kr, 70000, 'KRW', now()),
      (p_user_id, v_stock_us, 200,   'USD', now())
    on conflict (user_id, stock_id) do update
    set price = excluded.price, currency = excluded.currency, updated_at_source = excluded.updated_at_source, updated_at = now();

    insert into public.fx_rates(user_id, pair, rate, updated_at_source)
    values (p_user_id, 'USDKRW', 1300, now())
    on conflict (user_id, pair) do update set rate = excluded.rate, updated_at_source = excluded.updated_at_source, updated_at = now();

    update public.account_balances set balance = 0
    where user_id = p_user_id and currency = 'KRW';
    update public.liabilities set principal_remaining = 0
    where user_id = p_user_id;

    perform public.refresh_stats(p_user_id);

    select stock_value_krw, total_networth_krw
      into v_actual_stock, v_actual_net
    from public.stats where user_id = p_user_id;

    v_expected_stock := 10*70000 + 2*200*1300;

    if v_actual_stock <> v_expected_stock then
      raise exception 'EXPECTED stock_value_krw=% but got % (net=%)', v_expected_stock, v_actual_stock, v_actual_net;
    end if;

    return query select 'K2 refresh_stats 시세/환율 계산', 'PASS', 'stock_value_krw matches expected';
  exception when others then
    return query select 'K2 refresh_stats 시세/환율 계산', 'FAIL', sqlerrm;
  end;

  -- K3
  begin
    perform public.capture_nav_snapshot(p_user_id, v_today, now(), 'TEST');

    if not exists (
      select 1 from public.portfolio_nav_daily
      where user_id = p_user_id and trading_date = v_today
    ) then
      raise exception 'NAV snapshot not inserted';
    end if;

    return query select 'K3 NAV 스냅샷 캡처', 'PASS', 'portfolio_nav_daily inserted/updated';
  exception when others then
    return query select 'K3 NAV 스냅샷 캡처', 'FAIL', sqlerrm;
  end;

  -- K4
  begin
    delete from public.portfolio_nav_daily where user_id = p_user_id;

    -- NOTE: Avoid date collisions with the monthly-seeded points (m_start+1 / m_start+20)
    -- We place the 3-point MDD series far enough in the past (but within lookback window)
    -- so that the monthly loop cannot overwrite these peak/trough points.
    insert into public.portfolio_nav_daily(user_id, trading_date, nav_krw, market_data_asof, source)
    values
      (p_user_id, current_date - 300, 1000, now(), 'TEST'), -- peak
      (p_user_id, current_date - 299, 850,  now(), 'TEST'), -- trough (-15%)
      (p_user_id, current_date - 298, 1200, now(), 'TEST')  -- recovery
    on conflict (user_id, trading_date) do update
    set nav_krw = excluded.nav_krw, market_data_asof = excluded.market_data_asof, source = excluded.source, updated_at = now();

    for i in 0..11 loop
      m_start := (date_trunc('month', current_date)::date - (i || ' months')::interval)::date;
      nav_start := 900 + (i * 5);

      if i < 9 then
        nav_end := nav_start * 1.02;
      else
        nav_end := nav_start * 0.98;
      end if;

      insert into public.portfolio_nav_daily(user_id, trading_date, nav_krw, market_data_asof, source)
      values
        (p_user_id, m_start + 1,  nav_start, now(), 'TEST'),
        (p_user_id, m_start + 20, nav_end,  now(), 'TEST')
      on conflict (user_id, trading_date) do update
      set nav_krw = excluded.nav_krw, market_data_asof = excluded.market_data_asof, source = excluded.source, updated_at = now();
    end loop;

    perform public.update_portfolio_metrics(p_user_id, current_date);

    select mdd_pct, months_count_12m, positive_months_12m, win_rate_12m
      into v_mdd, v_months, v_pos, v_wr
    from public.portfolio_metrics
    where user_id = p_user_id;

    if v_mdd is null or abs(v_mdd - (-0.15)) > 0.000001 then
      raise exception 'MDD expected -0.15 but got %', v_mdd;
    end if;

    if v_months is distinct from 12 then
      raise exception 'months_count_12m expected 12 but got %', v_months;
    end if;

    if v_pos is distinct from 9 then
      raise exception 'positive_months_12m expected 9 but got %', v_pos;
    end if;

    if v_wr is null or abs(v_wr - (9::numeric/12::numeric)) > 0.000001 then
      raise exception 'win_rate_12m expected 0.75 but got %', v_wr;
    end if;

    return query select 'K4 MDD/12M 승률 계산', 'PASS', 'MDD=-15%, win-rate=9/12 verified';
  exception when others then
    return query select 'K4 MDD/12M 승률 계산', 'FAIL', sqlerrm;
  end;

  -- K5 Token Cache / 1-min RateLimit 대응 (DB 레벨 로직 검증)
  begin
    if to_regclass('public.kis_token_cache') is null then
      raise exception 'kis_token_cache missing. Apply Token Cache Add-on migration first.';
    end if;

    -- reset token cache row
    update public.kis_token_cache
       set access_token = null,
           expires_at = null,
           last_issued_at = null,
           last_attempt_at = null,
           refresh_deadline = null,
           refresh_owner = null,
           updated_at = now()
     where id = 1;

    -- 1) first decide -> REFRESH_ALLOWED
    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'REFRESH_ALLOWED' then
      raise exception 'Expected REFRESH_ALLOWED on empty cache';
    end if;

    -- 2) finish refresh and validate cache usage
    perform public.kis_token_finish_refresh('TEST', 'TOK_TEST_1', now() + interval '3600 seconds');

    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'USE_CACHE' then
      raise exception 'Expected USE_CACHE after finish_refresh';
    end if;

    -- 3) near-expiry -> should allow refresh (after min-interval bypass)
    update public.kis_token_cache
       set expires_at = now() + interval '30 seconds',
           last_attempt_at = now() - interval '61 seconds',
           refresh_deadline = null,
           refresh_owner = null,
           updated_at = now()
     where id = 1;

    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'REFRESH_ALLOWED' then
      raise exception 'Expected REFRESH_ALLOWED when token expires within safety window';
    end if;

    -- 4) min-interval -> WAIT
    update public.kis_token_cache
       set access_token = null,
           expires_at = null,
           last_attempt_at = now(),
           refresh_deadline = null,
           refresh_owner = null,
           updated_at = now()
     where id = 1;

    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'WAIT' then
      raise exception 'Expected WAIT within min interval';
    end if;

    return query select 'K5 토큰 캐시/레이트리밋(1분) 로직', 'PASS', 'USE_CACHE/REFRESH_ALLOWED/WAIT scenarios verified';
  exception when others then
    return query select 'K5 토큰 캐시/레이트리밋(1분) 로직', 'FAIL', sqlerrm;
  end;

end;
$$;

grant execute on function public.run_full_edge_tests_kis(uuid) to authenticated;

-- =====================================================================
-- FINAL TEST RUNNER PATCHES (APPLIED LAST)
-- =====================================================================

-- Patch: Fix K4 positive_months_12m deterministic seed (MDD=-15%, win_rate=9/12)
-- Generated: 2026-01-24

create or replace function public.run_full_edge_tests_kis(p_user_id uuid)
returns table(test_name text, status text, detail text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_acc_bank uuid;
  v_acc_sec  uuid;
  v_stock_kr uuid;
  v_stock_us uuid;
  v_liab_id  uuid;
  v_usd_acc  uuid;
  v_tx_id    uuid;

  v_expected_stock numeric(18,2);
  v_actual_stock numeric(18,2);
  v_actual_net numeric(18,2);

  v_today date := (now() at time zone 'Asia/Seoul')::date;

  -- K4 variables
  i int;
  m_start date;
  nav_start numeric(18,2);
  nav_end numeric(18,2);
  nav_starts numeric[];
  nav_ends numeric[];
  v_mdd numeric(10,6);
  v_months int;
  v_pos int;
  v_wr numeric(10,6);
begin
  if p_user_id is null then
    return query select 'PRECHECK', 'FAIL', 'p_user_id is required';
    return;
  end if;

  perform public.cleanup_test_data(p_user_id);
  perform public.seed_test_data(p_user_id);

  perform set_config('request.jwt.claim.sub',  p_user_id::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);

  select account_id into v_acc_bank from public.accounts where user_id = p_user_id and account_name = '주거래계좌' limit 1;
  select account_id into v_acc_sec  from public.accounts where user_id = p_user_id and account_name = '증권계좌' limit 1;
  select stock_id   into v_stock_kr from public.stocks   where user_id = p_user_id and ticker = '005930' limit 1;
  select stock_id   into v_stock_us from public.stocks   where user_id = p_user_id and ticker = 'AAPL'   limit 1;
  select liability_id into v_liab_id from public.liabilities where user_id = p_user_id and liability_name = '주택담보대출' limit 1;

  if v_acc_bank is null or v_acc_sec is null or v_stock_kr is null or v_liab_id is null then
    return query select 'PRECHECK', 'FAIL', '필수 데이터 없음 (주거래계좌/증권계좌/005930/주택담보대출)';
    return;
  end if;

  -- T1
  begin
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 0)
    on conflict (user_id, account_id, currency) do update set balance = 0;

    v_tx_id := public.process_transaction_v2(
      now(), '지출', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      null,
      '테스트', 'T1: 잔액음수',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T1 잔액 음수 방지', 'FAIL', sqlerrm;
    else
      return query select 'T1 잔액 음수 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T2
  begin
    insert into public.holdings(user_id, stock_id, holdings_qty)
    values (p_user_id, v_stock_kr, 1)
    on conflict (user_id, stock_id) do update set holdings_qty = 1;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_kr,
      2, null,
      null,
      '테스트', 'T2: 초과매도',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T2 초과 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T2 초과 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T3
  begin
    delete from public.holdings where user_id = p_user_id and stock_id = v_stock_kr;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_kr,
      1, null,
      null,
      '테스트', 'T3: 보유없음매도',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T3 보유없음 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T3 보유없음 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T4
  begin
    insert into public.accounts (user_id, account_name, account_type, default_currency)
    values (p_user_id, 'USD테스트계좌', 'Bank', 'USD')
    returning account_id into v_usd_acc;

    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_usd_acc,
      null, null,
      null, null,
      null,
      '테스트', 'T4: 통화불일치이체',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T4 이체 통화불일치 방지', 'FAIL', sqlerrm;
    else
      return query select 'T4 이체 통화불일치 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T5
  begin
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, est_value_krw)
    values (p_user_id, 'USD', 0, 0, 0)
    on conflict (user_id, currency) do update
    set total_foreign_held = 0, total_krw_invested = 0, est_value_krw = 0;

    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 999999999)
    on conflict (user_id, account_id, currency) do update set balance = 999999999;

    v_tx_id := public.process_transaction_v2(
      now(), '환전_매도', 1300, 'KRW',
      v_acc_bank, null,
      null, null,
      1, 1300,
      null,
      '테스트', 'T5: USD초과매도',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T5 USD 초과매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T5 USD 초과매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T6
  begin
    update public.liabilities
    set principal_remaining = 0
    where user_id = p_user_id and liability_id = v_liab_id;

    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 1000000)
    on conflict (user_id, account_id, currency) do update set balance = 1000000;

    v_tx_id := public.process_transaction_v2(
      now(), '대출_상환_원금', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      v_liab_id,
      '테스트', 'T6: 원금초과상환',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T6 원금 초과상환 방지', 'FAIL', sqlerrm;
    else
      return query select 'T6 원금 초과상환 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- T7
  begin
    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_acc_bank,
      null, null,
      null, null,
      null,
      '테스트', 'T7: 동일계좌이체',
      false, null
    );
    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T7 동일계좌 이체 방지', 'FAIL', sqlerrm;
    else
      return query select 'T7 동일계좌 이체 방지', 'PASS', sqlerrm;
    end if;
  end;

  -- K1
  begin
    insert into public.stocks(user_id, ticker, name, market, currency)
    values (p_user_id, 'DUMMY', 'Dummy US', 'US', 'USD');
    raise exception 'UNEXPECTED_SUCCESS inserted US stock without KIS fields';
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'K1 US 종목 KIS 메타 필수', 'FAIL', sqlerrm;
    else
      return query select 'K1 US 종목 KIS 메타 필수', 'PASS', sqlerrm;
    end if;
  end;

  -- K2
  begin
    insert into public.holdings(user_id, stock_id, holdings_qty)
    values
      (p_user_id, v_stock_kr, 10),
      (p_user_id, v_stock_us, 2)
    on conflict (user_id, stock_id) do update set holdings_qty = excluded.holdings_qty;

    insert into public.stock_prices(user_id, stock_id, price, currency, updated_at_source)
    values
      (p_user_id, v_stock_kr, 70000, 'KRW', now()),
      (p_user_id, v_stock_us, 200,   'USD', now())
    on conflict (user_id, stock_id) do update
    set price = excluded.price, currency = excluded.currency, updated_at_source = excluded.updated_at_source, updated_at = now();

    insert into public.fx_rates(user_id, pair, rate, updated_at_source)
    values (p_user_id, 'USDKRW', 1300, now())
    on conflict (user_id, pair) do update set rate = excluded.rate, updated_at_source = excluded.updated_at_source, updated_at = now();

    update public.account_balances set balance = 0
    where user_id = p_user_id and currency = 'KRW';
    update public.liabilities set principal_remaining = 0
    where user_id = p_user_id;

    perform public.refresh_stats(p_user_id);

    select stock_value_krw, total_networth_krw
      into v_actual_stock, v_actual_net
    from public.stats where user_id = p_user_id;

    v_expected_stock := 10*70000 + 2*200*1300;

    if v_actual_stock <> v_expected_stock then
      raise exception 'EXPECTED stock_value_krw=% but got % (net=%)', v_expected_stock, v_actual_stock, v_actual_net;
    end if;

    return query select 'K2 refresh_stats 시세/환율 계산', 'PASS', 'stock_value_krw matches expected';
  exception when others then
    return query select 'K2 refresh_stats 시세/환율 계산', 'FAIL', sqlerrm;
  end;

  -- K3
  begin
    perform public.capture_nav_snapshot(p_user_id, v_today, now(), 'TEST');

    if not exists (
      select 1 from public.portfolio_nav_daily
      where user_id = p_user_id and trading_date = v_today
    ) then
      raise exception 'NAV snapshot not inserted';
    end if;

    return query select 'K3 NAV 스냅샷 캡처', 'PASS', 'portfolio_nav_daily inserted/updated';
  exception when others then
    return query select 'K3 NAV 스냅샷 캡처', 'FAIL', sqlerrm;
  end;

  -- K4
  begin
    delete from public.portfolio_nav_daily where user_id = p_user_id;

    -- Seed 12 months (including current month) with deterministic monthly returns:
    --   - 12 months_count_12m
    --   - 9 positive months (return_pct > 0) => win_rate 0.75
    --   - MDD exactly -15% (peak 1000 -> trough 850) with no larger drawdown
    --
    -- Monthly return is computed by rebuild_monthly_returns() as:
    --   return_pct = nav_end / nav_start - 1
    -- where nav_start/nav_end are the first/last nav_krw within each month.

    nav_starts := array[900, 920, 940, 960, 980, 1000, 850, 900, 950, 1000, 1100, 1080];
    nav_ends   := array[920, 910, 960, 980, 1000, 850, 900, 950, 1000, 1100, 1080, 1200];

    for i in 0..11 loop
      -- Oldest month = 11 months ago, newest = current month
      m_start := (date_trunc('month', current_date)::date - interval '11 months')::date + (i || ' months')::interval;

      insert into public.portfolio_nav_daily(user_id, trading_date, nav_krw, market_data_asof, source)
      values
        (p_user_id, (m_start::date + 1),  nav_starts[i+1], now(), 'TEST'),
        (p_user_id, (m_start::date + 20), nav_ends[i+1],   now(), 'TEST')
      on conflict (user_id, trading_date) do update
      set nav_krw = excluded.nav_krw,
          market_data_asof = excluded.market_data_asof,
          source = excluded.source,
          updated_at = now();
    end loop;

    perform public.update_portfolio_metrics(p_user_id, current_date);

    select mdd_pct, months_count_12m, positive_months_12m, win_rate_12m
      into v_mdd, v_months, v_pos, v_wr
    from public.portfolio_metrics
    where user_id = p_user_id;

    if v_mdd is null or abs(v_mdd - (-0.15)) > 0.000001 then
      raise exception 'MDD expected -0.15 but got %', v_mdd;
    end if;

    if v_months is distinct from 12 then
      raise exception 'months_count_12m expected 12 but got %', v_months;
    end if;

    if v_pos is distinct from 9 then
      raise exception 'positive_months_12m expected 9 but got %', v_pos;
    end if;

    if v_wr is null or abs(v_wr - (9::numeric/12::numeric)) > 0.000001 then
      raise exception 'win_rate_12m expected 0.75 but got %', v_wr;
    end if;

    return query select 'K4 MDD/12M 승률 계산', 'PASS', 'MDD=-15%, win-rate=9/12 verified';
  exception when others then
    return query select 'K4 MDD/12M 승률 계산', 'FAIL', sqlerrm;
  end;

  -- K5 Token Cache / 1-min RateLimit 대응 (DB 레벨 로직 검증)
  begin
    if to_regclass('public.kis_token_cache') is null then
      raise exception 'kis_token_cache missing. Apply Token Cache Add-on migration first.';
    end if;

    -- reset token cache row
    update public.kis_token_cache
       set access_token = null,
           expires_at = null,
           last_issued_at = null,
           last_attempt_at = null,
           refresh_deadline = null,
           refresh_owner = null,
           updated_at = now()
     where id = 1;

    -- 1) first decide -> REFRESH_ALLOWED
    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'REFRESH_ALLOWED' then
      raise exception 'Expected REFRESH_ALLOWED on empty cache';
    end if;

    -- 2) finish refresh and validate cache usage
    perform public.kis_token_finish_refresh('TEST', 'TOK_TEST_1', now() + interval '3600 seconds');

    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'USE_CACHE' then
      raise exception 'Expected USE_CACHE after finish_refresh';
    end if;

    -- 3) near-expiry -> should allow refresh (after min-interval bypass)
    update public.kis_token_cache
       set expires_at = now() + interval '30 seconds',
           last_attempt_at = now() - interval '61 seconds',
           refresh_deadline = null,
           refresh_owner = null,
           updated_at = now()
     where id = 1;

    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'REFRESH_ALLOWED' then
      raise exception 'Expected REFRESH_ALLOWED when token expires within safety window';
    end if;

    -- 4) min-interval -> WAIT
    update public.kis_token_cache
       set access_token = null,
           expires_at = null,
           last_attempt_at = now(),
           refresh_deadline = null,
           refresh_owner = null,
           updated_at = now()
     where id = 1;

    if (public.kis_token_decide('TEST', 60, 60, 5)->>'action') is distinct from 'WAIT' then
      raise exception 'Expected WAIT within min interval';
    end if;

    return query select 'K5 토큰 캐시/레이트리밋(1분) 로직', 'PASS', 'USE_CACHE/REFRESH_ALLOWED/WAIT scenarios verified';
  exception when others then
    return query select 'K5 토큰 캐시/레이트리밋(1분) 로직', 'FAIL', sqlerrm;
  end;

end;

$$;

grant execute on function public.run_full_edge_tests_kis(uuid) to authenticated;



-- =========================================================
-- PATCH: v1.3.2_categories_and_merchant (applied)
-- Purpose:
--  - Add user-scoped categories table (dropdown + FK enforcement)
--  - Add transactions.category_id (FK) and transactions.merchant
--  - Enforce: '지출'/'수입' must have a valid category
-- =========================================================

-- Categories table (idempotent)
create table if not exists public.categories (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  category_id uuid not null default gen_random_uuid(),

  category_name text not null,
  category_kind text not null default '공용'
    constraint chk_categories_kind check (category_kind in ('지출','수입','공용')),

  is_active boolean not null default true,
  sort_order int not null default 0,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint pk_categories primary key (user_id, category_id),
  constraint uq_categories_user_name unique (user_id, category_name)
);

create index if not exists idx_categories_user_active_sort
  on public.categories(user_id, is_active, sort_order, category_name);

drop trigger if exists trg_categories_updated_at on public.categories;
create trigger trg_categories_updated_at
before update on public.categories
for each row execute function public.set_updated_at();

-- Transactions columns (idempotent)
alter table public.transactions
  add column if not exists category_id uuid null;

alter table public.transactions
  add column if not exists merchant text null;

-- Constraints (idempotent via catalog check)
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'fk_transactions_category'
      and conrelid = 'public.transactions'::regclass
  ) then
    alter table public.transactions
      add constraint fk_transactions_category
      foreign key (user_id, category_id)
      references public.categories(user_id, category_id)
      on delete restrict;
  end if;

  if not exists (
    select 1 from pg_constraint
    where conname = 'chk_transactions_category_required'
      and conrelid = 'public.transactions'::regclass
  ) then
    alter table public.transactions
      add constraint chk_transactions_category_required
      check (case when type in ('지출','수입') then category_id is not null else true end);
  end if;
end $$;

-- Indexes (idempotent)
create index if not exists idx_transactions_user_category_date
  on public.transactions(user_id, category_id, date desc)
  where category_id is not null;

create index if not exists idx_transactions_user_merchant_date
  on public.transactions(user_id, merchant, date desc)
  where merchant is not null;

-- RLS / Policy / Grants
alter table public.categories enable row level security;

drop policy if exists "categories_owner_all" on public.categories;
create policy "categories_owner_all" on public.categories
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.categories to authenticated;

-- ===========================
-- SECTION 2: IDPOTENCY + APP VERSIONING ADD-ON
-- ===========================

-- =====================================================================
-- Migration: Idempotency (client_tx_id) + App Versioning
-- Target base: PAD_All-SDK v1.3.2 patched (2026-01-24)
-- =====================================================================

begin;

-- ---------------------------------------------------------------------
-- 0) App version table (read-only to authenticated)
-- ---------------------------------------------------------------------
create table if not exists public.app_versions (
  id bigint primary key generated always as identity,
  version text not null unique,
  min_supported_version text not null,
  created_at timestamptz not null default now()
);

alter table public.app_versions enable row level security;

do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname='public' and tablename='app_versions' and policyname='read app_versions'
  ) then
    create policy "read app_versions"
      on public.app_versions
      for select
      to authenticated
      using (true);
  end if;
end $$;

grant select on public.app_versions to authenticated;

insert into public.app_versions (version, min_supported_version)
values
  ('1.3.2', '1.3.0'),
  ('2.0.4', '2.0.4'),
  ('2.1.0', '2.0.4'),
  ('2.1.1', '2.0.4')
on conflict (version) do nothing;

create or replace function public.get_current_app_version()
returns table(version text, min_supported_version text, created_at timestamptz)
language sql
stable
security definer
set search_path = public
as $$
  select v.version, v.min_supported_version, v.created_at
  from public.app_versions v
  order by v.created_at desc
  limit 1;
$$;

grant execute on function public.get_current_app_version() to authenticated;

-- ---------------------------------------------------------------------
-- 1) Idempotency column + unique index
-- ---------------------------------------------------------------------
alter table public.transactions
  add column if not exists client_tx_id uuid;

-- NOTE:
--  - Unique is per-user to avoid accidental collisions across users.
--  - Partial index keeps legacy rows (null) unaffected.
create unique index if not exists ux_transactions_user_client_tx_id
  on public.transactions (user_id, client_tx_id)
  where client_tx_id is not null;

-- ---------------------------------------------------------------------
-- 2) RPC: process_transaction_v2 (FULL BODY) + idempotency
--     - Adds p_client_tx_id uuid default null
--     - Fast-path return if already processed
--     - Insert uses ON CONFLICT to make race-safe
-- ---------------------------------------------------------------------
create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  -- v1.3.2: category FK + merchant
  p_category_id uuid default null,
  p_merchant text default null,
  -- v1.3.2+: idempotency
  p_client_tx_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;
  v_existing_tx_id uuid;

  -- v1.3.2: category FK enforcement
  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_month_start timestamptz := (date_trunc('month', timezone('Asia/Seoul', now())) at time zone 'Asia/Seoul');
  v_month_end timestamptz := ((date_trunc('month', timezone('Asia/Seoul', now())) + interval '1 month') at time zone 'Asia/Seoul');

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;

  v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- --------------------------------------------------------------
  -- Idempotency fast-path
  --  - If the same client_tx_id was already processed for this user,
  --    return the existing transaction_id and DO NOT apply side effects.
  -- --------------------------------------------------------------
  if p_client_tx_id is not null then
    select transaction_id into v_existing_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;

    if v_existing_tx_id is not null then
      return v_existing_tx_id;
    end if;
  end if;


  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;


  -- Resolve & validate category (FK)
  -- NOTE: DB constraint also enforces category_id for 지출/수입. This keeps error messages user-friendly.
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    -- Other types: category is optional; if category_id is provided, validate it.
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- [v1.3.1] Currency guard:
    -- Prevent KRW account -> USD account transfer without explicit FX transaction.
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  if p_type in ('지출','수입','수수료','세금','배당금') then
    if p_account_id is null then
      raise exception 'account_id is required for this transaction type';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id,
    client_tx_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id,
    p_client_tx_id
  )
  on conflict (user_id, client_tx_id) where client_tx_id is not null
  do nothing
  returning transaction_id into v_tx_id;

  -- If this was a duplicate (race), return the existing tx_id without side effects
  if v_tx_id is null and p_client_tx_id is not null then
    select transaction_id into v_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;
    return v_tx_id;
  end if;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates
  if p_type = '주식_매수' then
    v_delta_qty := p_qty;
  elsif p_type = '주식_매도' then
    v_delta_qty := -p_qty;
  end if;

  if v_delta_qty <> 0 then
    insert into public.holdings(user_id, stock_id, holdings_qty, last_updated)
    values (v_user_id, p_stock_id, greatest(v_delta_qty, 0), now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = public.holdings.holdings_qty + v_delta_qty,
      last_updated = now();

    if exists (
      select 1 from public.holdings
      where user_id = v_user_id and stock_id = p_stock_id and holdings_qty < 0
    ) then
      raise exception 'Holdings cannot be negative (stock_id=%)', p_stock_id;
    end if;
  end if;

  -- Liabilities principal update
  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Monthly KPI accumulation (simple)
  if p_date >= v_month_start and p_date < v_month_end then
    if p_type in ('지출','수수료','세금','대출_상환_이자') then
      update public.stats
      set expense_this_month = expense_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type in ('수입','배당금') then
      update public.stats
      set income_this_month = income_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type = '대출_상환_이자' then
      update public.stats
      set interest_cost_this_month = interest_cost_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);

  return v_tx_id;
end;
$$;

grant execute on function public.process_transaction_v2(
  timestamptz,
  transaction_type,
  numeric,
  currency_code,
  uuid,
  uuid,
  uuid,
  uuid,
  numeric,
  numeric,
  uuid,
  text,
  text,
  boolean,
  uuid,
  uuid,
  text,
  uuid
) to authenticated;

-- ---------------------------------------------------------------------
-- 3) Edge tests: add T8 (idempotency)
--     - OPTIONAL: keep in dev/test only
-- ---------------------------------------------------------------------
create or replace function public.run_edge_tests(p_user_id uuid)
returns table(test_name text, status text, detail text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_acc_bank uuid;
  v_acc_sec  uuid;
  v_stock_id uuid;
  v_liab_id  uuid;
  v_usd_acc  uuid;
  v_tx_id    uuid;
begin
  -- SQL Editor에서도 auth.uid() 인식시키기 (테스트용)
  perform set_config('request.jwt.claim.sub',  p_user_id::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);

  -- 테스트 대상 엔티티 찾기 (기본 테스트 데이터 기준)
  select account_id into v_acc_bank
  from public.accounts
  where user_id = p_user_id and account_name = '주거래계좌'
  limit 1;

  select account_id into v_acc_sec
  from public.accounts
  where user_id = p_user_id and account_name = '증권계좌'
  limit 1;

  select stock_id into v_stock_id
  from public.stocks
  where user_id = p_user_id and ticker = '005930'
  limit 1;

  select liability_id into v_liab_id
  from public.liabilities
  where user_id = p_user_id and liability_name = '주택담보대출'
  limit 1;

  if v_acc_bank is null or v_acc_sec is null or v_stock_id is null or v_liab_id is null then
    return query
    select
      'PRECHECK'::text,
      'FAIL'::text,
      '필수 데이터 없음 (주거래계좌/증권계좌/005930/주택담보대출 확인)'::text;
    return;
  end if;


  -- Ensure required category exists for tests (category FK enforcement)
  insert into public.categories(user_id, category_name, category_kind, is_active, sort_order)
  values (p_user_id, '테스트', '공용', true, 0)
  on conflict (user_id, category_name) do update
  set is_active = true;

  ------------------------------------------------------------------
  -- T1) 계좌 잔액 음수 방지: 잔액 0에서 1원 지출은 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 0)
    on conflict (user_id, account_id, currency) do update set balance = 0;

    v_tx_id := public.process_transaction_v2(
      now(), '지출', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      null,
      '테스트', 'T1: 잔액음수',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id; -- 성공하면 일부러 예외로 롤백
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T1 잔액 음수 방지', 'FAIL', sqlerrm;
    else
      return query select 'T1 잔액 음수 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T2) 주식 초과 매도 방지: 보유 1에서 2 매도는 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.holdings(user_id, stock_id, holdings_qty)
    values (p_user_id, v_stock_id, 1)
    on conflict (user_id, stock_id) do update set holdings_qty = 1;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_id,
      2, null,
      null,
      '테스트', 'T2: 초과매도',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T2 초과 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T2 초과 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T3) 보유 row가 없는데 매도 방지: 보유 삭제 후 매도는 "막혀야"
  ------------------------------------------------------------------
  begin
    delete from public.holdings
    where user_id = p_user_id and stock_id = v_stock_id;

    v_tx_id := public.process_transaction_v2(
      now(), '주식_매도', 1000, 'KRW',
      v_acc_sec, null,
      null, v_stock_id,
      1, null,
      null,
      '테스트', 'T3: 보유없는데 매도',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T3 보유없음 매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T3 보유없음 매도 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T4) 이체 통화 불일치 방지: KRW -> USD 계좌로 KRW 이체는 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.accounts (user_id, account_name, account_type, default_currency)
    values (p_user_id, 'USD테스트계좌', 'Bank', 'USD')
    returning account_id into v_usd_acc;

    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_usd_acc,
      null, null,
      null, null,
      null,
      '테스트', 'T4: 통화불일치이체',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T4 이체 통화불일치 방지', 'FAIL', sqlerrm;
    else
      return query select 'T4 이체 통화불일치 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T5) USD 지갑 음수 방지: USD=0인데 1 매도는 "막혀야"
  ------------------------------------------------------------------
  begin
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested)
    values (p_user_id, 'USD', 0, 0)
    on conflict (user_id, currency) do update
    set total_foreign_held = 0, total_krw_invested = 0;

    -- bank 잔액쪽으로 실패하지 않게 잔액 충분히
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 999999999)
    on conflict (user_id, account_id, currency) do update set balance = 999999999;

    v_tx_id := public.process_transaction_v2(
      now(), '환전_매도', 1300, 'KRW',
      v_acc_bank, null,
      null, null,
      1, 1300,
      null,
      '테스트', 'T5: USD초과매도',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T5 USD 초과매도 방지', 'FAIL', sqlerrm;
    else
      return query select 'T5 USD 초과매도 방지', 'PASS', sqlerrm;
    end if;
  end;


  ------------------------------------------------------------------
  -- T6) 카테고리 유효성 강제: 존재하지 않는 카테고리로 지출 입력은 "막혀야"
  ------------------------------------------------------------------
  begin
    -- bank 잔액쪽으로 실패하지 않게 잔액 충분히
    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 999999999)
    on conflict (user_id, account_id, currency) do update set balance = 999999999;

    v_tx_id := public.process_transaction_v2(
      now(), '지출', 1000, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      null,
      '없는카테고리', 'T6: 카테고리없음',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T6 카테고리 유효성(없음) 방지', 'FAIL', sqlerrm;
    else
      return query select 'T6 카테고리 유효성(없음) 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T6) 대출 원금 초과 상환 방지: principal=0인데 1 상환은 "막혀야"
  ------------------------------------------------------------------
  begin
    update public.liabilities
    set principal_remaining = 0
    where user_id = p_user_id and liability_id = v_liab_id;

    insert into public.account_balances(user_id, account_id, currency, balance)
    values (p_user_id, v_acc_bank, 'KRW', 1000000)
    on conflict (user_id, account_id, currency) do update set balance = 1000000;

    v_tx_id := public.process_transaction_v2(
      now(), '대출_상환_원금', 1, 'KRW',
      v_acc_bank, null,
      null, null,
      null, null,
      v_liab_id,
      '테스트', 'T6: 원금초과상환',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T6 원금 초과상환 방지', 'FAIL', sqlerrm;
    else
      return query select 'T6 원금 초과상환 방지', 'PASS', sqlerrm;
    end if;
  end;

  ------------------------------------------------------------------
  -- T7) 동일 계좌 이체 방지: from=to는 "막혀야"
  ------------------------------------------------------------------
  begin
    v_tx_id := public.process_transaction_v2(
      now(), '이체', 1000, 'KRW',
      v_acc_bank, v_acc_bank,
      null, null,
      null, null,
      null,
      '테스트', 'T7: 동일계좌이체',
      false, null
    );

    raise exception 'UNEXPECTED_SUCCESS tx=%', v_tx_id;
  exception when others then
    if sqlerrm like 'UNEXPECTED_SUCCESS%' then
      return query select 'T7 동일계좌 이체 방지', 'FAIL', sqlerrm;
    else
      return query select 'T7 동일계좌 이체 방지', 'PASS', sqlerrm;
    end if;
  end;


------------------------------------------------------------------
-- T8) 거래 멱등성(client_tx_id): 같은 요청ID로 재호출 시
--     - 동일 transaction_id 반환
--     - 거래 1건만 존재
--     - 잔액 변화는 1회만 적용
------------------------------------------------------------------
declare
  v_client_id uuid := gen_random_uuid();
  v_before numeric := 0;
  v_after1 numeric := 0;
  v_after2 numeric := 0;
  v_tx1 uuid;
  v_tx2 uuid;
  v_cnt bigint := 0;
  v_amt numeric := 1234;
begin
  select coalesce(balance,0) into v_before
  from public.account_balances
  where account_id = v_acc_bank;

  v_tx1 := public.process_transaction_v2(
    now(), '지출', v_amt, 'KRW',
    v_acc_bank, null,
    null, null,
    null, null,
    null,
    '테스트', 'T8: idempotency',
    false, null,
    p_client_tx_id => v_client_id
  );

  select coalesce(balance,0) into v_after1
  from public.account_balances
  where account_id = v_acc_bank;

  v_tx2 := public.process_transaction_v2(
    now(), '지출', v_amt, 'KRW',
    v_acc_bank, null,
    null, null,
    null, null,
    null,
    '테스트', 'T8: idempotency (retry)',
    false, null,
    p_client_tx_id => v_client_id
  );

  select coalesce(balance,0) into v_after2
  from public.account_balances
  where account_id = v_acc_bank;

  select count(*) into v_cnt
  from public.transactions
  where user_id = p_user_id and client_tx_id = v_client_id;

  if v_tx1 = v_tx2
     and v_cnt = 1
     and v_after1 = (v_before - v_amt)
     and v_after2 = v_after1 then
    return query select 'T8 거래 멱등성(client_tx_id)', 'PASS',
      format('tx=%s cnt=%s before=%s after=%s', v_tx1, v_cnt, v_before, v_after2);
  else
    return query select 'T8 거래 멱등성(client_tx_id)', 'FAIL',
      format('tx1=%s tx2=%s cnt=%s before=%s after1=%s after2=%s', v_tx1, v_tx2, v_cnt, v_before, v_after1, v_after2);
  end if;
exception when others then
  return query select 'T8 거래 멱등성(client_tx_id)', 'FAIL', sqlerrm;
end;


end $$;

--


-- =========================================================
-- Read Model View: v_transactions_with_info
-- =========================================================
-- =====================================================================
-- PATCH: v1.3.6 (2026-01-25)  Daily NAV Snapshots (Account/Stock) + Dashboard RPC
-- =====================================================================
-- Notes:
--  - This section is idempotent (CREATE IF NOT EXISTS / CREATE OR REPLACE).
--  - Intended capture flow:
--      (prices/rates upsert) -> refresh_stats(user) -> capture_nav_snapshot(user, trading_date, asof) -> capture_account_snapshots(user, trading_date, asof)
--  - trading_date is KST-based (Asia/Seoul) date.
-- =====================================================================

-- =========================================================
-- 1) Dashboard RPC (from DashBoard RPC.md)
-- =========================================================
-- PATCH: add get_dashboard RPC
create or replace function public.get_dashboard(
  p_limit int default 10,
  p_include_nav boolean default true
)
returns jsonb
language plpgsql
stable
security invoker
as $$
declare
  v_uid uuid := (select auth.uid());
  v_stats jsonb;
  v_recent jsonb;
  v_sync jsonb;
  v_kis jsonb;
  v_nav jsonb;
begin
  if v_uid is null then
    raise exception 'Unauthenticated: auth.uid() is null';
  end if;

  select to_jsonb(s)
  into v_stats
  from public.stats s
  where s.user_id = v_uid;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.date desc, t.created_at desc), '[]'::jsonb)
  into v_recent
  from (
    select
      transaction_id, user_id, date, type, amount, currency,
      account_id, account_name, to_account_id, to_account_name,
      category_id, category, category_kind,
      merchant, memo,
      card_id, card_name,
      stock_id, stock_ticker, stock_name, stock_market,
      qty, fx_rate,
      liability_id, liability_name,
      is_correction, linked_transaction_id,
      created_at, updated_at
    from public.v_transactions_with_info
    where user_id = v_uid
    order by date desc, created_at desc
    limit greatest(p_limit, 1)
  ) t;

  select to_jsonb(x)
  into v_sync
  from (
    select status, mode, market, started_at, finished_at, market_data_asof, detail
    from public.market_data_sync_runs
    where user_id = v_uid
    order by started_at desc
    limit 1
  ) x;

  select to_jsonb(k)
  into v_kis
  from (
    select id, expires_at, last_issued_at, last_attempt_at, refresh_deadline, refresh_owner, updated_at
    from public.kis_token_cache
    where id = 1
    limit 1
  ) k;

  if p_include_nav then
    select to_jsonb(n)
    into v_nav
    from (
      with last2 as (
        select trading_date, nav_krw
        from public.portfolio_nav_daily
        where user_id = v_uid
        order by trading_date desc
        limit 2
      )
      select
        (select trading_date from last2 order by trading_date desc limit 1) as latest_date,
        (select nav_krw from last2 order by trading_date desc limit 1)      as latest_nav_krw,
        (select nav_krw from last2 order by trading_date desc offset 1 limit 1) as prev_nav_krw,
        ((select nav_krw from last2 order by trading_date desc limit 1)
         - (select nav_krw from last2 order by trading_date desc offset 1 limit 1)) as delta_nav_krw
    ) n;
  else
    v_nav := null;
  end if;

  return jsonb_build_object(
    'user_id', v_uid,
    'stats', v_stats,
    'recent', v_recent,
    'sync', v_sync,
    'kis', v_kis,
    'nav', v_nav,
    'generated_at', now()
  );
end $$;

grant execute on function public.get_dashboard(int, boolean) to authenticated;

-- =========================================================
-- 2) Snapshot Tables
--    2.1) Account x Stock daily valuation
-- =========================================================
create table if not exists public.account_stock_nav_daily (
  nav_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  trading_date date not null,

  account_id uuid not null references public.accounts(account_id) on delete cascade,
  stock_id uuid not null references public.stocks(stock_id) on delete cascade,

  qty numeric(18,6) not null,
  price numeric(18,6) not null,
  price_currency currency_code not null,

  fx_rate_used numeric(18,6) null,     -- USD인 경우 USDKRW
  value_krw numeric(18,2) not null,    -- 최종 KRW 평가금액

  market_data_asof timestamptz not null,
  source text null default 'KIS',

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_account_stock_nav_daily unique (user_id, trading_date, account_id, stock_id),
  constraint chk_account_stock_nav_value_non_negative check (value_krw >= 0)
);

create index if not exists idx_account_stock_nav_daily_user_date
  on public.account_stock_nav_daily(user_id, trading_date desc);

create index if not exists idx_account_stock_nav_daily_user_date_account
  on public.account_stock_nav_daily(user_id, trading_date desc, account_id);

alter table public.account_stock_nav_daily enable row level security;

drop policy if exists "account_stock_nav_daily_owner_all" on public.account_stock_nav_daily;
create policy "account_stock_nav_daily_owner_all" on public.account_stock_nav_daily
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.account_stock_nav_daily to authenticated;

drop trigger if exists trg_account_stock_nav_daily_updated_at on public.account_stock_nav_daily;
create trigger trg_account_stock_nav_daily_updated_at
before update on public.account_stock_nav_daily
for each row execute function public.set_updated_at();

-- =========================================================
-- 2.2) Account daily valuation (cash + fx + stocks) in KRW
-- =========================================================
create table if not exists public.account_nav_daily (
  nav_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  trading_date date not null,

  account_id uuid not null references public.accounts(account_id) on delete cascade,

  cash_krw numeric(18,2) not null default 0,
  usd_qty numeric(18,6) not null default 0,
  usd_value_krw numeric(18,2) not null default 0,
  stock_value_krw numeric(18,2) not null default 0,
  total_krw numeric(18,2) not null default 0,

  market_data_asof timestamptz not null,
  source text null default 'KIS',

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_account_nav_daily unique (user_id, trading_date, account_id),
  constraint chk_account_nav_total_non_negative check (total_krw >= 0)
);

create index if not exists idx_account_nav_daily_user_date
  on public.account_nav_daily(user_id, trading_date desc);

create index if not exists idx_account_nav_daily_user_date_account
  on public.account_nav_daily(user_id, trading_date desc, account_id);

alter table public.account_nav_daily enable row level security;

drop policy if exists "account_nav_daily_owner_all" on public.account_nav_daily;
create policy "account_nav_daily_owner_all" on public.account_nav_daily
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.account_nav_daily to authenticated;

drop trigger if exists trg_account_nav_daily_updated_at on public.account_nav_daily;
create trigger trg_account_nav_daily_updated_at
before update on public.account_nav_daily
for each row execute function public.set_updated_at();

-- =========================================================
-- 3) Capture RPC: write daily snapshots
--    - 제한: p_trading_date는 (KST 기준) 오늘 또는 어제만 허용
-- =========================================================
create or replace function public.capture_account_snapshots(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'KIS'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_usdkrw numeric(18,6);
  v_today_kst date := timezone('Asia/Seoul', now())::date;
  v_missing text;
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  -- Guardrail: prevent accidental historical backfill in normal mode
  if p_source <> 'REBUILD' then
    if p_trading_date not in (v_today_kst, (v_today_kst - 1)) then
      raise exception 'p_trading_date must be today or yesterday (KST). got=%', p_trading_date;
    end if;
  end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  -- USDKRW rate (prefer daily for trading_date)
  if p_source = 'REBUILD' then
    select rate into v_usdkrw
    from public.fx_rates_daily
    where user_id = p_user_id and trading_date = p_trading_date and pair = 'USDKRW'
    limit 1;

    if v_usdkrw is null then
      raise exception 'Missing fx_rates_daily (USDKRW) for % (user_id=%). Backfill daily FX rates before rebuild.', p_trading_date, p_user_id;
    end if;
  else
    select coalesce(
      (select rate from public.fx_rates_daily where user_id=p_user_id and trading_date=p_trading_date and pair='USDKRW' limit 1),
      (select rate from public.fx_rates where user_id=p_user_id and pair='USDKRW' limit 1),
      0
    ) into v_usdkrw;
  end if;

  -- ---------------------------------------------------------
  -- A) Account x Stock valuation
  --    Holdings computed from transactions (account-scoped)
  --    Only include tx where (KST date) <= p_trading_date
  -- ---------------------------------------------------------

  -- Strict mode: require daily stock prices for ALL positions on p_trading_date
  if p_source = 'REBUILD' then
    with pos as (
      select
        t.account_id,
        t.stock_id,
        sum(case
          when t.type = '주식_매수' then t.qty
          when t.type = '주식_매도' then -t.qty
          else 0
        end) as qty
      from public.transactions t
      where t.user_id = p_user_id
        and t.is_correction = false
      and t.is_voided = false
        and t.account_id is not null
        and t.stock_id is not null
        and t.qty is not null
        and t.type in ('주식_매수','주식_매도')
        and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
      group by t.account_id, t.stock_id
      having sum(case
          when t.type = '주식_매수' then t.qty
          when t.type = '주식_매도' then -t.qty
          else 0
        end) <> 0
    ),
    missing as (
      select distinct pos.stock_id
      from pos
      left join public.stock_prices_daily spd
        on spd.user_id = p_user_id and spd.trading_date = p_trading_date and spd.stock_id = pos.stock_id
      where spd.stock_id is null
    )
    select string_agg(stock_id::text, ',') into v_missing from missing;

    if v_missing is not null then
      raise exception 'Missing stock_prices_daily for % (stock_ids=%). Backfill daily prices before rebuild.', p_trading_date, v_missing;
    end if;
  end if;

  with pos as (
    select
      t.account_id,
      t.stock_id,
      sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
      end) as qty
    from public.transactions t
    where t.user_id = p_user_id
      and t.is_correction = false
      and t.is_voided = false
      and t.account_id is not null
      and t.stock_id is not null
      and t.qty is not null
      and t.type in ('주식_매수','주식_매도')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.account_id, t.stock_id
    having sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
      end) <> 0
  ),
  priced as (
    select
      p_user_id as user_id,
      p_trading_date as trading_date,
      pos.account_id,
      pos.stock_id,
      pos.qty,
      coalesce(spd.price, sp.price) as price,
      coalesce(spd.currency, sp.currency) as price_currency,
      case when coalesce(spd.currency, sp.currency)='USD' then v_usdkrw else null end as fx_rate_used,
      round(
        case
          when sp.currency='KRW' then (pos.qty * sp.price)
          when sp.currency='USD' then (pos.qty * sp.price * v_usdkrw)
          else 0
        end
      , 2) as value_krw
    from pos
    left join public.stock_prices_daily spd
      on spd.user_id = p_user_id and spd.trading_date = p_trading_date and spd.stock_id = pos.stock_id
    join public.stock_prices sp
      on sp.user_id = p_user_id and sp.stock_id = pos.stock_id
  )
  insert into public.account_stock_nav_daily(
    user_id, trading_date, account_id, stock_id,
    qty, price, price_currency, fx_rate_used, value_krw,
    market_data_asof, source
  )
  select
    user_id, trading_date, account_id, stock_id,
    qty, price, price_currency, fx_rate_used, value_krw,
    p_market_data_asof, p_source
  from priced
  on conflict (user_id, trading_date, account_id, stock_id)
  do update set
    qty = excluded.qty,
    price = excluded.price,
    price_currency = excluded.price_currency,
    fx_rate_used = excluded.fx_rate_used,
    value_krw = excluded.value_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();

  -- ---------------------------------------------------------
  -- B) Account valuation (cash + fx + stocks)
  --    cash: account_balances (current)
  --    usd_qty: from transactions (account-scoped), KST date <= p_trading_date
  -- ---------------------------------------------------------
  with usd_pos as (
    select
      t.account_id,
      sum(case
        when t.type='환전_매수' then t.qty
        when t.type='환전_매도' then -t.qty
        else 0
      end) as usd_qty
    from public.transactions t
    where t.user_id = p_user_id
      and t.is_correction = false
      and t.is_voided = false
      and t.account_id is not null
      and t.qty is not null
      and t.type in ('환전_매수','환전_매도')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.account_id
  ),
  cash as (
    select
      ab.account_id,
      sum(case
        when ab.currency='KRW' then ab.balance
        when ab.currency='USD' then ab.balance * v_usdkrw
        else 0
      end) as cash_krw
    from public.account_balances ab
    where ab.user_id = p_user_id
    group by ab.account_id
  ),
  stock_sum as (
    select
      account_id,
      coalesce(sum(value_krw),0) as stock_value_krw
    from public.account_stock_nav_daily
    where user_id = p_user_id
      and trading_date = p_trading_date
    group by account_id
  ),
  merged as (
    select
      a.account_id,
      coalesce(c.cash_krw,0) as cash_krw,
      coalesce(u.usd_qty,0) as usd_qty,
      round(coalesce(u.usd_qty,0) * v_usdkrw, 2) as usd_value_krw,
      coalesce(s.stock_value_krw,0) as stock_value_krw
    from public.accounts a
    left join cash c on c.account_id = a.account_id
    left join usd_pos u on u.account_id = a.account_id
    left join stock_sum s on s.account_id = a.account_id
    where a.user_id = p_user_id
      and a.is_include_in_networth = true
  )
  insert into public.account_nav_daily(
    user_id, trading_date, account_id,
    cash_krw, usd_qty, usd_value_krw, stock_value_krw, total_krw,
    market_data_asof, source
  )
  select
    p_user_id, p_trading_date, account_id,
    cash_krw, usd_qty, usd_value_krw, stock_value_krw,
    round(cash_krw + usd_value_krw + stock_value_krw, 2) as total_krw,
    p_market_data_asof, p_source
  from merged
  on conflict (user_id, trading_date, account_id)
  do update set
    cash_krw = excluded.cash_krw,
    usd_qty = excluded.usd_qty,
    usd_value_krw = excluded.usd_value_krw,
    stock_value_krw = excluded.stock_value_krw,
    total_krw = excluded.total_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();
end;
$$;

grant execute on function public.capture_account_snapshots(uuid, date, timestamptz, text) to authenticated;

-- =========================================================
-- 4) Read-model Views (3 views)
--    - If today's snapshot row does not exist, fall back to "live" calculation based on current state.
-- =========================================================

-- 4.1) Stock daily valuation (by account)
create or replace view public.v_account_stock_nav_daily as
with u as (
  select
    auth.uid() as user_id,
    timezone('Asia/Seoul', now())::date as today
),
snap as (
  select
    d.user_id,
    d.trading_date,
    d.account_id,
    a.account_name,
    d.stock_id,
    s.ticker,
    s.name as stock_name,
    s.market,
    d.qty,
    d.price,
    d.price_currency,
    d.fx_rate_used,
    d.value_krw,
    d.market_data_asof,
    d.source,
    true as is_snapshot
  from public.account_stock_nav_daily d
  join public.accounts a on a.account_id = d.account_id
  join public.stocks s on s.stock_id = d.stock_id
  where d.user_id = (select user_id from u)
),
live as (
  select
    (select user_id from u) as user_id,
    (select today from u) as trading_date,
    pos.account_id,
    a.account_name,
    pos.stock_id,
    s.ticker,
    s.name as stock_name,
    s.market,
    pos.qty,
    sp.price,
    sp.currency as price_currency,
    case when sp.currency='USD' then fr.rate else null end as fx_rate_used,
    round(
      case
        when sp.currency='KRW' then (pos.qty * sp.price)
        when sp.currency='USD' then (pos.qty * sp.price * coalesce(fr.rate,0))
        else 0
      end
    , 2) as value_krw,
    coalesce(sp.updated_at_source, now()) as market_data_asof,
    'LIVE'::text as source,
    false as is_snapshot
  from (
    select
      t.account_id,
      t.stock_id,
      sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
      end) as qty
    from public.transactions t
    where t.user_id = (select user_id from u)
      and t.is_correction = false
      and t.account_id is not null
      and t.stock_id is not null
      and t.qty is not null
      and t.type in ('주식_매수','주식_매도')
    group by t.account_id, t.stock_id
    having sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
      end) <> 0
  ) pos
  join public.accounts a on a.account_id = pos.account_id and a.user_id = (select user_id from u)
  join public.stocks s on s.stock_id = pos.stock_id and s.user_id = (select user_id from u)
  join public.stock_prices sp on sp.stock_id = pos.stock_id and sp.user_id = (select user_id from u)
  left join public.fx_rates fr on fr.user_id = (select user_id from u) and fr.pair = 'USDKRW'
  where not exists (
    select 1 from public.account_stock_nav_daily x
    where x.user_id = (select user_id from u)
      and x.trading_date = (select today from u)
    limit 1
  )
)
select * from snap
union all
select * from live;

grant select on public.v_account_stock_nav_daily to authenticated;

-- 4.2) Account daily valuation (by account)
create or replace view public.v_account_nav_daily as
with u as (
  select
    auth.uid() as user_id,
    timezone('Asia/Seoul', now())::date as today
),
snap as (
  select
    d.user_id,
    d.trading_date,
    d.account_id,
    a.account_name,
    d.cash_krw,
    d.usd_qty,
    d.usd_value_krw,
    d.stock_value_krw,
    d.total_krw,
    d.market_data_asof,
    d.source,
    true as is_snapshot
  from public.account_nav_daily d
  join public.accounts a on a.account_id = d.account_id
  where d.user_id = (select user_id from u)
),
live as (
  with fx as (
    select coalesce(fr.rate,0) as usdkrw
    from public.fx_rates fr
    where fr.user_id = (select user_id from u) and fr.pair='USDKRW'
    limit 1
  ),
  usd_pos as (
    select
      t.account_id,
      sum(case
        when t.type='환전_매수' then t.qty
        when t.type='환전_매도' then -t.qty
        else 0
      end) as usd_qty
    from public.transactions t
    where t.user_id = (select user_id from u)
      and t.is_correction = false
      and t.account_id is not null
      and t.qty is not null
      and t.type in ('환전_매수','환전_매도')
    group by t.account_id
  ),
  cash as (
    select
      ab.account_id,
      sum(case
        when ab.currency='KRW' then ab.balance
        when ab.currency='USD' then ab.balance * (select usdkrw from fx)
        else 0
      end) as cash_krw
    from public.account_balances ab
    where ab.user_id = (select user_id from u)
    group by ab.account_id
  ),
  stock_sum as (
    select
      v.account_id,
      coalesce(sum(v.value_krw),0) as stock_value_krw
    from public.v_account_stock_nav_daily v
    where v.user_id = (select user_id from u)
      and v.trading_date = (select today from u)
    group by v.account_id
  )
  select
    (select user_id from u) as user_id,
    (select today from u) as trading_date,
    a.account_id,
    a.account_name,
    coalesce(c.cash_krw,0) as cash_krw,
    coalesce(u2.usd_qty,0) as usd_qty,
    round(coalesce(u2.usd_qty,0) * (select usdkrw from fx), 2) as usd_value_krw,
    coalesce(s.stock_value_krw,0) as stock_value_krw,
    round(coalesce(c.cash_krw,0)
        + round(coalesce(u2.usd_qty,0) * (select usdkrw from fx), 2)
        + coalesce(s.stock_value_krw,0)
    , 2) as total_krw,
    now() as market_data_asof,
    'LIVE'::text as source,
    false as is_snapshot
  from public.accounts a
  left join cash c on c.account_id = a.account_id
  left join usd_pos u2 on u2.account_id = a.account_id
  left join stock_sum s on s.account_id = a.account_id
  where a.user_id = (select user_id from u)
    and a.is_include_in_networth = true
    and not exists (
      select 1 from public.account_nav_daily x
      where x.user_id = (select user_id from u)
        and x.trading_date = (select today from u)
      limit 1
    )
)
select * from snap
union all
select * from live;

grant select on public.v_account_nav_daily to authenticated;

-- 4.3) Total portfolio NAV daily series (KRW)
--      - base: portfolio_nav_daily
--      - fallback: stats.total_networth_krw (LIVE) when today's snapshot missing
create or replace view public.v_portfolio_nav_daily as
with u as (
  select
    auth.uid() as user_id,
    timezone('Asia/Seoul', now())::date as today
),
snap as (
  select
    d.user_id,
    d.trading_date,
    d.nav_krw,
    d.market_data_asof,
    d.source,
    true as is_snapshot
  from public.portfolio_nav_daily d
  where d.user_id = (select user_id from u)
),
live as (
  select
    s.user_id,
    (select today from u) as trading_date,
    s.total_networth_krw as nav_krw,
    s.updated_at as market_data_asof,
    'LIVE'::text as source,
    false as is_snapshot
  from public.stats s
  where s.user_id = (select user_id from u)
    and not exists (
      select 1 from public.portfolio_nav_daily x
      where x.user_id = (select user_id from u)
        and x.trading_date = (select today from u)
      limit 1
    )
),
all_rows as (
  select * from snap
  union all
  select * from live
)
select
  user_id,
  trading_date,
  nav_krw,
  nav_krw - lag(nav_krw) over (order by trading_date) as delta_nav_krw,
  case
    when lag(nav_krw) over (order by trading_date) is null then null
    when lag(nav_krw) over (order by trading_date) = 0 then null
    else round((nav_krw / lag(nav_krw) over (order by trading_date) - 1) * 100, 4)
  end as delta_nav_pct,
  market_data_asof,
  source,
  is_snapshot
from all_rows;

grant select on public.v_portfolio_nav_daily to authenticated;

-- =====================================================================
-- END PATCH v1.3.6
-- =====================================================================


commit;

-- =====================================================================
-- PAD All-SDK FULL (v1.3.7) PATCH: Fixed Expenses (Plan) + Credit Card Cycle (Start Day)
-- Generated: 2026-01-26 00:00:00 +0900 (Asia/Seoul)
--
-- Goals (User decision / cash-basis networth):
--  - Bank transfer/expense immediately affects account balance & networth
--  - Card spend does NOT create liability nor reduce networth (cash-basis networth)
--  - Card payment reduces bank balance & networth
--  - Card pages provide cycle spend (start_day -> end_day auto)
--  - Fixed expenses are stored separately as plan/reference only (no impact on ledger/balances)
-- =====================================================================

-- =========================================================
-- 1) Fixed Expenses (Plan/Reference only, KRW only)
-- =========================================================
create table if not exists public.fixed_expenses (
  fixed_expense_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),

  title text not null,                 -- 예: '월세'
  amount numeric(18,2) not null,       -- 예: 700000
  day_of_month smallint not null,      -- 1~31
  note text null,                      -- 간략 설명(비고)

  category_id uuid null,
  constraint fk_fixed_expenses_category
    foreign key (user_id, category_id)
    references public.categories(user_id, category_id)
    on delete set null,

  is_active boolean not null default true,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint chk_fixed_expenses_amount_nonneg check (amount >= 0),
  constraint chk_fixed_expenses_day_range check (day_of_month between 1 and 31)
);

create index if not exists idx_fixed_expenses_user_active_day
  on public.fixed_expenses(user_id, is_active, day_of_month, title);

drop trigger if exists trg_fixed_expenses_updated_at on public.fixed_expenses;
create trigger trg_fixed_expenses_updated_at
before update on public.fixed_expenses
for each row execute function public.set_updated_at();

alter table public.fixed_expenses enable row level security;

drop policy if exists "fixed_expenses_owner_all" on public.fixed_expenses;
create policy "fixed_expenses_owner_all" on public.fixed_expenses
for all
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.fixed_expenses to authenticated;

create or replace view public.v_fixed_expenses_monthly as
select
  user_id,
  sum(amount) as total_monthly_krw,
  count(*) as item_count,
  max(updated_at) as updated_at_max
from public.fixed_expenses
where is_active = true
group by user_id;

grant select on public.v_fixed_expenses_monthly to authenticated;

create or replace view public.v_fixed_expenses_active_list as
select
  user_id, fixed_expense_id,
  title, amount, day_of_month, note,
  category_id,
  updated_at
from public.fixed_expenses
where is_active = true;

grant select on public.v_fixed_expenses_active_list to authenticated;


-- =========================================================
-- 2) Credit Cards: statement_start_day(청구기간 시작일) + card payment type
-- =========================================================

-- 2.1 cards: statement_start_day 추가
alter table public.cards
  add column if not exists statement_start_day int not null default 1;

alter table public.cards
  drop constraint if exists chk_cards_statement_start_day;

alter table public.cards
  add constraint chk_cards_statement_start_day check (statement_start_day between 1 and 31);

create index if not exists idx_cards_user_statement_start_day
  on public.cards(user_id, statement_start_day);

-- 2.2 transaction_type enum: '카드_대금' is included in initial type definition on clean install.
-- 2.3 transactions: 카드/계좌 정합성 체크 (직접 INSERT 방지용, 기존 데이터 호환을 위해 NOT VALID)
alter table public.transactions
  drop constraint if exists chk_transactions_card_based_no_account;

alter table public.transactions
  add constraint chk_transactions_card_based_no_account
    check (
      case
        when card_id is not null and type in ('지출','수입','수수료','세금')
          then account_id is null
        else true
      end
    ) not valid;

alter table public.transactions
  drop constraint if exists chk_transactions_card_payment_requires_both;

alter table public.transactions
  add constraint chk_transactions_card_payment_requires_both
    check (
      case
        when type = '카드_대금'
          then (account_id is not null and card_id is not null)
        else true
      end
    ) not valid;



-- =========================================================
-- 3) Card cycle bounds helper (start_day -> [period_start, period_end])
-- =========================================================
create or replace function public.calc_card_cycle_bounds(
  p_start_day int,
  p_as_of date
)
returns table(period_start date, period_end date)
language plpgsql
stable
security invoker
set search_path = public
as $$
declare
  v_start_day int := greatest(1, least(p_start_day, 31));
  v_asof date := p_as_of;

  v_this_month_first date := date_trunc('month', v_asof::timestamp)::date;
  v_prev_month_first date := (v_this_month_first - interval '1 month')::date;

  v_this_month_last date := (v_this_month_first + interval '1 month - 1 day')::date;
  v_prev_month_last date := (v_prev_month_first + interval '1 month - 1 day')::date;

  v_start_month_first date;
  v_start_month_last  date;

  v_next_month_first date;
  v_next_month_last  date;

  v_start date;
  v_next_start date;
begin
  -- if today >= start_day => cycle started this month, else previous month
  if extract(day from v_asof)::int >= v_start_day then
    v_start_month_first := v_this_month_first;
    v_start_month_last  := v_this_month_last;
  else
    v_start_month_first := v_prev_month_first;
    v_start_month_last  := v_prev_month_last;
  end if;

  -- clamp day to month last day (29~31 edge)
  v_start :=
    v_start_month_first
    + (least(v_start_day, extract(day from v_start_month_last)::int) - 1);

  v_next_month_first := (v_start_month_first + interval '1 month')::date;
  v_next_month_last  := (v_next_month_first + interval '1 month - 1 day')::date;

  v_next_start :=
    v_next_month_first
    + (least(v_start_day, extract(day from v_next_month_last)::int) - 1);

  period_start := v_start;
  period_end   := v_next_start - 1;
  return;
end;
$$;

grant execute on function public.calc_card_cycle_bounds(int, date) to authenticated;


-- =========================================================
-- 4) Views for Card Pages (current cycle spend + account grouped)
-- =========================================================
-- 월별 카드 납부액(결제된 금액) 조회용
-- =========================================================
-- 5) process_transaction_v2: 카드 결제(지출/수입)에서 account_id optional + 카드대금 처리
--    - 카드 사용 시: card_id not null AND account_id MUST be null (cash untouched)
--    - 카드 납부 시: type='카드_대금', account_id + card_id required (cash decreases)
-- =========================================================
create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  -- v1.3.2: category FK + merchant
  p_category_id uuid default null,
  p_merchant text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;

  -- v1.3.2: category FK enforcement
  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_month_start timestamptz := (date_trunc('month', timezone('Asia/Seoul', now())) at time zone 'Asia/Seoul');
  v_month_end timestamptz := ((date_trunc('month', timezone('Asia/Seoul', now())) + interval '1 month') at time zone 'Asia/Seoul');

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;

  v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;


  -- Resolve & validate category (FK)
  -- NOTE: DB constraint also enforces category_id for 지출/수입. This keeps error messages user-friendly.
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    -- Other types: category is optional; if category_id is provided, validate it.
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- [v1.3.1] Currency guard:
    -- Prevent KRW account -> USD account transfer without explicit FX transaction.
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  -- Payment method rules (account vs card)
  --  - Bank-based: account_id required, card_id must be null
  --  - Card-based: card_id required, account_id must be null (cash untouched)
  if p_type in ('지출','수입','수수료','세금') then
    if p_card_id is null and p_account_id is null then
      raise exception 'Either account_id or card_id is required for this transaction type';
    end if;

    if p_card_id is not null and p_account_id is not null then
      raise exception 'For card-based transactions, account_id must be NULL (type=%)', p_type;
    end if;
  end if;

  if p_type = '배당금' then
    if p_account_id is null then
      raise exception 'account_id is required for dividend';
    end if;
  end if;

  if p_type = '카드_대금' then
    if p_account_id is null or p_card_id is null then
      raise exception 'account_id and card_id are required for card payment';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id
  )
  returning transaction_id into v_tx_id;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','카드_대금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates
  if p_type = '주식_매수' then
    v_delta_qty := p_qty;
  elsif p_type = '주식_매도' then
    v_delta_qty := -p_qty;
  end if;

  if v_delta_qty <> 0 then
    insert into public.holdings(user_id, stock_id, holdings_qty, last_updated)
    values (v_user_id, p_stock_id, greatest(v_delta_qty, 0), now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = public.holdings.holdings_qty + v_delta_qty,
      last_updated = now();

    if exists (
      select 1 from public.holdings
      where user_id = v_user_id and stock_id = p_stock_id and holdings_qty < 0
    ) then
      raise exception 'Holdings cannot be negative (stock_id=%)', p_stock_id;
    end if;
  end if;

  -- Liabilities principal update
  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Monthly KPI accumulation (simple)
  if p_date >= v_month_start and p_date < v_month_end then
    if p_type in ('지출','수수료','세금','대출_상환_이자') then
      update public.stats
      set expense_this_month = expense_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type in ('수입','배당금') then
      update public.stats
      set income_this_month = income_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type = '대출_상환_이자' then
      update public.stats
      set interest_cost_this_month = interest_cost_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);

  return v_tx_id;
end;
$$;

-- =========================================================
-- 6) reverse_transaction: '카드_대금' reversal mapping 추가
-- =========================================================
create or replace function public.reverse_transaction(
  p_transaction_id uuid,
  p_reason text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;

  v_reverse_type transaction_type;
  v_reverse_account_id uuid;
  v_reverse_to_account_id uuid;
  v_reverse_memo text;

  v_new_tx_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_org
  from public.transactions
  where transaction_id = p_transaction_id
    and user_id = v_user_id;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot reverse a correction transaction';
  end if;

  -- Determine reverse mapping
  v_reverse_account_id := v_org.account_id;
  v_reverse_to_account_id := v_org.to_account_id;

  if v_org.type = '지출' then
    v_reverse_type := '수입';
  elsif v_org.type = '수입' then
    v_reverse_type := '지출';
  elsif v_org.type = '배당금' then
    v_reverse_type := '지출';
  elsif v_org.type in ('수수료','세금','대출_상환_이자') then
    v_reverse_type := '수입';
  elsif v_org.type = '대출_실행' then
    v_reverse_type := '대출_상환_원금';
  elsif v_org.type = '대출_상환_원금' then
    v_reverse_type := '대출_실행';
  elsif v_org.type = '주식_매수' then
    v_reverse_type := '주식_매도';
  elsif v_org.type = '주식_매도' then
    v_reverse_type := '주식_매수';
  elsif v_org.type = '환전_매수' then
    v_reverse_type := '환전_매도';
  elsif v_org.type = '환전_매도' then
    v_reverse_type := '환전_매수';
  elsif v_org.type = '카드_대금' then
    v_reverse_type := '수입';
    elsif v_org.type = '이체' then
    v_reverse_type := '이체';
    -- swap directions
    v_reverse_account_id := v_org.to_account_id;
    v_reverse_to_account_id := v_org.account_id;
  else
    raise exception 'Unsupported reverse mapping for type=%', v_org.type;
  end if;

  v_reverse_memo :=
    coalesce('[REVERSAL] ' || p_reason, '[REVERSAL]') ||
    ' (orig=' || v_org.transaction_id::text || ')';

  -- Create opposite entry via main RPC
  v_new_tx_id := public.process_transaction_v2(
    v_org.date,                    -- same date (or now() if preferred)
    v_reverse_type,
    v_org.amount,
    v_org.currency,
    v_reverse_account_id,
    v_reverse_to_account_id,
    v_org.card_id,
    v_org.stock_id,
    v_org.qty,
    v_org.fx_rate,
    v_org.liability_id,
    v_org.category,
    v_reverse_memo,
    true,                          -- is_correction
    v_org.transaction_id,          -- linked_transaction_id
    v_org.category_id,             -- category_id (v1.3.2)
    v_org.merchant                 -- merchant (v1.3.2)
  );

  return v_new_tx_id;
end;
$$;

-- =========================================================
-- Notes:
--  - refresh_stats는 '카드 미결제액'을 부채로 포함하지 않습니다 (요구사항: 순자산은 현금/통장+주식-부채).
--  - 카드 사용(지출/수수료/세금/수입 환불)은 card_id 기반으로만 집계하며, account_balances에는 영향이 없습니다.
--  - 카드 납부(type='카드_대금')는 account_id를 차감하고, 월 지출 KPI에는 포함되지 않습니다(이중계상 방지).
-- =========================================================


-- =====================================================================
-- SECTION V2.0 FINAL (2026-01-26): Transaction Edit(수정) + KPI 재계산 + View 필터링(VOID/CORRECTION)
--  - 핵심 정책(요구사항):
--      * 카드 사용(지출/수수료/세금/환불 수입)은 통장 잔액/순자산에 영향 없음 (card_id만 기록, account_id=NULL)
--      * 카드 대금 납부(type='카드_대금')는 통장에서 빠져나가며 순자산 감소 (account_id+card_id 필요)
--      * 순자산은 현금/통장(+외화) + 주식 - 부채(대출 등) / 카드 미결제액은 부채에 포함하지 않음
--      * 거래내역 수정은 UPDATE가 아니라: 원거래 VOID + (교정/역거래) + 새 거래 생성
-- =====================================================================

-- =========================================================
-- 1) transactions: VOID/수정 추적 컬럼 추가
-- =========================================================
alter table public.transactions
  add column if not exists is_voided boolean not null default false,
  add column if not exists voided_at timestamptz null,
  add column if not exists void_reason text null,
  add column if not exists superseded_by uuid null references public.transactions(transaction_id) on delete set null;

create index if not exists idx_transactions_user_voided_date
  on public.transactions(user_id, is_voided, date desc);

create index if not exists idx_transactions_user_superseded_by
  on public.transactions(user_id, superseded_by)
  where superseded_by is not null;

-- 카드/계좌 정합성 + "출처 필수" 강화 (직접 INSERT 방지, 기존 데이터 호환을 위해 NOT VALID 유지)
alter table public.transactions
  drop constraint if exists chk_transactions_payment_source_required;

alter table public.transactions
  add constraint chk_transactions_payment_source_required
    check (
      case
        when type in ('지출','수입','수수료','세금')
          then (account_id is not null and card_id is null)
            or (account_id is null and card_id is not null)
        when type = '카드_대금'
          then (account_id is not null and card_id is not null)
        else true
      end
    ) not valid;

-- 성능 인덱스(카드/계좌 집계용)
create index if not exists idx_transactions_user_card_date
  on public.transactions(user_id, card_id, date desc)
  where card_id is not null;

create index if not exists idx_transactions_user_account_date
  on public.transactions(user_id, account_id, date desc)
  where account_id is not null;


-- =========================================================
-- 2) 월간 KPI(이번달 수입/지출/이자) 재계산 함수
--    - VOID/CORRECTION 제외
--    - "이번달" 기준은 KST(Asia/Seoul) 달력월
-- =========================================================
create or replace function public.recalc_monthly_kpis(
  p_user_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_month_start timestamptz;
  v_month_end timestamptz;
  v_expense numeric(18,2);
  v_income numeric(18,2);
  v_interest numeric(18,2);
begin
  perform public.ensure_stats_row(p_user_id);

  -- KST 달력월 경계
  v_month_start := (date_trunc('month', timezone('Asia/Seoul', now())) at time zone 'Asia/Seoul');
  v_month_end := ((date_trunc('month', timezone('Asia/Seoul', now())) + interval '1 month') at time zone 'Asia/Seoul');

  select
    coalesce(sum(case when t.type in ('지출','수수료','세금','대출_상환_이자') then t.amount else 0 end), 0),
    coalesce(sum(case when t.type in ('수입','배당금') then t.amount else 0 end), 0),
    coalesce(sum(case when t.type = '대출_상환_이자' then t.amount else 0 end), 0)
  into v_expense, v_income, v_interest
  from public.transactions t
  where t.user_id = p_user_id
    and t.is_voided = false
    and t.is_correction = false
    and t.date >= v_month_start
    and t.date < v_month_end;

  update public.stats
  set
    expense_this_month = v_expense,
    income_this_month = v_income,
    interest_cost_this_month = v_interest,
    updated_at = now()
  where user_id = p_user_id;
end;
$$;

grant execute on function public.recalc_monthly_kpis(uuid) to authenticated;


-- =========================================================
-- 3) process_transaction_v2 (FINAL v2.3.0)
--    - idempotency(client_tx_id) + 카드 규칙 + KPI 재계산
-- =========================================================
create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  p_category_id uuid default null,
  p_merchant text default null,

  p_client_tx_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;
  v_existing_tx_id uuid;

  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;

  v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- Idempotency fast-path
  if p_client_tx_id is not null then
    select transaction_id into v_existing_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;

    if v_existing_tx_id is not null then
      return v_existing_tx_id;
    end if;
  end if;

  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;

  -- Resolve & validate category (FK)
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- Currency guard
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  -- 결제수단 규칙(카드/계좌)
  if p_type in ('지출','수입','수수료','세금') then
    if p_card_id is null and p_account_id is null then
      raise exception 'Either account_id or card_id is required for this transaction type';
    end if;

    if p_card_id is not null and p_account_id is not null then
      raise exception 'For card-based transactions, account_id must be NULL (type=%)', p_type;
    end if;
  end if;

  if p_type = '배당금' then
    if p_account_id is null then
      raise exception 'account_id is required for dividend';
    end if;
  end if;

  if p_type = '카드_대금' then
    if p_account_id is null or p_card_id is null then
      raise exception 'account_id and card_id are required for card payment';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert (race-safe idempotency)
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id,
    client_tx_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id,
    p_client_tx_id
  )
  on conflict (user_id, client_tx_id) where client_tx_id is not null
  do nothing
  returning transaction_id into v_tx_id;

  if v_tx_id is null and p_client_tx_id is not null then
    select transaction_id into v_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;

    if v_tx_id is not null then
      return v_tx_id;
    end if;

    raise exception 'Idempotency conflict: insert did nothing but existing row not found (client_tx_id=%)', p_client_tx_id;
  end if;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','카드_대금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates
  if p_type = '주식_매수' then
    v_delta_qty := p_qty;
  elsif p_type = '주식_매도' then
    v_delta_qty := -p_qty;
  end if;

  if v_delta_qty <> 0 then
    insert into public.holdings(user_id, stock_id, holdings_qty, last_updated)
    values (v_user_id, p_stock_id, greatest(v_delta_qty, 0), now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = public.holdings.holdings_qty + v_delta_qty,
      last_updated = now();

    if exists (
      select 1 from public.holdings
      where user_id = v_user_id and stock_id = p_stock_id and holdings_qty < 0
    ) then
      raise exception 'Holdings cannot be negative (stock_id=%)', p_stock_id;
    end if;
  end if;

  -- Liabilities principal update
  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);
  perform public.recalc_monthly_kpis(v_user_id);

  return v_tx_id;
end;
$$;

grant execute on function public.process_transaction_v2(
  timestamptz, transaction_type, numeric, currency_code,
  uuid, uuid, uuid, uuid, numeric, numeric, uuid, text, text, boolean, uuid,
  uuid, text, uuid
) to authenticated;


-- =========================================================
-- 4) reverse_transaction (FINAL v2.3.0)
--    - 카드_대금 역거래 시 card_id 제거(검증 통과) + VOID/CORRECTION 로직은 edit에서 처리
-- =========================================================
create or replace function public.reverse_transaction(
  p_transaction_id uuid,
  p_reason text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;

  v_reverse_type transaction_type;
  v_reverse_account_id uuid;
  v_reverse_to_account_id uuid;
  v_reverse_card_id uuid;
  v_reverse_memo text;

  v_new_tx_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_org
  from public.transactions
  where transaction_id = p_transaction_id
    and user_id = v_user_id;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot reverse a correction transaction';
  end if;

  v_reverse_account_id := v_org.account_id;
  v_reverse_to_account_id := v_org.to_account_id;
  v_reverse_card_id := v_org.card_id;

  if v_org.type = '지출' then
    v_reverse_type := '수입';
  elsif v_org.type = '수입' then
    v_reverse_type := '지출';
  elsif v_org.type = '배당금' then
    v_reverse_type := '지출';
  elsif v_org.type in ('수수료','세금','대출_상환_이자') then
    v_reverse_type := '수입';
  elsif v_org.type = '대출_실행' then
    v_reverse_type := '대출_상환_원금';
  elsif v_org.type = '대출_상환_원금' then
    v_reverse_type := '대출_실행';
  elsif v_org.type = '주식_매수' then
    v_reverse_type := '주식_매도';
  elsif v_org.type = '주식_매도' then
    v_reverse_type := '주식_매수';
  elsif v_org.type = '환전_매수' then
    v_reverse_type := '환전_매도';
  elsif v_org.type = '환전_매도' then
    v_reverse_type := '환전_매수';
  elsif v_org.type = '카드_대금' then
    -- 카드 대금 취소는 "수입(통장)"으로 처리 (card_id 제거)
    v_reverse_type := '수입';
    v_reverse_card_id := null;
  elsif v_org.type = '이체' then
    v_reverse_type := '이체';
    v_reverse_account_id := v_org.to_account_id;
    v_reverse_to_account_id := v_org.account_id;
  else
    raise exception 'Unsupported reverse mapping for type=%', v_org.type;
  end if;

  v_reverse_memo :=
    coalesce('[REVERSAL] ' || p_reason, '[REVERSAL]') ||
    ' (orig=' || v_org.transaction_id::text || ')';

  v_new_tx_id := public.process_transaction_v2(
    v_org.date,
    v_reverse_type,
    v_org.amount,
    v_org.currency,
    v_reverse_account_id,
    v_reverse_to_account_id,
    v_reverse_card_id,
    v_org.stock_id,
    v_org.qty,
    v_org.fx_rate,
    v_org.liability_id,
    v_org.category,
    v_reverse_memo,
    true,
    v_org.transaction_id,
    v_org.category_id,
    v_org.merchant,
    null
  );

  return v_new_tx_id;
end;
$$;

grant execute on function public.reverse_transaction(uuid, text) to authenticated;


-- =========================================================
-- 5) edit_transaction_v2: 안전한 거래내역 수정(금액/계좌/카드 등 포함)
--    - 경제적 필드 변경 시: 원거래 VOID + reverse_transaction + 새 거래 생성
--    - 메모/가맹점/카테고리만 변경 시: 안전 UPDATE
-- =========================================================
create or replace function public.edit_transaction_v2(
  p_original_transaction_id uuid,

  -- 새 값(원하면 null=변경없음, 빈문자열=''로 "비우기" 가능)
  p_new_date timestamptz default null,
  p_new_type transaction_type default null,
  p_new_amount numeric default null,
  p_new_currency currency_code default null,

  p_new_account_id uuid default null,
  p_new_to_account_id uuid default null,
  p_new_card_id uuid default null,
  p_new_stock_id uuid default null,
  p_new_qty numeric default null,
  p_new_fx_rate numeric default null,
  p_new_liability_id uuid default null,

  p_new_category_id uuid default null,
  p_new_category text default null,
  p_new_merchant text default null,
  p_new_memo text default null,

  p_edit_reason text default null,
  p_client_tx_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;

  v_effective_date timestamptz;
  v_effective_type transaction_type;
  v_effective_amount numeric;
  v_effective_currency currency_code;

  v_effective_account_id uuid;
  v_effective_to_account_id uuid;
  v_effective_card_id uuid;
  v_effective_stock_id uuid;
  v_effective_qty numeric;
  v_effective_fx_rate numeric;
  v_effective_liability_id uuid;

  v_effective_category_id uuid;
  v_effective_category text;
  v_effective_merchant text;
  v_effective_memo text;

  v_is_economic_change boolean := false;
  v_new_tx_id uuid;

  v_cat public.categories%rowtype;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_org
  from public.transactions
  where transaction_id = p_original_transaction_id
    and user_id = v_user_id;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_original_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot edit a correction transaction';
  end if;

  if v_org.is_voided = true then
    raise exception 'Cannot edit a voided transaction (transaction_id=%)', p_original_transaction_id;
  end if;

  -- coalesce 새 값 적용
  v_effective_date := coalesce(p_new_date, v_org.date);
  v_effective_type := coalesce(p_new_type, v_org.type);
  v_effective_amount := coalesce(p_new_amount, v_org.amount);
  v_effective_currency := coalesce(p_new_currency, v_org.currency);

  v_effective_account_id := coalesce(p_new_account_id, v_org.account_id);
  v_effective_to_account_id := coalesce(p_new_to_account_id, v_org.to_account_id);
  v_effective_card_id := coalesce(p_new_card_id, v_org.card_id);
  v_effective_stock_id := coalesce(p_new_stock_id, v_org.stock_id);
  v_effective_qty := coalesce(p_new_qty, v_org.qty);
  v_effective_fx_rate := coalesce(p_new_fx_rate, v_org.fx_rate);
  v_effective_liability_id := coalesce(p_new_liability_id, v_org.liability_id);

  v_effective_category_id := coalesce(p_new_category_id, v_org.category_id);
  v_effective_category := coalesce(p_new_category, v_org.category);
  v_effective_merchant := coalesce(p_new_merchant, v_org.merchant);
  v_effective_memo := coalesce(p_new_memo, v_org.memo);

  -- 경제적 필드 변경 여부 판단
  v_is_economic_change :=
    (v_effective_date is distinct from v_org.date)
    or (v_effective_type is distinct from v_org.type)
    or (v_effective_amount is distinct from v_org.amount)
    or (v_effective_currency is distinct from v_org.currency)
    or (v_effective_account_id is distinct from v_org.account_id)
    or (v_effective_to_account_id is distinct from v_org.to_account_id)
    or (v_effective_card_id is distinct from v_org.card_id)
    or (v_effective_stock_id is distinct from v_org.stock_id)
    or (v_effective_qty is distinct from v_org.qty)
    or (v_effective_fx_rate is distinct from v_org.fx_rate)
    or (v_effective_liability_id is distinct from v_org.liability_id);

  if v_is_economic_change = false then
    -- 안전한 메타 수정(카테고리/메모/가맹점만)
    if v_effective_type in ('지출','수입') then
      if v_effective_category_id is null then
        raise exception 'category_id is required for expense/income edits';
      end if;

      select * into v_cat
      from public.categories
      where user_id = v_user_id and category_id = v_effective_category_id;

      if not found then
        raise exception 'Unknown category_id=%', v_effective_category_id;
      end if;

      if v_effective_type = '지출' and v_cat.category_kind = '수입' then
        raise exception 'Category kind mismatch: expense cannot use income category';
      elsif v_effective_type = '수입' and v_cat.category_kind = '지출' then
        raise exception 'Category kind mismatch: income cannot use expense category';
      end if;

      v_effective_category := v_cat.category_name; -- snapshot
    end if;

    update public.transactions
    set
      category_id = v_effective_category_id,
      category = v_effective_category,
      merchant = v_effective_merchant,
      memo = v_effective_memo
    where transaction_id = v_org.transaction_id
      and user_id = v_user_id;

    perform public.recalc_monthly_kpis(v_user_id);
    return v_org.transaction_id;
  end if;

  -- 경제적 수정: 원거래를 무효화 + 교정 + 새 거래
  perform public.reverse_transaction(v_org.transaction_id, coalesce(p_edit_reason, 'EDIT'));

  v_new_tx_id := public.process_transaction_v2(
    v_effective_date,
    v_effective_type,
    v_effective_amount,
    v_effective_currency,
    v_effective_account_id,
    v_effective_to_account_id,
    v_effective_card_id,
    v_effective_stock_id,
    v_effective_qty,
    v_effective_fx_rate,
    v_effective_liability_id,
    v_effective_category,
    v_effective_memo,
    false,
    null,
    v_effective_category_id,
    v_effective_merchant,
    p_client_tx_id
  );

  update public.transactions
  set
    is_voided = true,
    voided_at = now(),
    void_reason = coalesce(p_edit_reason, 'EDIT'),
    superseded_by = v_new_tx_id
  where transaction_id = v_org.transaction_id
    and user_id = v_user_id;

  -- stats는 process_transaction_v2에서 refresh + recalc를 수행하므로 여기서 추가 호출은 생략
  return v_new_tx_id;
end;
$$;

grant execute on function public.edit_transaction_v2(
  uuid, timestamptz, transaction_type, numeric, currency_code,
  uuid, uuid, uuid, uuid, numeric, numeric, uuid,
  uuid, text, text, text, text, uuid
) to authenticated;


-- =========================================================
-- 6) v_transactions_with_info / v_transactions_display
--    - display는 VOID/CORRECTION 제외 (앱 기본 리스트용)
-- =========================================================
create or replace view public.v_transactions_with_info as
select
  t.transaction_id,
  t.user_id,
  t.date,
  t.type,
  t.amount,
  t.currency,
  t.account_id,
  a.account_name,
  t.to_account_id,
  ta.account_name as to_account_name,
  t.category_id,
  coalesce(cat.category_name, t.category) as category,
  cat.category_kind,
  t.merchant,
  t.memo,
  t.card_id,
  c.card_name,
  c.linked_account_id as card_linked_account_id,
  ca.account_name as card_linked_account_name,
  t.stock_id,
  s.ticker as stock_ticker,
  s.name   as stock_name,
  s.market as stock_market,
  t.qty,
  t.fx_rate,
  t.liability_id,
  l.liability_name,
  t.is_correction,
  t.linked_transaction_id,
  t.is_voided,
  t.voided_at,
  t.void_reason,
  t.superseded_by,
  t.client_tx_id,
  t.created_at,
  t.updated_at
from public.transactions t
left join public.accounts a
  on a.account_id = t.account_id and a.user_id = t.user_id
left join public.accounts ta
  on ta.account_id = t.to_account_id and ta.user_id = t.user_id
left join public.categories cat
  on cat.user_id = t.user_id and cat.category_id = t.category_id
left join public.cards c
  on c.card_id = t.card_id and c.user_id = t.user_id
left join public.accounts ca
  on ca.account_id = c.linked_account_id and ca.user_id = t.user_id
left join public.stocks s
  on s.stock_id = t.stock_id and s.user_id = t.user_id
left join public.liabilities l
  on l.liability_id = t.liability_id and l.user_id = t.user_id
;

grant select on public.v_transactions_with_info to authenticated;

create or replace view public.v_transactions_display as
select *
from public.v_transactions_with_info
where is_voided = false
  and is_correction = false;

grant select on public.v_transactions_display to authenticated;


-- =========================================================
-- 7) 카드 집계 VIEW들: VOID/CORRECTION 제외하도록 FINAL override
-- =========================================================
create or replace view public.v_card_cycle_spend_current as
select
  c.user_id,
  c.card_id,
  c.card_name,
  c.linked_account_id,
  c.statement_start_day,
  b.period_start,
  b.period_end,
  coalesce(sum(
    case
      when t.type in ('지출','수수료','세금') then t.amount
      when t.type = '수입' then -t.amount
      else 0
    end
  ), 0) as spend_amount_krw
from public.cards c
cross join lateral public.calc_card_cycle_bounds(
  c.statement_start_day,
  timezone('Asia/Seoul', now())::date
) b
left join public.transactions t
  on t.user_id = c.user_id
 and t.card_id = c.card_id
 and t.is_voided = false
 and t.is_correction = false
 and timezone('Asia/Seoul', t.date)::date between b.period_start and b.period_end
 and t.currency = 'KRW'
 and t.type in ('지출','수수료','세금','수입')
group by
  c.user_id, c.card_id, c.card_name, c.linked_account_id, c.statement_start_day, b.period_start, b.period_end;

grant select on public.v_card_cycle_spend_current to authenticated;

create or replace view public.v_card_cycle_spend_by_account_current as
select
  v.user_id,
  v.linked_account_id as account_id,
  a.account_name,
  a.account_type,
  v.period_start,
  v.period_end,
  sum(v.spend_amount_krw) as spend_amount_krw,
  count(*) as card_count
from public.v_card_cycle_spend_current v
join public.accounts a
  on a.user_id = v.user_id and a.account_id = v.linked_account_id
group by
  v.user_id, v.linked_account_id, a.account_name, a.account_type, v.period_start, v.period_end;

grant select on public.v_card_cycle_spend_by_account_current to authenticated;

create or replace view public.v_card_payments_monthly as
select
  t.user_id,
  t.card_id,
  c.card_name,
  date_trunc('month', timezone('Asia/Seoul', t.date))::date as month_kst,
  sum(t.amount) as paid_amount_krw
from public.transactions t
join public.cards c
  on c.user_id = t.user_id and c.card_id = t.card_id
where t.type = '카드_대금'
  and t.currency = 'KRW'
  and t.is_voided = false
  and t.is_correction = false
group by t.user_id, t.card_id, c.card_name, date_trunc('month', timezone('Asia/Seoul', t.date))::date;

grant select on public.v_card_payments_monthly to authenticated;


-- =========================================================
-- 8) 카드 월별 사용액(청구기간 기준) - 최근 12개 사이클
--    - 예: start_day=12면 "1월"=1/12~2/11, "2월"=2/12~3/11 ...
--    - 현재 사이클은 오늘까지 누적
-- =========================================================
create or replace view public.v_card_cycle_spend_recent_12 as
with today as (
  select timezone('Asia/Seoul', now())::date as today_kst
)
select
  c.user_id,
  c.card_id,
  c.card_name,
  c.statement_start_day,
  b.period_start,
  b.period_end,
  date_trunc('month', b.period_start)::date as cycle_month_kst,
  coalesce(sum(
    case
      when t.type in ('지출','수수료','세금') then t.amount
      when t.type = '수입' then -t.amount
      else 0
    end
  ), 0) as spend_amount_krw
from public.cards c
cross join today td
cross join generate_series(0, 11) as gs(n)
cross join lateral public.calc_card_cycle_bounds(
  c.statement_start_day,
  (td.today_kst - (gs.n || ' month')::interval)::date
) b
left join public.transactions t
  on t.user_id = c.user_id
 and t.card_id = c.card_id
 and t.is_voided = false
 and t.is_correction = false
 and t.currency = 'KRW'
 and t.type in ('지출','수수료','세금','수입')
 and timezone('Asia/Seoul', t.date)::date between b.period_start and least(b.period_end, td.today_kst)
group by
  c.user_id, c.card_id, c.card_name, c.statement_start_day, b.period_start, b.period_end, date_trunc('month', b.period_start)::date;

grant select on public.v_card_cycle_spend_recent_12 to authenticated;


-- =========================================================
-- 9) Dashboard RPC: 최근 거래는 display(VOID/CORRECTION 제외) 기준으로 반환
-- =========================================================
create or replace function public.get_dashboard(
  p_limit int default 10,
  p_include_nav boolean default true
)
returns jsonb
language plpgsql
stable
security invoker
as $$
declare
  v_uid uuid := (select auth.uid());
  v_stats jsonb;
  v_recent jsonb;
  v_sync jsonb;
  v_kis jsonb;
  v_nav jsonb;
begin
  if v_uid is null then
    raise exception 'Unauthenticated: auth.uid() is null';
  end if;

  select to_jsonb(s)
  into v_stats
  from public.stats s
  where s.user_id = v_uid;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.date desc, t.created_at desc), '[]'::jsonb)
  into v_recent
  from (
    select *
    from public.v_transactions_display
    where user_id = v_uid
    order by date desc, created_at desc
    limit greatest(p_limit, 1)
  ) t;

  select to_jsonb(x)
  into v_sync
  from (
    select status, mode, market, started_at, finished_at, market_data_asof, detail
    from public.market_data_sync_runs
    where user_id = v_uid
    order by started_at desc
    limit 1
  ) x;

  select to_jsonb(k)
  into v_kis
  from (
    select id, expires_at, last_issued_at, last_attempt_at, refresh_deadline, refresh_owner, updated_at
    from public.kis_token_cache
    where id = 1
    limit 1
  ) k;

  if p_include_nav then
    select to_jsonb(n)
    into v_nav
    from (
      with last2 as (
        select trading_date, nav_krw
        from public.portfolio_nav_daily
        where user_id = v_uid
        order by trading_date desc
        limit 2
      )
      select
        (select trading_date from last2 order by trading_date desc limit 1) as latest_date,
        (select nav_krw from last2 order by trading_date desc limit 1)      as latest_nav_krw,
        (select nav_krw from last2 order by trading_date desc offset 1 limit 1) as prev_nav_krw,
        ((select nav_krw from last2 order by trading_date desc limit 1)
         - (select nav_krw from last2 order by trading_date desc offset 1 limit 1)) as delta_nav_krw
    ) n;
  else
    v_nav := null;
  end if;

  return jsonb_build_object(
    'user_id', v_uid,
    'stats', v_stats,
    'recent', v_recent,
    'sync', v_sync,
    'kis', v_kis,
    'nav', v_nav,
    'generated_at', now()
  );
end $$;

grant execute on function public.get_dashboard(int, boolean) to authenticated;

-- =========================================================
-- END OF V2.0 FINAL SECTION
-- =========================================================


-- ======================================================================
-- Security harden (from PAD_DB_SECURITY_HARDEN_v2.3.0sql)
-- ======================================================================
-- PAD DB Security Hardening (v2.3.0)
-- 목적: "정합성 핵심 테이블"은 RPC(SECURITY DEFINER)로만 쓰기 허용하고,
--       클라이언트(authenticated)의 직접 INSERT/UPDATE/DELETE를 차단합니다.
-- 실행 위치: Supabase Dashboard > SQL Editor (또는 migration으로 버전관리)

begin;

-- Tier 1 (필수 권장): 거래 정합성 핵심
revoke insert, update, delete on table public.transactions      from authenticated;
revoke insert, update, delete on table public.account_balances  from authenticated;
revoke insert, update, delete on table public.holdings          from authenticated;
revoke insert, update, delete on table public.stats             from authenticated;

-- Tier 2 (권장): 스냅샷/지표/성과(계산 결과) 테이블도 직접 쓰기 차단
revoke insert, update, delete on table public.account_nav_daily         from authenticated;
revoke insert, update, delete on table public.account_stock_nav_daily   from authenticated;
revoke insert, update, delete on table public.portfolio_nav_daily       from authenticated;
revoke insert, update, delete on table public.portfolio_returns_monthly from authenticated;
revoke insert, update, delete on table public.portfolio_metrics         from authenticated;

-- 주의:
-- - fx_rates / stock_prices 는 "시세/환율 동기화"를 MAUI가 직접 upsert하는 설계를 쓰면
--   여기서 revoke 하면 안 됩니다. (대신 RPC로 수집/업데이트하도록 구조를 바꾸는 게 가장 안전)
-- - market_data_sync_runs 는 RLS 정책으로 service_role write를 강제하고 있으므로
--   authenticated에 insert/update grant가 있어도 실제로는 막힙니다.
--   혼동을 줄이려면 grant를 정리하는 별도 패치를 고려하세요.

commit;


-- ======================================================================
-- 2026-01-27 patch pack
-- ======================================================================

/* =====================================================================
   PAD v2.3.0x - Market Data Server Sync Patch Pack (2026-01-27)
   - Idempotent policy fix for market_data_sync_runs (avoid 42710)
   - Optional client-write revokes for server-owned market data tables
   ===================================================================== */

-- Ensure these tables are server-owned (write only by service-role)
revoke insert, update, delete on public.fx_rates from authenticated;
revoke insert, update, delete on public.stock_prices from authenticated;
revoke insert, update, delete on public.currency_wallet from authenticated;
revoke insert, update, delete on public.market_data_sync_runs from authenticated;

-- [PATCH] Fix: policy already exists (ERROR 42710) -> drop then recreate
drop policy if exists "market_data_sync_runs_owner_read" on public.market_data_sync_runs;
drop policy if exists "market_data_sync_runs_service_write" on public.market_data_sync_runs;
drop policy if exists "market_data_sync_runs_service_update" on public.market_data_sync_runs;

create policy "market_data_sync_runs_owner_read"
on public.market_data_sync_runs for select
using (user_id = auth.uid() or public.is_service_role());

create policy "market_data_sync_runs_service_write"
on public.market_data_sync_runs for insert
with check (public.is_service_role());

create policy "market_data_sync_runs_service_update"
on public.market_data_sync_runs for update
using (public.is_service_role())
with check (public.is_service_role());

/* ===================================================================== */




-- =========================================================
-- PAD v2.3.0 PATCH: Daily Market Data + Daily Close Snapshots
--   - 목적: KST 00:00 기준(전일) 스냅샷 저장 전에 시장데이터(환율/주가) 최신화
--   - 과거 거래 수정/취소(최소 10일+) 반영을 위해 일별 스냅샷 재계산 지원
-- =========================================================

-- 0) Allow negative NAV (net worth can be negative when liabilities > assets)
alter table public.portfolio_nav_daily
  drop constraint if exists chk_nav_non_negative;

-- 1) Daily Market Data Tables
create table if not exists public.fx_rates_daily (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  trading_date date not null,
  pair text not null,
  rate numeric(18,6) not null,
  source text not null default 'frankfurter',
  market_data_asof timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint pk_fx_rates_daily primary key (user_id, trading_date, pair)
);

create index if not exists idx_fx_rates_daily_user_date
  on public.fx_rates_daily(user_id, trading_date desc);

alter table public.fx_rates_daily enable row level security;

drop policy if exists "fx_rates_daily_owner_read" on public.fx_rates_daily;
drop policy if exists "fx_rates_daily_service_write" on public.fx_rates_daily;
drop policy if exists "fx_rates_daily_service_update" on public.fx_rates_daily;

create policy "fx_rates_daily_owner_read"
on public.fx_rates_daily for select
using (user_id = auth.uid() or public.is_service_role());

create policy "fx_rates_daily_service_write"
on public.fx_rates_daily for insert
with check (public.is_service_role());

create policy "fx_rates_daily_service_update"
on public.fx_rates_daily for update
using (public.is_service_role())
with check (public.is_service_role());

grant select on public.fx_rates_daily to authenticated;

create table if not exists public.stock_prices_daily (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  trading_date date not null,
  stock_id uuid not null references public.stocks(stock_id) on delete cascade,
  price numeric(18,6) not null,
  currency currency_code not null,
  source text not null default 'KIS',
  market_data_asof timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint pk_stock_prices_daily primary key (user_id, trading_date, stock_id)
);

create index if not exists idx_stock_prices_daily_user_date
  on public.stock_prices_daily(user_id, trading_date desc);

alter table public.stock_prices_daily enable row level security;

drop policy if exists "stock_prices_daily_owner_read" on public.stock_prices_daily;
drop policy if exists "stock_prices_daily_service_write" on public.stock_prices_daily;
drop policy if exists "stock_prices_daily_service_update" on public.stock_prices_daily;

create policy "stock_prices_daily_owner_read"
on public.stock_prices_daily for select
using (user_id = auth.uid() or public.is_service_role());

create policy "stock_prices_daily_service_write"
on public.stock_prices_daily for insert
with check (public.is_service_role());

create policy "stock_prices_daily_service_update"
on public.stock_prices_daily for update
using (public.is_service_role())
with check (public.is_service_role());

grant select on public.stock_prices_daily to authenticated;

-- 2) Daily Card Usage Table (for "일일 카드 사용량" 조회)
create table if not exists public.card_usage_daily (
  usage_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  trading_date date not null,
  card_id uuid not null references public.cards(card_id) on delete cascade,

  spend_krw numeric(18,2) not null default 0,
  spend_count int not null default 0,

  market_data_asof timestamptz not null,
  source text null default 'CRON',

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint uq_card_usage_daily unique (user_id, trading_date, card_id)
);

create index if not exists idx_card_usage_daily_user_date
  on public.card_usage_daily(user_id, trading_date desc);

alter table public.card_usage_daily enable row level security;

drop policy if exists "card_usage_daily_owner_read" on public.card_usage_daily;
drop policy if exists "card_usage_daily_service_write" on public.card_usage_daily;
drop policy if exists "card_usage_daily_service_update" on public.card_usage_daily;

create policy "card_usage_daily_owner_read"
on public.card_usage_daily for select
using (user_id = auth.uid() or public.is_service_role());

create policy "card_usage_daily_service_write"
on public.card_usage_daily for insert
with check (public.is_service_role());

create policy "card_usage_daily_service_update"
on public.card_usage_daily for update
using (public.is_service_role())
with check (public.is_service_role());

grant select on public.card_usage_daily to authenticated;

-- 3) Recalc Queue (when past transactions are edited/voided later)
create table if not exists public.daily_snapshot_recalc_queue (
  user_id uuid not null references auth.users(id) on delete cascade,
  trading_date date not null,
  reason text null,
  created_at timestamptz not null default now(),
  constraint pk_daily_snapshot_recalc_queue primary key (user_id, trading_date)
);

alter table public.daily_snapshot_recalc_queue enable row level security;

drop policy if exists "daily_snapshot_recalc_queue_owner_read" on public.daily_snapshot_recalc_queue;
drop policy if exists "daily_snapshot_recalc_queue_service_write" on public.daily_snapshot_recalc_queue;
drop policy if exists "daily_snapshot_recalc_queue_service_update" on public.daily_snapshot_recalc_queue;
drop policy if exists "daily_snapshot_recalc_queue_service_delete" on public.daily_snapshot_recalc_queue;

create policy "daily_snapshot_recalc_queue_owner_read"
on public.daily_snapshot_recalc_queue for select
using (user_id = auth.uid() or public.is_service_role());

create policy "daily_snapshot_recalc_queue_service_write"
on public.daily_snapshot_recalc_queue for insert
with check (public.is_service_role());

create policy "daily_snapshot_recalc_queue_service_update"
on public.daily_snapshot_recalc_queue for update
using (public.is_service_role())
with check (public.is_service_role());

create policy "daily_snapshot_recalc_queue_service_delete"
on public.daily_snapshot_recalc_queue for delete
using (public.is_service_role());

grant select on public.daily_snapshot_recalc_queue to authenticated;

-- 4) Utility: enqueue recalc
create or replace function public.enqueue_daily_snapshot_recalc(
  p_user_id uuid,
  p_trading_date date,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;

  insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
  values (p_user_id, p_trading_date, p_reason)
  on conflict (user_id, trading_date)
  do update set
    reason = coalesce(excluded.reason, public.daily_snapshot_recalc_queue.reason),
    created_at = public.daily_snapshot_recalc_queue.created_at;
end;
$$;

-- 5) Trigger: enqueue on transactions change (insert/update/delete)
create or replace function public.trg_enqueue_snapshot_recalc()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid;
  v_new_date date;
  v_old_date date;
begin
  v_user := coalesce(NEW.user_id, OLD.user_id);
  v_new_date := case when NEW.date is null then null else timezone('Asia/Seoul', NEW.date)::date end;
  v_old_date := case when OLD.date is null then null else timezone('Asia/Seoul', OLD.date)::date end;

  if v_user is null then
    return coalesce(NEW, OLD);
  end if;

  if v_old_date is not null then
    perform public.enqueue_daily_snapshot_recalc(v_user, v_old_date, TG_OP);
  end if;

  if v_new_date is not null and v_new_date is distinct from v_old_date then
    perform public.enqueue_daily_snapshot_recalc(v_user, v_new_date, TG_OP);
  end if;

  return coalesce(NEW, OLD);
end;
$$;

drop trigger if exists trg_transactions_snapshot_recalc on public.transactions;
create trigger trg_transactions_snapshot_recalc
after insert or update or delete on public.transactions
for each row execute function public.trg_enqueue_snapshot_recalc();

-- 6) Persist current market data into daily tables for a given trading_date
create or replace function public.persist_market_data_daily(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'CRON'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    raise exception 'Service role required';
  end if;

  -- FX: USDKRW
  insert into public.fx_rates_daily(user_id, trading_date, pair, rate, source, market_data_asof)
  select user_id, p_trading_date, pair, rate, source, p_market_data_asof
  from public.fx_rates
  where user_id = p_user_id and pair = 'USDKRW'
  on conflict (user_id, trading_date, pair)
  do update set
    rate = excluded.rate,
    source = excluded.source,
    market_data_asof = excluded.market_data_asof,
    updated_at = now();

  -- Stocks: copy latest price for this user's stocks
  insert into public.stock_prices_daily(user_id, trading_date, stock_id, price, currency, source, market_data_asof)
  select user_id, p_trading_date, stock_id, price, currency, source, p_market_data_asof
  from public.stock_prices
  where user_id = p_user_id
  on conflict (user_id, trading_date, stock_id)
  do update set
    price = excluded.price,
    currency = excluded.currency,
    source = excluded.source,
    market_data_asof = excluded.market_data_asof,
    updated_at = now();
end;
$$;

-- 7) Patch: capture_account_snapshots uses daily market data first + exclude voided
create or replace function public.capture_account_snapshots(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'KIS'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_usdkrw numeric(18,6);
  v_today_kst date := timezone('Asia/Seoul', now())::date;
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;
  -- USDKRW rate (daily snapshot first, fallback to latest)
  select rate into v_usdkrw
  from public.fx_rates_daily
  where user_id = p_user_id
    and trading_date = p_trading_date
    and pair = 'USDKRW'
  limit 1;

  if v_usdkrw is null then
    select rate into v_usdkrw
    from public.fx_rates
    where user_id = p_user_id and pair = 'USDKRW'
    limit 1;
  end if;

  if v_usdkrw is null then
    v_usdkrw := 0;
  end if;

  -- ---------------------------------------------------------
  -- A) Account x Stock valuation
  --    Holdings computed from transactions (account-scoped)
  --    Only include tx where (KST date) <= p_trading_date
  -- ---------------------------------------------------------
  with pos as (
    select
      t.account_id,
      t.stock_id,
      sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
      end) as qty
    from public.transactions t
    where t.user_id = p_user_id
      and t.is_correction = false
      and t.is_voided = false
      and t.account_id is not null
      and t.stock_id is not null
      and t.qty is not null
      and t.type in ('주식_매수','주식_매도')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.account_id, t.stock_id
    having sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
      end) <> 0
  ),
  priced as (
    select
      p_user_id as user_id,
      p_trading_date as trading_date,
      pos.account_id,
      pos.stock_id,
      pos.qty,
      coalesce(spd.price, spc.price) as price,
      coalesce(spd.currency, spc.currency) as price_currency,
      case when coalesce(spd.currency, spc.currency)='USD' then v_usdkrw else null end as fx_rate_used,
      round(
        case
          when coalesce(spd.currency, spc.currency)='KRW' then (pos.qty * coalesce(spd.price, spc.price))
          when coalesce(spd.currency, spc.currency)='USD' then (pos.qty * coalesce(spd.price, spc.price) * v_usdkrw)
          else 0
        end
      , 2) as value_krw
    from pos
    left join public.stock_prices_daily spd
      on spd.user_id = p_user_id and spd.trading_date = p_trading_date and spd.stock_id = pos.stock_id
    left join public.stock_prices spc
      on spc.user_id = p_user_id and spc.stock_id = pos.stock_id
    where coalesce(spd.price, spc.price) is not null
  )
  insert into public.account_stock_nav_daily(
    user_id, trading_date, account_id, stock_id,
    qty, price, price_currency, fx_rate_used, value_krw,
    market_data_asof, source
  )
  select
    user_id, trading_date, account_id, stock_id,
    qty, price, price_currency, fx_rate_used, value_krw,
    p_market_data_asof, p_source
  from priced
  on conflict (user_id, trading_date, account_id, stock_id)
  do update set
    qty = excluded.qty,
    price = excluded.price,
    price_currency = excluded.price_currency,
    fx_rate_used = excluded.fx_rate_used,
    value_krw = excluded.value_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();

  -- ---------------------------------------------------------
  -- B) Account valuation (cash + fx + stocks)
  --    cash: account_balances (current)
  --    usd_qty: from transactions (account-scoped), KST date <= p_trading_date
  -- ---------------------------------------------------------
  with usd_pos as (
    select
      t.account_id,
      sum(case
        when t.type='환전_매수' then t.qty
        when t.type='환전_매도' then -t.qty
        else 0
      end) as usd_qty
    from public.transactions t
    where t.user_id = p_user_id
      and t.is_correction = false
      and t.is_voided = false
      and t.account_id is not null
      and t.qty is not null
      and t.type in ('환전_매수','환전_매도')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.account_id
  ),
  cash as (
    select
      ab.account_id,
      sum(case
        when ab.currency='KRW' then ab.balance
        when ab.currency='USD' then ab.balance * v_usdkrw
        else 0
      end) as cash_krw
    from public.account_balances ab
    where ab.user_id = p_user_id
    group by ab.account_id
  ),
  stock_sum as (
    select
      account_id,
      coalesce(sum(value_krw),0) as stock_value_krw
    from public.account_stock_nav_daily
    where user_id = p_user_id
      and trading_date = p_trading_date
    group by account_id
  ),
  merged as (
    select
      a.account_id,
      coalesce(c.cash_krw,0) as cash_krw,
      coalesce(u.usd_qty,0) as usd_qty,
      round(coalesce(u.usd_qty,0) * v_usdkrw, 2) as usd_value_krw,
      coalesce(s.stock_value_krw,0) as stock_value_krw
    from public.accounts a
    left join cash c on c.account_id = a.account_id
    left join usd_pos u on u.account_id = a.account_id
    left join stock_sum s on s.account_id = a.account_id
    where a.user_id = p_user_id
      and a.is_include_in_networth = true
  )
  insert into public.account_nav_daily(
    user_id, trading_date, account_id,
    cash_krw, usd_qty, usd_value_krw, stock_value_krw, total_krw,
    market_data_asof, source
  )
  select
    p_user_id, p_trading_date, account_id,
    cash_krw, usd_qty, usd_value_krw, stock_value_krw,
    round(cash_krw + usd_value_krw + stock_value_krw, 2) as total_krw,
    p_market_data_asof, p_source
  from merged
  on conflict (user_id, trading_date, account_id)
  do update set
    cash_krw = excluded.cash_krw,
    usd_qty = excluded.usd_qty,
    usd_value_krw = excluded.usd_value_krw,
    stock_value_krw = excluded.stock_value_krw,
    total_krw = excluded.total_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();
end;
$$;

-- 8) Patch: capture_nav_snapshot computes NAV for trading_date (assets - liabilities) without relying on current stats
create or replace function public.capture_nav_snapshot(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'CRON'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_assets numeric(18,2);
  v_liab numeric(18,2);
  v_nav numeric(18,2);
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  select coalesce(sum(total_krw), 0)
    into v_assets
  from public.account_nav_daily
  where user_id = p_user_id
    and trading_date = p_trading_date;

  -- Liabilities as-of trading_date (principal only)
  select coalesce(sum(principal), 0)
    into v_liab
  from (
    select
      l.liability_id,
      coalesce(sum(
        case
          when t.type = '대출_실행' then t.amount
          when t.type = '대출_상환_원금' then -t.amount
          else 0
        end
      ), 0) as principal
    from public.liabilities l
    left join public.transactions t
      on t.user_id = l.user_id
     and t.liability_id = l.liability_id
     and t.is_correction = false
     and t.is_voided = false
     and t.type in ('대출_실행','대출_상환_원금')
     and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    where l.user_id = p_user_id
      and l.is_include_in_networth = true
    group by l.liability_id
  ) q;

  v_nav := round(v_assets - v_liab, 2);

  insert into public.portfolio_nav_daily(user_id, trading_date, nav_krw, market_data_asof, source)
  values (p_user_id, p_trading_date, v_nav, p_market_data_asof, p_source)
  on conflict (user_id, trading_date)
  do update set
    nav_krw = excluded.nav_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();
end;
$$;

-- 9) Capture: card usage daily (지출 with card_id, exclude voided/corrections)
create or replace function public.capture_card_usage_snapshot(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'CRON'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_usdkrw numeric(18,6);
  v_used_source text := p_source;
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  -- v2.3: resilient FX lookup (prevents rebuild from failing on a single missing day)
  -- Priority: exact daily -> previous daily (FFILL) -> current (only if NOT rebuild) -> abort day
  select rate into v_usdkrw
  from public.fx_rates_daily
  where user_id = p_user_id and trading_date = p_trading_date and pair='USDKRW'
  limit 1;

  if v_usdkrw is null then
    select rate into v_usdkrw
    from public.fx_rates_daily
    where user_id = p_user_id and trading_date < p_trading_date and pair='USDKRW'
    order by trading_date desc
    limit 1;

    if v_usdkrw is not null then
      v_used_source := p_source || ':FFILL_FX';
    end if;
  end if;

  if v_usdkrw is null and p_source <> 'REBUILD' then
    select rate into v_usdkrw
    from public.fx_rates
    where user_id = p_user_id and pair='USDKRW'
    limit 1;

    if v_usdkrw is not null then
      v_used_source := p_source || ':CURRENT_FX';
    end if;
  end if;

  if v_usdkrw is null then
    -- Do not write partial/incorrect data.
    insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
    values (p_user_id, p_trading_date, 'capture_card_usage_snapshot: missing USDKRW (daily+prev; current forbidden in REBUILD)')
    on conflict (user_id, trading_date) do update set reason = excluded.reason;
    return;
  end if;

  insert into public.card_usage_daily(
    user_id, trading_date, card_id,
    spend_krw, spend_count,
    market_data_asof, source
  )
  select
    p_user_id,
    p_trading_date,
    t.card_id,
    round(sum(
      case
        when t.currency = 'KRW' then t.amount
        when t.currency = 'USD' then t.amount * v_usdkrw
        else 0
      end
    ), 2) as spend_krw,
    count(*)::int as spend_count,
    p_market_data_asof,
    v_used_source
  from public.transactions t
  where t.user_id = p_user_id
    and t.card_id is not null
    and t.type = '지출'
    and t.is_correction = false
    and t.is_voided = false
    and (timezone('Asia/Seoul', t.date)::date) = p_trading_date
  group by t.card_id
  on conflict (user_id, trading_date, card_id)
  do update set
    spend_krw = excluded.spend_krw,
    spend_count = excluded.spend_count,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();
end;
$$;



-- 10) Rebuild snapshots for a date range (used when past edits happen later)
create or replace function public.rebuild_daily_snapshots(
  p_user_id uuid,
  p_from_date date,
  p_to_date date,
  p_source text default 'REBUILD'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  d date;
  v_asof timestamptz;
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_from_date is null or p_to_date is null then raise exception 'date range required'; end if;
  if p_from_date > p_to_date then raise exception 'p_from_date must be <= p_to_date'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    raise exception 'Service role required';
  end if;

  d := p_from_date;
  while d <= p_to_date loop
    -- v2.3: asof lookup (exact -> FFILL prev). Do not abort whole rebuild for one missing day.
    select market_data_asof into v_asof
    from public.fx_rates_daily
    where user_id = p_user_id and trading_date = d and pair='USDKRW'
    limit 1;

    if v_asof is null then
      select market_data_asof into v_asof
      from public.fx_rates_daily
      where user_id = p_user_id and trading_date < d and pair='USDKRW'
      order by trading_date desc
      limit 1;
    end if;

    if v_asof is null then
      insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
      values (p_user_id, d, 'rebuild_daily_snapshots: missing fx_rates_daily USDKRW (no prev to ffill)')
      on conflict (user_id, trading_date) do update set reason = excluded.reason;
      d := d + 1;
      continue;
    end if;

    begin
      perform public.capture_account_snapshots(p_user_id, d, v_asof, p_source);
      perform public.capture_nav_snapshot(p_user_id, d, v_asof, p_source);
      perform public.capture_card_usage_snapshot(p_user_id, d, v_asof, p_source);
    exception when others then
      insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
      values (p_user_id, d, 'rebuild_daily_snapshots: ' || sqlerrm)
      on conflict (user_id, trading_date) do update set reason = excluded.reason;
    end;

    d := d + 1;
  end loop;
end;
$$;





-- =========================================================
-- PAD v2.3.0 PATCH (2026-01-27)
-- - Moving Average Cost Basis (avg_buy_price) 유지 + 실현손익(Realized P&L) 기록
-- - reverse_transaction: 원거래 VOID 처리 (correction tx는 기술적 보정으로만 사용)
-- - 카드대금(account delta) 누락 버그 수정
-- - 일일 스냅샷(과거 재계산) 함수들이 service_role에서 historical range 지원 + daily prices/rates 사용
-- - Corporate Action(액면분할) 수동 적용 RPC 추가
-- =========================================================

-- 0) transactions: stock P&L columns (optional convenience)
alter table public.transactions
  add column if not exists stock_unit_price numeric(18,6) null,
  add column if not exists stock_avg_cost numeric(18,6) null,
  add column if not exists stock_realized_pnl numeric(18,6) null;

-- 1) Realized P&L log (moving average method)
create table if not exists public.stock_realized_pnl (
  pnl_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  transaction_id uuid not null references public.transactions(transaction_id) on delete cascade,
  stock_id uuid not null references public.stocks(stock_id) on delete cascade,

  qty numeric(18,6) not null,
  unit_price numeric(18,6) not null,        -- 매도 단가(= amount/qty)
  avg_cost numeric(18,6) not null,          -- 매도 시점 이동평균 평단
  realized_pnl numeric(18,6) not null,      -- (unit_price-avg_cost)*qty

  currency currency_code not null,
  realized_at timestamptz not null,

  created_at timestamptz not null default now(),
  constraint uq_stock_realized_pnl_tx unique (user_id, transaction_id)
);

create index if not exists idx_stock_realized_pnl_user_time
on public.stock_realized_pnl(user_id, realized_at desc);

alter table public.stock_realized_pnl enable row level security;

-- v2.3.0: void propagation for realized PnL
alter table public.stock_realized_pnl
  add column if not exists is_voided boolean not null default false;

create index if not exists idx_stock_realized_pnl_user_voided
on public.stock_realized_pnl(user_id, is_voided);

create or replace function public.sync_realized_pnl_void_status()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if TG_OP = 'UPDATE' and (new.is_voided is distinct from old.is_voided) then
    update public.stock_realized_pnl
    set is_voided = new.is_voided
    where user_id = new.user_id and transaction_id = new.transaction_id;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_sync_realized_pnl_void on public.transactions;
create trigger trg_sync_realized_pnl_void
after update of is_voided on public.transactions
for each row execute function public.sync_realized_pnl_void_status();



drop policy if exists "stock_realized_pnl_owner_read" on public.stock_realized_pnl;
drop policy if exists "stock_realized_pnl_service_write" on public.stock_realized_pnl;

create policy "stock_realized_pnl_owner_read"
on public.stock_realized_pnl for select
using (
  public.is_service_role()
  or (user_id = auth.uid() and is_voided = false)
);

create policy "stock_realized_pnl_service_write"
on public.stock_realized_pnl for insert
with check (public.is_service_role());

grant select on public.stock_realized_pnl to authenticated;

-- 2) Corporate Actions (manual) - Stock Split
create table if not exists public.stock_corporate_actions (
  action_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  stock_id uuid not null references public.stocks(stock_id) on delete cascade,

  action_type text not null, -- 'SPLIT'
  ratio_num integer not null,
  ratio_den integer not null,
  effective_date date not null,
  memo text null,

  transaction_id uuid null references public.transactions(transaction_id) on delete set null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint chk_split_ratio_pos check (ratio_num > 0 and ratio_den > 0)
);

create index if not exists idx_stock_corp_actions_user_date
on public.stock_corporate_actions(user_id, effective_date desc);

drop trigger if exists trg_stock_corp_actions_updated_at on public.stock_corporate_actions;
create trigger trg_stock_corp_actions_updated_at
before update on public.stock_corporate_actions
for each row execute function public.set_updated_at();

alter table public.stock_corporate_actions enable row level security;

drop policy if exists "stock_corp_actions_owner_all" on public.stock_corporate_actions;
drop policy if exists "stock_corp_actions_service_all" on public.stock_corporate_actions;

create policy "stock_corp_actions_owner_all"
on public.stock_corporate_actions for all
using (user_id = auth.uid() or public.is_service_role())
with check (user_id = auth.uid() or public.is_service_role());

create policy "stock_corp_actions_service_all"
on public.stock_corporate_actions for all
using (public.is_service_role())
with check (public.is_service_role());

grant select, insert, update, delete on public.stock_corporate_actions to authenticated;

-- 2B) RPC: apply_stock_split (manual corporate action)
create or replace function public.apply_stock_split(
  p_stock_id uuid,
  p_ratio_num integer,
  p_ratio_den integer,
  p_effective_date date,
  p_memo text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_action_id uuid;
  v_stock public.stocks%rowtype;
  v_h public.holdings%rowtype;
  v_new_qty numeric(18,6);
  v_new_avg numeric(18,6);
  v_tx_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;
  if p_stock_id is null then raise exception 'p_stock_id is required'; end if;
  if p_ratio_num is null or p_ratio_den is null then raise exception 'ratio required'; end if;
  if p_ratio_num <= 0 or p_ratio_den <= 0 then raise exception 'ratio must be > 0'; end if;
  if p_effective_date is null then raise exception 'p_effective_date is required'; end if;

  select * into v_stock
  from public.stocks
  where stock_id = p_stock_id and user_id = v_user_id;

  if not found then
    raise exception 'stock not found or not owned';
  end if;

  select * into v_h
  from public.holdings
  where user_id = v_user_id and stock_id = p_stock_id
  for update;

  if not found or coalesce(v_h.holdings_qty,0) <= 0 then
    raise exception 'no holdings to apply split';
  end if;

  v_new_qty := round(v_h.holdings_qty * (p_ratio_num::numeric / p_ratio_den::numeric), 6);

  if v_h.avg_buy_price is null then
    v_new_avg := null;
  else
    v_new_avg := round(v_h.avg_buy_price * (p_ratio_den::numeric / p_ratio_num::numeric), 6);
  end if;

  update public.holdings
  set holdings_qty = v_new_qty,
      avg_buy_price = v_new_avg,
      last_updated = now()
  where holding_id = v_h.holding_id;

  -- audit: insert 0-amount "교정" tx (no balance impact)
  insert into public.transactions(
    user_id, date, type, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id
  ) values (
    v_user_id,
    (p_effective_date::timestamp at time zone 'Asia/Seoul'),
    '교정',
    coalesce('[CORP_ACTION][SPLIT] '||p_ratio_num::text||':'||p_ratio_den::text||' '||p_memo, '[CORP_ACTION][SPLIT] '||p_ratio_num::text||':'||p_ratio_den::text),
    0,
    v_stock.currency,
    null, null, null, p_stock_id,
    null, null,
    null,
    true, null
  ) returning transaction_id into v_tx_id;

  insert into public.stock_corporate_actions(
    user_id, stock_id, action_type, ratio_num, ratio_den, effective_date, memo, transaction_id
  ) values (
    v_user_id, p_stock_id, 'SPLIT', p_ratio_num, p_ratio_den, p_effective_date, p_memo, v_tx_id
  ) returning action_id into v_action_id;

  -- enqueue daily snapshots rebuild from effective date
  perform public.enqueue_daily_snapshot_recalc(v_user_id, p_effective_date, 'CORP_ACTION_SPLIT');

  return v_action_id;
end;
$$;

grant execute on function public.apply_stock_split(uuid, integer, integer, date, text) to authenticated;

-- 3) PATCH: reverse_transaction void original
create or replace function public.reverse_transaction(
  p_transaction_id uuid,
  p_reason text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;

  v_reverse_type transaction_type;
  v_reverse_account_id uuid;
  v_reverse_to_account_id uuid;
  v_reverse_card_id uuid;
  v_reverse_memo text;

  v_new_tx_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  select * into v_org
  from public.transactions
  where transaction_id = p_transaction_id
    and user_id = v_user_id;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot reverse a correction transaction';
  end if;

  v_reverse_account_id := v_org.account_id;
  v_reverse_to_account_id := v_org.to_account_id;
  v_reverse_card_id := v_org.card_id;

  if v_org.type = '지출' then
    v_reverse_type := '수입';
  elsif v_org.type = '수입' then
    v_reverse_type := '지출';
  elsif v_org.type = '배당금' then
    v_reverse_type := '지출';
  elsif v_org.type in ('수수료','세금','대출_상환_이자') then
    v_reverse_type := '수입';
  elsif v_org.type = '대출_실행' then
    v_reverse_type := '대출_상환_원금';
  elsif v_org.type = '대출_상환_원금' then
    v_reverse_type := '대출_실행';
  elsif v_org.type = '주식_매수' then
    v_reverse_type := '주식_매도';
  elsif v_org.type = '주식_매도' then
    v_reverse_type := '주식_매수';
  elsif v_org.type = '환전_매수' then
    v_reverse_type := '환전_매도';
  elsif v_org.type = '환전_매도' then
    v_reverse_type := '환전_매수';
  elsif v_org.type = '카드_대금' then
    -- 카드 대금 취소는 "수입(통장)"으로 처리 (card_id 제거)
    v_reverse_type := '수입';
    v_reverse_card_id := null;
  elsif v_org.type = '이체' then
    v_reverse_type := '이체';
    v_reverse_account_id := v_org.to_account_id;
    v_reverse_to_account_id := v_org.account_id;
  else
    raise exception 'Unsupported reverse mapping for type=%', v_org.type;
  end if;

  v_reverse_memo :=
    coalesce('[REVERSAL] ' || p_reason, '[REVERSAL]') ||
    ' (orig=' || v_org.transaction_id::text || ')';

  v_new_tx_id := public.process_transaction_v2(
    v_org.date,
    v_reverse_type,
    v_org.amount,
    v_org.currency,
    v_reverse_account_id,
    v_reverse_to_account_id,
    v_reverse_card_id,
    v_org.stock_id,
    v_org.qty,
    v_org.fx_rate,
    v_org.liability_id,
    v_org.category,
    v_reverse_memo,
    true,
    v_org.transaction_id,
    v_org.category_id,
    v_org.merchant,
    null
  );

  -- Mark original as VOID (so analytics can safely exclude corrections)
  update public.transactions
  set is_voided = true,
      voided_at = now(),
      void_reason = p_reason,
      superseded_by = v_new_tx_id
  where transaction_id = p_transaction_id
    and user_id = v_user_id;

  return v_new_tx_id;
end;
$$;

-- 4) PATCH: process_transaction_v2 (avg cost + realized pnl + 카드대금 delta)
create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  -- v1.3.2: category FK + merchant
  p_category_id uuid default null,
  p_merchant text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;

  -- v1.3.2: category FK enforcement
  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_month_start timestamptz := (date_trunc('month', timezone('Asia/Seoul', now())) at time zone 'Asia/Seoul');
  v_month_end timestamptz := ((date_trunc('month', timezone('Asia/Seoul', now())) + interval '1 month') at time zone 'Asia/Seoul');

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;

  
  v_hold_qty numeric := null;
  v_hold_avg numeric := null;
  v_unit_price numeric := null;
  v_realized_pnl numeric := null;
  v_new_qty numeric := null;
  v_new_avg numeric := null;
v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;


  -- Resolve & validate category (FK)
  -- NOTE: DB constraint also enforces category_id for 지출/수입. This keeps error messages user-friendly.
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    -- Other types: category is optional; if category_id is provided, validate it.
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- [v1.3.1] Currency guard:
    -- Prevent KRW account -> USD account transfer without explicit FX transaction.
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  -- Payment method rules (account vs card)
  --  - Bank-based: account_id required, card_id must be null
  --  - Card-based: card_id required, account_id must be null (cash untouched)
  if p_type in ('지출','수입','수수료','세금') then
    if p_card_id is null and p_account_id is null then
      raise exception 'Either account_id or card_id is required for this transaction type';
    end if;

    if p_card_id is not null and p_account_id is not null then
      raise exception 'For card-based transactions, account_id must be NULL (type=%)', p_type;
    end if;
  end if;

  if p_type = '배당금' then
    if p_account_id is null then
      raise exception 'account_id is required for dividend';
    end if;
  end if;

  if p_type = '카드_대금' then
    if p_account_id is null or p_card_id is null then
      raise exception 'account_id and card_id are required for card payment';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id
  )
  returning transaction_id into v_tx_id;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','카드_대금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates (주식: qty + 이동평균 평단 + 실현손익)
if p_stock_id is not null and p_type in ('주식_매수','주식_매도') then
  if p_qty is null or p_qty <= 0 then
    raise exception 'qty must be > 0 for stock trade';
  end if;

  v_unit_price := round(p_amount / nullif(p_qty,0), 6);

  -- Lock holding row to avoid race
  select holdings_qty, avg_buy_price
    into v_hold_qty, v_hold_avg
  from public.holdings
  where user_id = v_user_id and stock_id = p_stock_id
  for update;

  v_hold_qty := coalesce(v_hold_qty, 0);
  v_hold_avg := coalesce(v_hold_avg, 0);

  if p_type = '주식_매수' then
    v_new_qty := round(v_hold_qty + p_qty, 6);
    if v_new_qty <= 0 then
      raise exception 'invalid new holdings qty';
    end if;

    v_new_avg := round(((v_hold_qty * v_hold_avg) + (p_qty * v_unit_price)) / v_new_qty, 6);
    v_realized_pnl := 0;

    insert into public.holdings(user_id, stock_id, holdings_qty, avg_buy_price, last_updated)
    values (v_user_id, p_stock_id, v_new_qty, v_new_avg, now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = excluded.holdings_qty,
      avg_buy_price = excluded.avg_buy_price,
      last_updated = now();

    update public.transactions
    set stock_unit_price = v_unit_price,
        stock_avg_cost = v_new_avg,
        stock_realized_pnl = 0
    where transaction_id = v_tx_id;

  else -- '주식_매도'
    if v_hold_qty < p_qty then
      raise exception 'Insufficient holdings (stock_id=%, have=%, sell=%)', p_stock_id, v_hold_qty, p_qty;
    end if;

    v_realized_pnl := round((v_unit_price - v_hold_avg) * p_qty, 6);
    v_new_qty := round(v_hold_qty - p_qty, 6);

    if v_new_qty = 0 then
      v_new_avg := null;
    else
      v_new_avg := v_hold_avg;
    end if;

    insert into public.holdings(user_id, stock_id, holdings_qty, avg_buy_price, last_updated)
    values (v_user_id, p_stock_id, v_new_qty, v_new_avg, now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = excluded.holdings_qty,
      avg_buy_price = excluded.avg_buy_price,
      last_updated = now();

    update public.transactions
    set stock_unit_price = v_unit_price,
        stock_avg_cost = v_hold_avg,
        stock_realized_pnl = v_realized_pnl
    where transaction_id = v_tx_id;

    insert into public.stock_realized_pnl(
      user_id, transaction_id, stock_id,
      qty, unit_price, avg_cost, realized_pnl,
      currency, realized_at
    ) values (
      v_user_id, v_tx_id, p_stock_id,
      p_qty, v_unit_price, v_hold_avg, v_realized_pnl,
      p_currency, p_date
    );
  end if;
end if;

-- Liabilities principal update
  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Monthly KPI accumulation (simple)
  if p_date >= v_month_start and p_date < v_month_end then
    if p_type in ('지출','수수료','세금','대출_상환_이자') then
      update public.stats
      set expense_this_month = expense_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type in ('수입','배당금') then
      update public.stats
      set income_this_month = income_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;

    if p_type = '대출_상환_이자' then
      update public.stats
      set interest_cost_this_month = interest_cost_this_month + p_amount,
          updated_at = now()
      where user_id = v_user_id;
    end if;
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);

  return v_tx_id;
end;
$$;

create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  p_category_id uuid default null,
  p_merchant text default null,

  p_client_tx_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;
  v_existing_tx_id uuid;

  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;

  
  v_hold_qty numeric := null;
  v_hold_avg numeric := null;
  v_unit_price numeric := null;
  v_realized_pnl numeric := null;
  v_new_qty numeric := null;
  v_new_avg numeric := null;
v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- Idempotency fast-path
  if p_client_tx_id is not null then
    select transaction_id into v_existing_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;

    if v_existing_tx_id is not null then
      return v_existing_tx_id;
    end if;
  end if;

  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;

  -- Resolve & validate category (FK)
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- Currency guard
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  -- 결제수단 규칙(카드/계좌)
  if p_type in ('지출','수입','수수료','세금') then
    if p_card_id is null and p_account_id is null then
      raise exception 'Either account_id or card_id is required for this transaction type';
    end if;

    if p_card_id is not null and p_account_id is not null then
      raise exception 'For card-based transactions, account_id must be NULL (type=%)', p_type;
    end if;
  end if;

  if p_type = '배당금' then
    if p_account_id is null then
      raise exception 'account_id is required for dividend';
    end if;
  end if;

  if p_type = '카드_대금' then
    if p_account_id is null or p_card_id is null then
      raise exception 'account_id and card_id are required for card payment';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert (race-safe idempotency)
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id,
    client_tx_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id,
    p_client_tx_id
  )
  on conflict (user_id, client_tx_id) where client_tx_id is not null
  do nothing
  returning transaction_id into v_tx_id;

  if v_tx_id is null and p_client_tx_id is not null then
    select transaction_id into v_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;

    if v_tx_id is not null then
      return v_tx_id;
    end if;

    raise exception 'Idempotency conflict: insert did nothing but existing row not found (client_tx_id=%)', p_client_tx_id;
  end if;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','카드_대금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates (주식: qty + 이동평균 평단 + 실현손익)
if p_stock_id is not null and p_type in ('주식_매수','주식_매도') then
  if p_qty is null or p_qty <= 0 then
    raise exception 'qty must be > 0 for stock trade';
  end if;

  v_unit_price := round(p_amount / nullif(p_qty,0), 6);

  -- Lock holding row to avoid race
  select holdings_qty, avg_buy_price
    into v_hold_qty, v_hold_avg
  from public.holdings
  where user_id = v_user_id and stock_id = p_stock_id
  for update;

  v_hold_qty := coalesce(v_hold_qty, 0);
  v_hold_avg := coalesce(v_hold_avg, 0);

  if p_type = '주식_매수' then
    v_new_qty := round(v_hold_qty + p_qty, 6);
    if v_new_qty <= 0 then
      raise exception 'invalid new holdings qty';
    end if;

    v_new_avg := round(((v_hold_qty * v_hold_avg) + (p_qty * v_unit_price)) / v_new_qty, 6);
    v_realized_pnl := 0;

    insert into public.holdings(user_id, stock_id, holdings_qty, avg_buy_price, last_updated)
    values (v_user_id, p_stock_id, v_new_qty, v_new_avg, now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = excluded.holdings_qty,
      avg_buy_price = excluded.avg_buy_price,
      last_updated = now();

    update public.transactions
    set stock_unit_price = v_unit_price,
        stock_avg_cost = v_new_avg,
        stock_realized_pnl = 0
    where transaction_id = v_tx_id;

  else -- '주식_매도'
    if v_hold_qty < p_qty then
      raise exception 'Insufficient holdings (stock_id=%, have=%, sell=%)', p_stock_id, v_hold_qty, p_qty;
    end if;

    v_realized_pnl := round((v_unit_price - v_hold_avg) * p_qty, 6);
    v_new_qty := round(v_hold_qty - p_qty, 6);

    if v_new_qty = 0 then
      v_new_avg := null;
    else
      v_new_avg := v_hold_avg;
    end if;

    insert into public.holdings(user_id, stock_id, holdings_qty, avg_buy_price, last_updated)
    values (v_user_id, p_stock_id, v_new_qty, v_new_avg, now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = excluded.holdings_qty,
      avg_buy_price = excluded.avg_buy_price,
      last_updated = now();

    update public.transactions
    set stock_unit_price = v_unit_price,
        stock_avg_cost = v_hold_avg,
        stock_realized_pnl = v_realized_pnl
    where transaction_id = v_tx_id;

    insert into public.stock_realized_pnl(
      user_id, transaction_id, stock_id,
      qty, unit_price, avg_cost, realized_pnl,
      currency, realized_at
    ) values (
      v_user_id, v_tx_id, p_stock_id,
      p_qty, v_unit_price, v_hold_avg, v_realized_pnl,
      p_currency, p_date
    );
  end if;
end if;

-- Liabilities principal update
  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);
  perform public.recalc_monthly_kpis(v_user_id);

  return v_tx_id;
end;
$$;

-- 5) PATCH: snapshot capture functions (historical rebuild enabled)
create or replace function public.capture_account_snapshots(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'CRON'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_usdkrw numeric(18,6);
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  -- v2.3: FX lookup policy (exact daily -> FFILL prev daily -> current (not rebuild) -> abort day)
  select rate into v_usdkrw
  from public.fx_rates_daily
  where user_id = p_user_id and trading_date = p_trading_date and pair='USDKRW'
  limit 1;

  if v_usdkrw is null then
    select rate into v_usdkrw
    from public.fx_rates_daily
    where user_id = p_user_id and trading_date < p_trading_date and pair='USDKRW'
    order by trading_date desc
    limit 1;
  end if;

  if v_usdkrw is null and p_source <> 'REBUILD' then
    select rate into v_usdkrw
    from public.fx_rates
    where user_id = p_user_id and pair='USDKRW'
    limit 1;
  end if;

  if v_usdkrw is null then
    insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
    values (p_user_id, p_trading_date, 'capture_account_snapshots: missing USDKRW (daily+prev; current forbidden in REBUILD)')
    on conflict (user_id, trading_date) do update set reason = excluded.reason;
    return;
  end if;

  -- A) Account x Stock valuation
  with pos as (
    select
      t.account_id,
      t.stock_id,
      sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
      end) as qty
    from public.transactions t
    where t.user_id = p_user_id
      and t.is_voided = false
      and t.is_correction = false
      and t.account_id is not null
      and t.stock_id is not null
      and t.qty is not null
      and t.type in ('주식_매수','주식_매도')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.account_id, t.stock_id
    having sum(case
        when t.type = '주식_매수' then t.qty
        when t.type = '주식_매도' then -t.qty
        else 0
    end) <> 0
  ),
  price_daily as (
    select spd.user_id, spd.stock_id, spd.price, spd.currency
    from public.stock_prices_daily spd
    where spd.user_id = p_user_id and spd.trading_date = p_trading_date
  ),
  price_prev as (
    select distinct on (spd.stock_id)
      spd.user_id, spd.stock_id, spd.price, spd.currency
    from public.stock_prices_daily spd
    where spd.user_id = p_user_id and spd.trading_date < p_trading_date
    order by spd.stock_id, spd.trading_date desc
  ),
  priced as (
    select
      p_user_id as user_id,
      p_trading_date as trading_date,
      pos.account_id,
      pos.stock_id,
      pos.qty,
      coalesce(pd.price, pp.price, (case when p_source <> 'REBUILD' then sp.price end)) as price,
      coalesce(pd.currency, pp.currency, (case when p_source <> 'REBUILD' then sp.currency end)) as price_currency,
      case when coalesce(pd.currency, pp.currency, (case when p_source <> 'REBUILD' then sp.currency end))='USD' then v_usdkrw else null end as fx_rate_used,
      round(
        case
          when coalesce(pd.currency, pp.currency, (case when p_source <> 'REBUILD' then sp.currency end))='KRW' then (pos.qty * coalesce(pd.price, pp.price, (case when p_source <> 'REBUILD' then sp.price end)))
          when coalesce(pd.currency, pp.currency, (case when p_source <> 'REBUILD' then sp.currency end))='USD' then (pos.qty * coalesce(pd.price, pp.price, (case when p_source <> 'REBUILD' then sp.price end)) * v_usdkrw)
          else 0
        end
      , 2) as value_krw
    from pos
    left join price_daily pd
      on pd.user_id = p_user_id and pd.stock_id = pos.stock_id
    left join price_prev pp
      on pp.user_id = p_user_id and pp.stock_id = pos.stock_id
    left join public.stock_prices sp
      on sp.user_id = p_user_id and sp.stock_id = pos.stock_id
    where coalesce(pd.price, pp.price, (case when p_source <> 'REBUILD' then sp.price end)) is not null
      and coalesce(pd.currency, pp.currency, (case when p_source <> 'REBUILD' then sp.currency end)) is not null
  )
  insert into public.account_stock_nav_daily(
    user_id, trading_date, account_id, stock_id,
    qty, price, price_currency, fx_rate_used, value_krw,
    market_data_asof, source
  )
  select
    user_id, trading_date, account_id, stock_id,
    qty, price, price_currency, fx_rate_used, value_krw,
    p_market_data_asof, p_source
  from priced
  on conflict (user_id, trading_date, account_id, stock_id)
  do update set
    qty = excluded.qty,
    price = excluded.price,
    price_currency = excluded.price_currency,
    fx_rate_used = excluded.fx_rate_used,
    value_krw = excluded.value_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();

  -- B) Account NAV (cash KRW + USD + stocks)
  with cash_krw as (
    select
      a.account_id,
      coalesce(sum(case
        when t.type in ('지출','수수료','세금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수','카드_대금')
          and t.account_id = a.account_id and t.currency='KRW' then -t.amount
        when t.type in ('수입','배당금','대출_실행','주식_매도','환전_매도')
          and t.account_id = a.account_id and t.currency='KRW' then +t.amount
        when t.type='이체' and t.account_id = a.account_id and t.currency='KRW' then -t.amount
        when t.type='이체' and t.to_account_id = a.account_id and t.currency='KRW' then +t.amount
        else 0 end), 0) as cash_krw
    from public.accounts a
    left join public.transactions t
      on t.user_id = p_user_id
     and t.is_voided = false
     and t.is_correction = false
     and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
     and (t.account_id = a.account_id or t.to_account_id = a.account_id)
    where a.user_id = p_user_id
    group by a.account_id
  ),
  usd_pos as (
    select
      t.account_id,
      sum(case
        when t.type='환전_매수' then t.qty
        when t.type='환전_매도' then -t.qty
        else 0
      end) as usd_qty
    from public.transactions t
    where t.user_id = p_user_id
      and t.is_voided = false
      and t.is_correction = false
      and t.account_id is not null
      and t.qty is not null
      and t.type in ('환전_매수','환전_매도')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.account_id
  ),
  stock_sum as (
    select
      account_id,
      round(coalesce(sum(value_krw),0),2) as stock_value_krw
    from public.account_stock_nav_daily
    where user_id = p_user_id and trading_date = p_trading_date
    group by account_id
  )
  insert into public.account_nav_daily(
    user_id, trading_date, account_id,
    cash_krw, usd_qty, usd_value_krw, stock_value_krw, total_krw,
    market_data_asof, source
  )
  select
    p_user_id,
    p_trading_date,
    a.account_id,
    round(coalesce(c.cash_krw,0),2) as cash_krw,
    coalesce(u.usd_qty,0) as usd_qty,
    round(coalesce(u.usd_qty,0) * v_usdkrw, 2) as usd_value_krw,
    coalesce(s.stock_value_krw,0) as stock_value_krw,
    round(coalesce(c.cash_krw,0) + (coalesce(u.usd_qty,0) * v_usdkrw) + coalesce(s.stock_value_krw,0), 2) as total_krw,
    p_market_data_asof,
    p_source
  from public.accounts a
  left join cash_krw c on c.account_id = a.account_id
  left join usd_pos u on u.account_id = a.account_id
  left join stock_sum s on s.account_id = a.account_id
  where a.user_id = p_user_id
  on conflict (user_id, trading_date, account_id)
  do update set
    cash_krw = excluded.cash_krw,
    usd_qty = excluded.usd_qty,
    usd_value_krw = excluded.usd_value_krw,
    stock_value_krw = excluded.stock_value_krw,
    total_krw = excluded.total_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();
end;
$$;



create or replace function public.capture_nav_snapshot(
  p_user_id uuid,
  p_trading_date date,
  p_market_data_asof timestamptz,
  p_source text default 'CRON'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_assets numeric(18,2);
  v_liability numeric(18,2);
  v_nav numeric(18,2);
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;
  if p_market_data_asof is null then raise exception 'p_market_data_asof is required'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Not allowed';
    end if;
  end if;

  select round(coalesce(sum(an.total_krw),0),2) into v_assets
  from public.account_nav_daily an
  join public.accounts a on a.account_id = an.account_id
  where an.user_id = p_user_id
    and an.trading_date = p_trading_date
    and a.is_include_in_networth = true;

  select round(coalesce(sum(principal_remaining),0),2) into v_liability
  from (
    select
      t.liability_id,
      sum(case
        when t.type='대출_실행' then t.amount
        when t.type='대출_상환_원금' then -t.amount
        else 0 end) as principal_remaining
    from public.transactions t
    where t.user_id = p_user_id
      and t.is_voided = false
      and t.is_correction = false
      and t.liability_id is not null
      and t.type in ('대출_실행','대출_상환_원금')
      and (timezone('Asia/Seoul', t.date)::date) <= p_trading_date
    group by t.liability_id
  ) x;

  v_nav := round(coalesce(v_assets,0) - coalesce(v_liability,0), 2);

  insert into public.portfolio_nav_daily(user_id, trading_date, nav_krw, market_data_asof, source)
  values (p_user_id, p_trading_date, v_nav, p_market_data_asof, p_source)
  on conflict (user_id, trading_date)
  do update set
    nav_krw = excluded.nav_krw,
    market_data_asof = excluded.market_data_asof,
    source = excluded.source,
    updated_at = now();
end;
$$;



-- =========================================================
-- PAD v2.3.0 FINAL (2026-01-28)
-- Full reset SQL based on v2.3.0 + hardening patches:
-- - Security definer auth binding (no horizontal escalation)
-- - Reverse flow fix (void before recalc) for monthly KPI correctness
-- - KIS token stored encrypted (Edge-only crypto) + non-blocking advisory lock
-- - Test-only RPCs removed
-- - Sensitive maintenance RPCs service_role only
-- - Constraint validation (full reset) + indexes
-- =========================================================


create or replace function public.process_transaction_v2(
  p_date timestamptz,
  p_type transaction_type,
  p_amount numeric,
  p_currency currency_code,

  p_account_id uuid default null,
  p_to_account_id uuid default null,

  p_card_id uuid default null,
  p_stock_id uuid default null,

  p_qty numeric default null,
  p_fx_rate numeric default null,

  p_liability_id uuid default null,

  p_category text default null,
  p_memo text default null,

  p_is_correction boolean default false,
  p_linked_transaction_id uuid default null,

  p_category_id uuid default null,
  p_merchant text default null,

  p_client_tx_id uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_tx_id uuid;
  v_existing_tx_id uuid;

  v_category_id uuid;
  v_category_name text;
  v_category_kind text;

  v_delta_account numeric := 0;
  v_delta_to_account numeric := 0;

  v_delta_qty numeric := 0;

  
  v_hold_qty numeric := null;
  v_hold_avg numeric := null;
  v_unit_price numeric := null;
  v_realized_pnl numeric := null;
  v_new_qty numeric := null;
  v_new_avg numeric := null;
v_avg_rate numeric := 0;
  v_current_rate numeric := null;
  v_wallet_foreign numeric := 0;
  v_wallet_invested numeric := 0;

  v_liability_delta numeric := 0;

  v_from_default_currency currency_code;
  v_to_default_currency currency_code;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- Idempotency fast-path
  if p_client_tx_id is not null then
    select transaction_id into v_existing_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;

    if v_existing_tx_id is not null then
      return v_existing_tx_id;
    end if;
  end if;

  if p_date is null then raise exception 'p_date is required'; end if;
  if p_type is null then raise exception 'p_type is required'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'p_amount must be >= 0'; end if;
  if p_currency is null then raise exception 'p_currency is required'; end if;

  -- Resolve & validate category (FK)
  if p_type in ('지출','수입') then
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;
    elsif p_category is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_name = p_category;
    else
      raise exception 'category is required for expense/income';
    end if;

    if v_category_id is null then
      raise exception 'Unknown category (name=% id=%)', p_category, p_category_id;
    end if;

    if p_type = '지출' and v_category_kind = '수입' then
      raise exception 'Category kind mismatch: expense cannot use income category (category=%)', v_category_name;
    elsif p_type = '수입' and v_category_kind = '지출' then
      raise exception 'Category kind mismatch: income cannot use expense category (category=%)', v_category_name;
    end if;
  else
    if p_category_id is not null then
      select category_id, category_name, category_kind
        into v_category_id, v_category_name, v_category_kind
      from public.categories
      where user_id = v_user_id and category_id = p_category_id;

      if v_category_id is null then
        raise exception 'Unknown category_id=%', p_category_id;
      end if;
    else
      v_category_id := null;
      v_category_name := p_category;
      v_category_kind := null;
    end if;
  end if;

  -- Required validation per type
  if p_type = '이체' then
    if p_account_id is null or p_to_account_id is null then
      raise exception 'account_id and to_account_id are required for transfer';
    end if;
    if p_account_id = p_to_account_id then
      raise exception 'from/to accounts must be different';
    end if;

    -- Currency guard
    select default_currency into v_from_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_account_id;

    if v_from_default_currency is null then
      raise exception 'From-account not found or not owned (account_id=%)', p_account_id;
    end if;

    select default_currency into v_to_default_currency
    from public.accounts
    where user_id = v_user_id and account_id = p_to_account_id;

    if v_to_default_currency is null then
      raise exception 'To-account not found or not owned (account_id=%)', p_to_account_id;
    end if;

    if v_from_default_currency <> p_currency or v_to_default_currency <> p_currency then
      raise exception 'Transfer currency mismatch. Use FX transaction instead. from=% to=% currency=%',
        v_from_default_currency, v_to_default_currency, p_currency;
    end if;
  end if;

  -- 결제수단 규칙(카드/계좌)
  if p_type in ('지출','수입','수수료','세금') then
    if p_card_id is null and p_account_id is null then
      raise exception 'Either account_id or card_id is required for this transaction type';
    end if;

    if p_card_id is not null and p_account_id is not null then
      raise exception 'For card-based transactions, account_id must be NULL (type=%)', p_type;
    end if;
  end if;

  if p_type = '배당금' then
    if p_account_id is null then
      raise exception 'account_id is required for dividend';
    end if;
  end if;

  if p_type = '카드_대금' then
    if p_account_id is null or p_card_id is null then
      raise exception 'account_id and card_id are required for card payment';
    end if;
  end if;

  if p_type in ('주식_매수','주식_매도') then
    if p_account_id is null then raise exception 'account_id is required for stock trades'; end if;
    if p_stock_id is null then raise exception 'stock_id is required for stock trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for stock trades'; end if;
  end if;

  if p_type in ('환전_매수','환전_매도') then
    if p_account_id is null then raise exception 'account_id is required for FX trades'; end if;
    if p_qty is null or p_qty <= 0 then raise exception 'qty must be > 0 for FX trades (USD qty)'; end if;
    if p_fx_rate is null or p_fx_rate <= 0 then raise exception 'fx_rate must be > 0 for FX trades'; end if;
  end if;

  if p_type in ('대출_실행','대출_상환_원금','대출_상환_이자') then
    if p_account_id is null then raise exception 'account_id is required for loan transactions'; end if;
    if p_liability_id is null then raise exception 'liability_id is required for loan transactions'; end if;
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_user_id::text, 911911));

  perform public.ensure_stats_row(v_user_id);

  -- Ledger insert (race-safe idempotency)
  insert into public.transactions (
    user_id, date, type, category_id, category, merchant, memo,
    amount, currency,
    account_id, to_account_id, card_id, stock_id,
    qty, fx_rate,
    liability_id,
    is_correction, linked_transaction_id,
    client_tx_id
  ) values (
    v_user_id, p_date, p_type, v_category_id, v_category_name, p_merchant, p_memo,
    p_amount, p_currency,
    p_account_id, p_to_account_id, p_card_id, p_stock_id,
    p_qty, p_fx_rate,
    p_liability_id,
    p_is_correction, p_linked_transaction_id,
    p_client_tx_id
  )
  on conflict (user_id, client_tx_id) where client_tx_id is not null
  do nothing
  returning transaction_id into v_tx_id;

  if v_tx_id is null and p_client_tx_id is not null then
    select transaction_id into v_tx_id
    from public.transactions
    where user_id = v_user_id and client_tx_id = p_client_tx_id
    limit 1;

    if v_tx_id is not null then
      return v_tx_id;
    end if;

    raise exception 'Idempotency conflict: insert did nothing but existing row not found (client_tx_id=%)', p_client_tx_id;
  end if;

  -- Account balance delta rules
  if p_type in ('지출','수수료','세금','카드_대금','대출_상환_원금','대출_상환_이자','주식_매수','환전_매수') then
    v_delta_account := -p_amount;
  elsif p_type in ('수입','배당금','대출_실행','주식_매도','환전_매도') then
    v_delta_account := +p_amount;
  elsif p_type = '이체' then
    v_delta_account := -p_amount;
    v_delta_to_account := +p_amount;
  end if;

  -- Apply from-account balance
  if p_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_account
    where user_id = v_user_id and account_id = p_account_id and currency = p_currency;

    if exists (
      select 1 from public.account_balances
      where user_id = v_user_id and account_id = p_account_id and currency = p_currency and balance < 0
    ) then
      raise exception 'Account balance cannot be negative (account_id=%)', p_account_id;
    end if;
  end if;

  -- Apply to-account for transfers
  if p_type = '이체' and p_to_account_id is not null then
    perform public.ensure_account_balance_row(v_user_id, p_to_account_id, p_currency);

    update public.account_balances
    set balance = balance + v_delta_to_account
    where user_id = v_user_id and account_id = p_to_account_id and currency = p_currency;
  end if;

  -- Holdings updates (주식: qty + 이동평균 평단 + 실현손익)
if p_stock_id is not null and p_type in ('주식_매수','주식_매도') then
  if p_qty is null or p_qty <= 0 then
    raise exception 'qty must be > 0 for stock trade';
  end if;

  v_unit_price := round(p_amount / nullif(p_qty,0), 6);

  -- Lock holding row to avoid race
  select holdings_qty, avg_buy_price
    into v_hold_qty, v_hold_avg
  from public.holdings
  where user_id = v_user_id and stock_id = p_stock_id
  for update;

  v_hold_qty := coalesce(v_hold_qty, 0);
  v_hold_avg := coalesce(v_hold_avg, 0);

  if p_type = '주식_매수' then
    v_new_qty := round(v_hold_qty + p_qty, 6);
    if v_new_qty <= 0 then
      raise exception 'invalid new holdings qty';
    end if;

    v_new_avg := round(((v_hold_qty * v_hold_avg) + (p_qty * v_unit_price)) / v_new_qty, 6);
    v_realized_pnl := 0;

    insert into public.holdings(user_id, stock_id, holdings_qty, avg_buy_price, last_updated)
    values (v_user_id, p_stock_id, v_new_qty, v_new_avg, now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = excluded.holdings_qty,
      avg_buy_price = excluded.avg_buy_price,
      last_updated = now();

    update public.transactions
    set stock_unit_price = v_unit_price,
        stock_avg_cost = v_new_avg,
        stock_realized_pnl = 0
    where transaction_id = v_tx_id;

  else -- '주식_매도'
    if v_hold_qty < p_qty then
      raise exception 'Insufficient holdings (stock_id=%, have=%, sell=%)', p_stock_id, v_hold_qty, p_qty;
    end if;

    v_realized_pnl := round((v_unit_price - v_hold_avg) * p_qty, 6);
    v_new_qty := round(v_hold_qty - p_qty, 6);

    if v_new_qty = 0 then
      v_new_avg := null;
    else
      v_new_avg := v_hold_avg;
    end if;

    insert into public.holdings(user_id, stock_id, holdings_qty, avg_buy_price, last_updated)
    values (v_user_id, p_stock_id, v_new_qty, v_new_avg, now())
    on conflict (user_id, stock_id)
    do update set
      holdings_qty = excluded.holdings_qty,
      avg_buy_price = excluded.avg_buy_price,
      last_updated = now();

    update public.transactions
    set stock_unit_price = v_unit_price,
        stock_avg_cost = v_hold_avg,
        stock_realized_pnl = v_realized_pnl
    where transaction_id = v_tx_id;

    insert into public.stock_realized_pnl(
      user_id, transaction_id, stock_id,
      qty, unit_price, avg_cost, realized_pnl,
      currency, realized_at
    ) values (
      v_user_id, v_tx_id, p_stock_id,
      p_qty, v_unit_price, v_hold_avg, v_realized_pnl,
      p_currency, p_date
    );
  end if;
end if;

-- Liabilities principal update
  if p_type = '대출_실행' then
    v_liability_delta := p_amount;
  elsif p_type = '대출_상환_원금' then
    v_liability_delta := -p_amount;
  else
    v_liability_delta := 0;
  end if;

  if v_liability_delta <> 0 then
    update public.liabilities
    set principal_remaining = principal_remaining + v_liability_delta,
        last_updated = now()
    where user_id = v_user_id and liability_id = p_liability_id;

    if not found then
      raise exception 'Liability not found or not owned (liability_id=%)', p_liability_id;
    end if;

    if exists (
      select 1 from public.liabilities
      where user_id = v_user_id and liability_id = p_liability_id and principal_remaining < 0
    ) then
      raise exception 'Liability principal cannot be negative (liability_id=%)', p_liability_id;
    end if;
  end if;

  -- Currency wallet updates (USD only)
  if p_type in ('환전_매수','환전_매도') then
    insert into public.currency_wallet(user_id, currency, total_foreign_held, total_krw_invested, last_updated)
    values (v_user_id, 'USD', 0, 0, now())
    on conflict (user_id, currency) do nothing;

    select total_foreign_held, total_krw_invested
      into v_wallet_foreign, v_wallet_invested
    from public.currency_wallet
    where user_id = v_user_id and currency = 'USD';

    if v_wallet_foreign > 0 then
      v_avg_rate := v_wallet_invested / v_wallet_foreign;
    else
      v_avg_rate := 0;
    end if;

    if p_type = '환전_매수' then
      v_wallet_foreign := v_wallet_foreign + p_qty;
      v_wallet_invested := v_wallet_invested + p_amount;
    else
      v_wallet_foreign := v_wallet_foreign - p_qty;
      v_wallet_invested := v_wallet_invested - (v_avg_rate * p_qty);
    end if;

    if v_wallet_foreign < 0 then
      raise exception 'USD wallet cannot be negative';
    end if;

    select rate into v_current_rate
    from public.fx_rates
    where user_id = v_user_id and pair = 'USDKRW'
    limit 1;

    update public.currency_wallet
    set
      total_foreign_held = v_wallet_foreign,
      total_krw_invested = greatest(v_wallet_invested, 0),
      avg_rate = case when v_wallet_foreign > 0 then (greatest(v_wallet_invested,0) / v_wallet_foreign) else 0 end,
      current_rate = v_current_rate,
      est_value_krw = case when v_current_rate is not null then (v_wallet_foreign * v_current_rate) else null end,
      profit_krw = case
        when v_current_rate is not null then (v_wallet_foreign * v_current_rate) - greatest(v_wallet_invested,0)
        else null
      end,
      last_updated = now()
    where user_id = v_user_id and currency = 'USD';
  end if;

  -- Final recalculation
  perform public.refresh_stats(v_user_id);
  perform public.recalc_monthly_kpis(v_user_id);

  return v_tx_id;
end;
$$;
create or replace function public.reverse_transaction(
  p_transaction_id uuid,
  p_reason text default 'USER'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;
  v_reverse_type transaction_type;
  v_reverse_account_id uuid;
  v_reverse_to_account_id uuid;
  v_reverse_memo text;
  v_new_tx_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- Serialize per-user mutation
  perform pg_advisory_xact_lock(hashtextextended(v_user_id::text, 911911));

  select * into v_org
  from public.transactions
  where transaction_id = p_transaction_id
    and user_id = v_user_id
  for update;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot reverse a correction transaction';
  end if;

  if v_org.is_voided = true then
    raise exception 'Already voided (transaction_id=%)', p_transaction_id;
  end if;

  -- Map reverse type + account routing
  if v_org.type in ('지출','수수료','세금') then
    v_reverse_type := '수입';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type in ('수입','배당금') then
    v_reverse_type := '지출';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '카드_대금' then
    v_reverse_type := '수입';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '계좌_이체' then
    v_reverse_type := '계좌_이체';
    v_reverse_account_id := v_org.to_account_id;
    v_reverse_to_account_id := v_org.account_id;
  elsif v_org.type = '주식_매수' then
    v_reverse_type := '주식_매도';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '주식_매도' then
    v_reverse_type := '주식_매수';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '대출_실행' then
    v_reverse_type := '대출_상환_원금';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type in ('대출_상환_원금','대출_상환_이자') then
    v_reverse_type := '대출_실행';
    v_reverse_account_id := v_org.account_id;
  else
    raise exception 'Unsupported reverse mapping for type=%', v_org.type;
  end if;

  v_reverse_memo :=
    coalesce('[REVERSAL] ' || p_reason, '[REVERSAL]') ||
    ' (orig=' || v_org.transaction_id::text || ')';

  -- IMPORTANT:
  -- Void original FIRST so KPI recalculation inside process_transaction_v2 excludes it.
  update public.transactions
  set is_voided = true,
      voided_at = now(),
      void_reason = p_reason,
      updated_at = now()
  where transaction_id = v_org.transaction_id
    and user_id = v_user_id;

  -- Create opposite entry (correction) via main RPC (will refresh_stats + recalc_monthly_kpis)
  v_new_tx_id := public.process_transaction_v2(
    v_org.date,
    v_reverse_type,
    v_org.amount,
    v_org.currency,
    v_reverse_account_id,
    v_reverse_to_account_id,
    v_org.card_id,
    v_org.stock_id,
    v_org.qty,
    v_org.fx_rate,
    v_org.liability_id,
    v_org.category,
    v_reverse_memo,
    true,                          -- is_correction
    v_org.transaction_id,          -- linked_transaction_id
    v_org.category_id,
    v_org.merchant,
    gen_random_uuid()              -- client_tx_id (server-side for reversals)
  );

  -- Link original -> correction for audit
  update public.transactions
  set superseded_by = v_new_tx_id,
      updated_at = now()
  where transaction_id = v_org.transaction_id
    and user_id = v_user_id;

  return v_new_tx_id;
end;
$$;

create or replace function public.ensure_stats_row(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_user_id is null then
    raise exception 'p_user_id is required';
  end if;

  -- Prevent horizontal privilege escalation for authenticated callers.
  if auth.uid() is not null and auth.uid() <> p_user_id then
    raise exception 'Forbidden (p_user_id must equal auth.uid())';
  end if;

  insert into public.stats(user_id)
  values (p_user_id)
  on conflict (user_id) do nothing;
end;
$$;

create or replace function public.ensure_account_balance_row(p_user_id uuid, p_account_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  if p_user_id is null or p_account_id is null then
    raise exception 'p_user_id and p_account_id are required';
  end if;

  if auth.uid() is not null and auth.uid() <> p_user_id then
    raise exception 'Forbidden (p_user_id must equal auth.uid())';
  end if;

  insert into public.account_balances(user_id, account_id, balance, currency)
  select p_user_id, a.account_id, 0, a.currency
  from public.accounts a
  where a.account_id = p_account_id and a.user_id = p_user_id
  on conflict (user_id, account_id) do update set updated_at = now()
  returning balance_id into v_id;

  return v_id;
end;
$$;

create or replace function public.refresh_stats(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_usdkrw numeric(18,6);
  v_krw_cash numeric(18,2);
  v_usd_cash numeric(18,6);
  v_stock_value_krw numeric(18,2);
  v_liability_krw numeric(18,2);
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;

  if auth.uid() is not null and auth.uid() <> p_user_id then
    raise exception 'Forbidden (p_user_id must equal auth.uid())';
  end if;

  perform public.ensure_stats_row(p_user_id);

  -- USDKRW (prefer latest fx_rates; daily_close uses fx_rates_daily separately)
  select rate into v_usdkrw
  from public.fx_rates
  where user_id = p_user_id and pair='USDKRW'
  order by updated_at desc
  limit 1;

  v_usdkrw := coalesce(v_usdkrw, 0);

  -- Cash totals (account_balances)
  select coalesce(sum(case when a.currency='KRW' then ab.balance else 0 end),0),
         coalesce(sum(case when a.currency='USD' then ab.balance else 0 end),0)
  into v_krw_cash, v_usd_cash
  from public.account_balances ab
  join public.accounts a on a.account_id = ab.account_id
  where ab.user_id=p_user_id and a.user_id=p_user_id and a.is_include_in_stats = true;

  -- Stock value in KRW (holdings * stock_prices; if USD stock, converted)
  select coalesce(sum(
      case
        when s.currency='KRW' then h.holdings_qty * sp.price
        when s.currency='USD' then h.holdings_qty * sp.price * v_usdkrw
        else 0
      end
  ),0)
  into v_stock_value_krw
  from public.holdings h
  join public.stocks s on s.stock_id = h.stock_id
  left join public.stock_prices sp on sp.user_id=h.user_id and sp.stock_id=h.stock_id
  where h.user_id=p_user_id;

  -- Liabilities
  select coalesce(sum(current_amount_krw),0)
  into v_liability_krw
  from public.liabilities
  where user_id=p_user_id and is_active=true;

  update public.stats
  set
    krw_cash_total = round(v_krw_cash,2),
    usd_cash_total = round(v_usd_cash,6),
    usd_value_krw = round(v_usd_cash * v_usdkrw,2),
    stock_value_krw = round(v_stock_value_krw,2),
    total_liability_krw = round(v_liability_krw,2),
    total_networth_krw = round((v_krw_cash + (v_usd_cash * v_usdkrw) + v_stock_value_krw) - v_liability_krw,2),
    updated_at = now()
  where user_id = p_user_id;
end;
$$;

create or replace function public.recalc_monthly_kpis(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_month_start timestamptz;
  v_month_end timestamptz;
  v_expense numeric(18,2);
  v_income numeric(18,2);
  v_interest numeric(18,2);
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;

  if auth.uid() is not null and auth.uid() <> p_user_id then
    raise exception 'Forbidden (p_user_id must equal auth.uid())';
  end if;

  perform public.ensure_stats_row(p_user_id);

  -- KST 달력월 경계 (UTC now() 기반 오해 방지)
  v_month_start := (date_trunc('month', timezone('Asia/Seoul', now())) at time zone 'Asia/Seoul');
  v_month_end := ((date_trunc('month', timezone('Asia/Seoul', now())) + interval '1 month') at time zone 'Asia/Seoul');

  select
    coalesce(sum(case when t.type in ('지출','수수료','세금','대출_상환_이자') then t.amount else 0 end), 0),
    coalesce(sum(case when t.type in ('수입','배당금') then t.amount else 0 end), 0),
    coalesce(sum(case when t.type = '대출_상환_이자' then t.amount else 0 end), 0)
  into v_expense, v_income, v_interest
  from public.transactions t
  where t.user_id = p_user_id
    and t.is_voided = false
    and t.is_correction = false
    and t.date >= v_month_start
    and t.date < v_month_end;

  update public.stats
  set
    expense_this_month = v_expense,
    income_this_month = v_income,
    interest_cost_this_month = v_interest,
    updated_at = now()
  where user_id = p_user_id;
end;
$$;

create or replace function public.enqueue_daily_snapshot_recalc(
  p_user_id uuid,
  p_trading_date date,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_user_id is null or p_trading_date is null then
    raise exception 'p_user_id and p_trading_date are required';
  end if;

  if auth.uid() is not null and auth.uid() <> p_user_id then
    raise exception 'Forbidden (p_user_id must equal auth.uid())';
  end if;

  insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
  values (p_user_id, p_trading_date, p_reason)
  on conflict (user_id, trading_date) do update
    set reason = excluded.reason, created_at = now();
end;
$$;

create or replace function public.sync_realized_pnl_void_on_correction()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if TG_OP = 'INSERT' and new.is_correction = true and new.linked_transaction_id is not null then
    update public.stock_realized_pnl
    set is_voided = true
    where user_id = new.user_id and transaction_id = new.linked_transaction_id;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_sync_realized_pnl_void_on_correction on public.transactions;
create trigger trg_sync_realized_pnl_void_on_correction
after insert on public.transactions
for each row execute function public.sync_realized_pnl_void_on_correction();

-- v2.3.0: KIS token cache stores encrypted token only (Edge encrypts/decrypts).
alter table public.kis_token_cache
  add column if not exists access_token_enc text null;

comment on column public.kis_token_cache.access_token_enc is
  'Encrypted KIS access token (ciphertext, base64). Encrypt/Decrypt in Edge Function using KIS_TOKEN_CRYPTO_KEY.';

-- v2.3.0: IMPORTANT
-- This script contains legacy KIS token RPC definitions earlier (v2.3.0) and redefines them later (v2.3.0 encryption).
-- Postgres cannot rename input parameter names via CREATE OR REPLACE.
-- Therefore, we DROP the legacy token RPCs RIGHT BEFORE the v2.3.0 definitions.
drop function if exists public.kis_token_decide(text);
drop function if exists public.kis_token_finish_refresh(text, text, timestamptz);
drop function if exists public.kis_token_fail_refresh(text, text);

create or replace function public.kis_token_decide(p_owner text default 'edge')
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_row public.kis_token_cache%rowtype;
  v_wait int := 3;
  v_locked boolean;
begin
  if not public.is_service_role() then
    raise exception 'Service role required';
  end if;

  insert into public.kis_token_cache(id) values (1)
  on conflict (id) do nothing;

  -- Non-blocking lock: avoid DB pool exhaustion under burst.
  v_locked := pg_try_advisory_lock(73001331);
  if not v_locked then
    return jsonb_build_object('action','WAIT','wait_seconds',1,'detail','LOCK_BUSY');
  end if;

  select * into v_row from public.kis_token_cache where id=1 for update;

  -- 1) valid cache
  if v_row.access_token_enc is not null and v_row.expires_at is not null and v_row.expires_at > v_now then
    perform pg_advisory_unlock(73001331);
    return jsonb_build_object(
      'action','USE_CACHE',
      'access_token_enc', v_row.access_token_enc,
      'expires_at', v_row.expires_at
    );
  end if;

  -- 2) someone refreshing (short deadline)
  if v_row.refresh_deadline is not null and v_row.refresh_deadline > v_now then
    v_wait := greatest(1, least(10, extract(epoch from (v_row.refresh_deadline - v_now))::int));
    perform pg_advisory_unlock(73001331);
    return jsonb_build_object('action','WAIT','wait_seconds',v_wait,'detail','OTHER_REFRESHING','owner',v_row.refresh_owner);
  end if;

  -- 3) 1-minute throttle
  if v_row.last_attempt_at is not null and v_row.last_attempt_at > (v_now - interval '1 minute') then
    v_wait := greatest(1, extract(epoch from ((v_row.last_attempt_at + interval '1 minute') - v_now))::int);
    perform pg_advisory_unlock(73001331);
    return jsonb_build_object('action','WAIT','wait_seconds',v_wait,'detail','THROTTLED');
  end if;

  -- 4) allow refresh
  update public.kis_token_cache
  set
    last_attempt_at = v_now,
    refresh_deadline = v_now + interval '20 seconds',
    refresh_owner = p_owner,
    updated_at = v_now
  where id=1;

  perform pg_advisory_unlock(73001331);
  return jsonb_build_object('action','REFRESH_ALLOWED','detail','OK');
exception when others then
  -- best-effort unlock
  begin perform pg_advisory_unlock(73001331); exception when others then null; end;
  raise;
end;
$$;

create or replace function public.kis_token_finish_refresh(
  p_owner text,
  p_access_token_enc text,
  p_expires_at timestamptz
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_locked boolean;
begin
  if not public.is_service_role() then
    raise exception 'Service role required';
  end if;

  if p_access_token_enc is null or length(p_access_token_enc) < 8 then
    raise exception 'Encrypted token is required';
  end if;

  v_locked := pg_try_advisory_lock(73001331);
  if not v_locked then
    -- do not block; caller can retry
    raise exception 'LOCK_BUSY';
  end if;

  update public.kis_token_cache
  set
    access_token = null, -- legacy column unused in v2.3.0+
    access_token_enc = p_access_token_enc,
    expires_at = p_expires_at,
    last_issued_at = v_now,
    refresh_deadline = null,
    refresh_owner = null,
    updated_at = v_now
  where id = 1;

  perform pg_advisory_unlock(73001331);
end;
$$;

create or replace function public.kis_token_fail_refresh(
  p_owner text,
  p_error text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_locked boolean;
begin
  if not public.is_service_role() then
    raise exception 'Service role required';
  end if;

  v_locked := pg_try_advisory_lock(73001331);
  if not v_locked then
    -- best effort only
    return;
  end if;

  update public.kis_token_cache
  set
    refresh_deadline = null,
    refresh_owner = null,
    updated_at = v_now
  where id=1;

  perform pg_advisory_unlock(73001331);
end;
$$;

-- Restrict token RPC to service_role only
revoke execute on function public.kis_token_decide(text) from authenticated;
revoke execute on function public.kis_token_finish_refresh(text, text, timestamptz) from authenticated;
revoke execute on function public.kis_token_fail_refresh(text, text) from authenticated;

grant execute on function public.kis_token_decide(text) to service_role;
grant execute on function public.kis_token_finish_refresh(text, text, timestamptz) to service_role;
grant execute on function public.kis_token_fail_refresh(text, text) to service_role;

-- v2.3.0: sensitive maintenance RPCs are service_role only
revoke execute on function public.capture_account_snapshots(uuid, date, timestamptz, text) from authenticated;
revoke execute on function public.capture_nav_snapshot(uuid, date, timestamptz, text) from authenticated;
revoke execute on function public.rebuild_daily_snapshots(uuid, date, date, text) from authenticated;
revoke execute on function public.persist_market_data_daily(uuid, date, timestamptz, text) from authenticated;
revoke execute on function public.rebuild_monthly_returns(uuid, int) from authenticated;
revoke execute on function public.update_portfolio_metrics(uuid, date, int) from authenticated;

grant execute on function public.capture_account_snapshots(uuid, date, timestamptz, text) to service_role;
grant execute on function public.capture_nav_snapshot(uuid, date, timestamptz, text) to service_role;
grant execute on function public.rebuild_daily_snapshots(uuid, date, date, text) to service_role;
grant execute on function public.persist_market_data_daily(uuid, date, timestamptz, text) to service_role;
grant execute on function public.rebuild_monthly_returns(uuid, int) to service_role;
grant execute on function public.update_portfolio_metrics(uuid, date, int) to service_role;

-- v2.3.0: Drop test-only RPCs (MUST NOT exist in production)
drop function if exists public.seed_test_data(uuid);
drop function if exists public.cleanup_test_data(uuid);
drop function if exists public.run_edge_tests(uuid);
drop function if exists public.run_full_edge_tests_kis(uuid);

-- v2.3.0: Validate constraints (FULL RESET only; on upgrade ensure data is clean first)
alter table public.stocks validate constraint chk_stocks_us_kis_required;
alter table public.transactions validate constraint chk_transactions_card_based_no_account;
alter table public.transactions validate constraint chk_transactions_card_payment_requires_both;
alter table public.transactions validate constraint chk_transactions_payment_source_required;

-- v2.3.0: KPI scan acceleration
create index if not exists idx_transactions_user_date_active
  on public.transactions(user_id, date desc)
  where is_voided = false and is_correction = false;

-- v2.3.0: Prevent physical deletes on core masters (use logical methods)
revoke delete on public.accounts from authenticated;
revoke delete on public.cards from authenticated;
revoke delete on public.stocks from authenticated;
revoke delete on public.liabilities from authenticated;


-- =========================================================
-- PAD v2.3.2 PATCH: Rebuild Queue Worker + Queue Hygiene + Safe Manual Request
-- Date: 2026-01-29 (KST)
--
-- Why:
-- 1) daily_snapshot_recalc_queue was being enqueued on *all* tx changes (incl. today),
--    but nothing cleared it on successful rebuild => Integrity UI becomes noisy.
-- 2) enqueue_daily_snapshot_recalc() was SECURITY DEFINER and accepted arbitrary user_id
--    => harden to prevent cross-user enqueue by authenticated callers.
-- 3) Add safe RPC for manual "recalc request" (queues only, no service-role execution).
-- 4) Add rebuild success cleanup: rebuild_daily_snapshots deletes queue entries for dates
--    that were successfully rebuilt.
-- 5) (Optional) Add snapshot_recalc_runs log table for visibility in the app.
-- =========================================================

begin;

-- ---------------------------------------------------------
-- 1) Harden enqueue_daily_snapshot_recalc (prevent cross-user enqueue)
-- ---------------------------------------------------------
create or replace function public.enqueue_daily_snapshot_recalc(
  p_user_id uuid,
  p_trading_date date,
  p_reason text default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  v_uid uuid := auth.uid();
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_trading_date is null then raise exception 'p_trading_date is required'; end if;

  v_role_ok := public.is_service_role();

  -- If not service-role, require authenticated user and self-only
  if not v_role_ok then
    if v_uid is null then
      raise exception 'Not authenticated';
    end if;
    if v_uid <> p_user_id then
      raise exception 'Not allowed (cross-user enqueue blocked)';
    end if;
  end if;

  insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
  values (p_user_id, p_trading_date, p_reason)
  on conflict (user_id, trading_date)
  do update set
    reason = coalesce(excluded.reason, public.daily_snapshot_recalc_queue.reason),
    created_at = public.daily_snapshot_recalc_queue.created_at;
end;
$$;

-- ---------------------------------------------------------
-- 2) Trigger: enqueue only for *past* dates (KST) to avoid noise
-- ---------------------------------------------------------
create or replace function public.trg_enqueue_snapshot_recalc()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid;
  v_new_date date;
  v_old_date date;
  v_today_kst date := timezone('Asia/Seoul', now())::date;
begin
  v_user := coalesce(NEW.user_id, OLD.user_id);
  v_new_date := case when NEW.date is null then null else timezone('Asia/Seoul', NEW.date)::date end;
  v_old_date := case when OLD.date is null then null else timezone('Asia/Seoul', OLD.date)::date end;

  if v_user is null then
    return coalesce(NEW, OLD);
  end if;

  -- Only past dates need rebuild (today/future are not "fixed snapshots")
  if v_old_date is not null and v_old_date < v_today_kst then
    perform public.enqueue_daily_snapshot_recalc(v_user, v_old_date, TG_OP);
  end if;

  if v_new_date is not null
     and v_new_date is distinct from v_old_date
     and v_new_date < v_today_kst then
    perform public.enqueue_daily_snapshot_recalc(v_user, v_new_date, TG_OP);
  end if;

  return coalesce(NEW, OLD);
end;
$$;

-- Trigger already exists in v2.3.0; we keep it as-is (function replaced)
-- drop trigger if exists trg_transactions_snapshot_recalc on public.transactions;
-- create trigger trg_transactions_snapshot_recalc ... (unchanged)

-- ---------------------------------------------------------
-- 3) Rebuild: delete queue entry for dates successfully rebuilt
-- ---------------------------------------------------------
create or replace function public.rebuild_daily_snapshots(
  p_user_id uuid,
  p_from_date date,
  p_to_date date,
  p_source text default 'REBUILD'
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role_ok boolean;
  d date;
  v_asof timestamptz;
  v_ok boolean;
begin
  if p_user_id is null then raise exception 'p_user_id is required'; end if;
  if p_from_date is null or p_to_date is null then raise exception 'date range required'; end if;
  if p_from_date > p_to_date then raise exception 'p_from_date must be <= p_to_date'; end if;

  v_role_ok := public.is_service_role();
  if not v_role_ok then
    raise exception 'Service role required';
  end if;

  d := p_from_date;
  while d <= p_to_date loop
    v_ok := false;

    -- asof lookup (exact -> FFILL prev). Do not abort whole rebuild for one missing day.
    select market_data_asof into v_asof
    from public.fx_rates_daily
    where user_id = p_user_id and trading_date = d and pair='USDKRW'
    limit 1;

    if v_asof is null then
      select market_data_asof into v_asof
      from public.fx_rates_daily
      where user_id = p_user_id and trading_date < d and pair='USDKRW'
      order by trading_date desc
      limit 1;
    end if;

    if v_asof is null then
      insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
      values (p_user_id, d, 'rebuild_daily_snapshots: missing fx_rates_daily USDKRW (no prev to ffill)')
      on conflict (user_id, trading_date) do update set reason = excluded.reason;
      d := d + 1;
      continue;
    end if;

    begin
      perform public.capture_account_snapshots(p_user_id, d, v_asof, p_source);
      perform public.capture_nav_snapshot(p_user_id, d, v_asof, p_source);
      perform public.capture_card_usage_snapshot(p_user_id, d, v_asof, p_source);
      v_ok := true;
    exception when others then
      insert into public.daily_snapshot_recalc_queue(user_id, trading_date, reason)
      values (p_user_id, d, 'rebuild_daily_snapshots: ' || sqlerrm)
      on conflict (user_id, trading_date) do update set reason = excluded.reason;
      v_ok := false;
    end;

    if v_ok then
      delete from public.daily_snapshot_recalc_queue
      where user_id = p_user_id and trading_date = d;
    end if;

    d := d + 1;
  end loop;
end;
$$;

-- ---------------------------------------------------------
-- 4) Safe manual request RPC (Authenticated only, queues only)
-- ---------------------------------------------------------
create or replace function public.request_snapshot_recalc(
  p_from date,
  p_to date,
  p_reason text default 'MANUAL'
)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_today_kst date := timezone('Asia/Seoul', now())::date;
  d date;
  v_cnt int := 0;
begin
  if v_uid is null then
    raise exception 'Not authenticated';
  end if;

  if p_from is null or p_to is null then
    raise exception 'date range required';
  end if;
  if p_from > p_to then
    raise exception 'p_from must be <= p_to';
  end if;

  -- Hard limit to prevent abuse / accidental huge rebuild
  if (p_to - p_from) > 31 then
    raise exception 'Range too large (max 31 days). from=% to=%', p_from, p_to;
  end if;

  d := p_from;
  while d <= p_to loop
    -- only past dates need rebuild; ignore today/future
    if d < v_today_kst then
      perform public.enqueue_daily_snapshot_recalc(v_uid, d, p_reason);
      v_cnt := v_cnt + 1;
    end if;
    d := d + 1;
  end loop;

  return v_cnt;
end;
$$;

grant execute on function public.request_snapshot_recalc(date,date,text) to authenticated;

-- ---------------------------------------------------------
-- 5) Optional: run log table (visible in Integrity UI)
-- ---------------------------------------------------------
create table if not exists public.snapshot_recalc_runs (
  run_id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'STARTED', -- STARTED|SUCCESS|PARTIAL|FAILED
  from_date date null,
  to_date date null,
  started_at timestamptz not null default now(),
  finished_at timestamptz null,
  items_total int not null default 0,
  items_success int not null default 0,
  items_failed int not null default 0,
  message text null
);

alter table public.snapshot_recalc_runs enable row level security;

drop policy if exists "snapshot_recalc_runs_owner_read" on public.snapshot_recalc_runs;
drop policy if exists "snapshot_recalc_runs_service_write" on public.snapshot_recalc_runs;
drop policy if exists "snapshot_recalc_runs_service_update" on public.snapshot_recalc_runs;

create policy "snapshot_recalc_runs_owner_read"
on public.snapshot_recalc_runs for select
using (user_id = auth.uid() or public.is_service_role());

create policy "snapshot_recalc_runs_service_write"
on public.snapshot_recalc_runs for insert
with check (public.is_service_role());

create policy "snapshot_recalc_runs_service_update"
on public.snapshot_recalc_runs for update
using (public.is_service_role())
with check (public.is_service_role());

grant select on public.snapshot_recalc_runs to authenticated;

commit;


-- =========================================================
-- v2.3.5 additional operational indexes
-- =========================================================
create index if not exists idx_daily_snapshot_recalc_queue_user_created
  on public.daily_snapshot_recalc_queue(user_id, created_at desc);

do $$
begin
  if exists (select 1 from information_schema.tables where table_schema='public' and table_name='snapshot_recalc_runs') then
    execute 'create index if not exists idx_snapshot_recalc_runs_user_started on public.snapshot_recalc_runs(user_id, started_at desc)';
    execute 'create index if not exists idx_snapshot_recalc_runs_status_started on public.snapshot_recalc_runs(status, started_at desc)';
  end if;
end $$;




-- =========================================================
-- PAD v2.3.5 FINAL FIXUP PACK (2026-01-29 KST)
-- This section is appended to ensure the final installed DB state is:
--  - No ambiguous RPC due to legacy overloads
--  - refresh_stats matches current schema
--  - reverse_transaction maps transfer as '이체'
--  - RLS policies avoid per-row auth/current_setting re-evaluation (InitPlan)
-- =========================================================

-- =========================================================
-- FINAL FIX: drop legacy overloads that cause RPC ambiguity (42725 not unique)
--  - process_transaction_v2 legacy (without p_client_tx_id)
--  - kis_token_decide legacy (1-arg)
--  - ensure_account_balance_row legacy (2-arg)
-- =========================================================
drop function if exists public.process_transaction_v2(
  timestamptz,
  transaction_type,
  numeric,
  currency_code,
  uuid,
  uuid,
  uuid,
  uuid,
  numeric,
  numeric,
  uuid,
  text,
  text,
  boolean,
  uuid,
  uuid,
  text
);

drop function if exists public.kis_token_decide(text);

drop function if exists public.ensure_account_balance_row(uuid, uuid);


-- =========================================================
-- FINAL FIX: refresh_stats() column alignment + stable semantics
--  - Fixes errors like: column a.currency does not exist / a.is_include_in_stats does not exist
--  - Source of truth:
--      * account_balances.currency (currency_code)
--      * accounts.is_include_in_networth (boolean)
-- =========================================================
create or replace function public.refresh_stats(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_krw_cash numeric(18,2);
  v_usd_value_krw numeric(18,2);
  v_stock_value_krw numeric(18,2);
  v_total_liability numeric(18,2);
  v_usdkrw numeric(18,6);
begin
  -- KRW cash total (only included accounts)
  select coalesce(sum(ab.balance), 0)
    into v_krw_cash
  from public.account_balances ab
  join public.accounts a on a.account_id = ab.account_id
  where ab.user_id = p_user_id
    and ab.currency = 'KRW'
    and a.is_include_in_networth = true;

  -- USD value in KRW (wallet)
  select coalesce(sum(est_value_krw), 0)
    into v_usd_value_krw
  from public.currency_wallet
  where user_id = p_user_id;

  -- USDKRW rate
  select rate into v_usdkrw
  from public.fx_rates
  where user_id = p_user_id and pair = 'USDKRW'
  limit 1;

  if v_usdkrw is null then
    v_usdkrw := 0;
  end if;

  -- Stock value in KRW (requires stock_prices)
  select coalesce(sum(
      case
        when sp.currency = 'KRW' then h.holdings_qty * sp.price
        when sp.currency = 'USD' then h.holdings_qty * sp.price * v_usdkrw
        else 0
      end
    ), 0)
    into v_stock_value_krw
  from public.holdings h
  join public.stock_prices sp
    on sp.user_id = h.user_id and sp.stock_id = h.stock_id
  where h.user_id = p_user_id;

  -- Total liabilities
  select coalesce(sum(principal_remaining), 0)
    into v_total_liability
  from public.liabilities
  where user_id = p_user_id
    and is_include_in_networth = true;

  -- Ensure stats row exists (idempotent)
  insert into public.stats(user_id)
  values (p_user_id)
  on conflict (user_id) do nothing;

  -- Update stats
  update public.stats
  set
    krw_cash_total = v_krw_cash,
    usd_value_krw = v_usd_value_krw,
    stock_value_krw = v_stock_value_krw,
    total_liability_krw = v_total_liability,
    total_networth_krw = v_krw_cash + v_usd_value_krw + v_stock_value_krw - v_total_liability,
    updated_at = now()
  where user_id = p_user_id;
end;
$$;

grant execute on function public.refresh_stats(uuid) to authenticated;


-- ---------------------------------------------------------
-- FINAL FIX: reverse_transaction transfer label ('이체')
-- ---------------------------------------------------------
-- Patch: fix reverse_transaction transfer type label

create or replace function public.reverse_transaction(
  p_transaction_id uuid,
  p_reason text default 'USER'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;
  v_reverse_type transaction_type;
  v_reverse_account_id uuid;
  v_reverse_to_account_id uuid;
  v_reverse_memo text;
  v_new_tx_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- Serialize per-user mutation
  perform pg_advisory_xact_lock(hashtextextended(v_user_id::text, 911911));

  select * into v_org
  from public.transactions
  where transaction_id = p_transaction_id
    and user_id = v_user_id
  for update;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot reverse a correction transaction';
  end if;

  if v_org.is_voided = true then
    raise exception 'Already voided (transaction_id=%)', p_transaction_id;
  end if;

  -- Map reverse type + account routing
  if v_org.type in ('지출','수수료','세금') then
    v_reverse_type := '수입';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type in ('수입','배당금') then
    v_reverse_type := '지출';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '카드_대금' then
    v_reverse_type := '수입';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '이체' then
    v_reverse_type := '이체';
    v_reverse_account_id := v_org.to_account_id;
    v_reverse_to_account_id := v_org.account_id;
  elsif v_org.type = '주식_매수' then
    v_reverse_type := '주식_매도';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '주식_매도' then
    v_reverse_type := '주식_매수';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '대출_실행' then
    v_reverse_type := '대출_상환_원금';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type in ('대출_상환_원금','대출_상환_이자') then
    v_reverse_type := '대출_실행';
    v_reverse_account_id := v_org.account_id;
  else
    raise exception 'Unsupported reverse mapping for type=%', v_org.type;
  end if;

  v_reverse_memo :=
    coalesce('[REVERSAL] ' || p_reason, '[REVERSAL]') ||
    ' (orig=' || v_org.transaction_id::text || ')';

  -- IMPORTANT:
  -- Void original FIRST so KPI recalculation inside process_transaction_v2 excludes it.
  update public.transactions
  set is_voided = true,
      voided_at = now(),
      void_reason = p_reason,
      updated_at = now()
  where transaction_id = v_org.transaction_id
    and user_id = v_user_id;

  -- Create opposite entry (correction) via main RPC (will refresh_stats + recalc_monthly_kpis)
  v_new_tx_id := public.process_transaction_v2(
    v_org.date,
    v_reverse_type,
    v_org.amount,
    v_org.currency,
    v_reverse_account_id,
    v_reverse_to_account_id,
    v_org.card_id,
    v_org.stock_id,
    v_org.qty,
    v_org.fx_rate,
    v_org.liability_id,
    v_org.category,
    v_reverse_memo,
    true,                          -- is_correction
    v_org.transaction_id,          -- linked_transaction_id
    v_org.category_id,
    v_org.merchant,
    gen_random_uuid()              -- client_tx_id (server-side for reversals)
  );

  -- Link original -> correction for audit
  update public.transactions
  set superseded_by = v_new_tx_id,
      updated_at = now()
  where transaction_id = v_org.transaction_id
    and user_id = v_user_id;

  return v_new_tx_id;
end;
$$;

-- ---------------------------------------------------------
-- FINAL FIX: RLS performance + policy consolidation (SAFE)
-- ---------------------------------------------------------
-- =========================================================
-- PAD v2.3.5 Patch (SAFE): RLS Performance (InitPlan) + Policy Consolidation
-- Date: 2026-01-29 (KST)
--
-- What it fixes (Supabase Linter):
--  - 0003_auth_rls_initplan:
--      Wrap auth.uid() / current_setting() helpers so Postgres evaluates them once per statement
--      instead of re-evaluating per row.
--  - 0006_multiple_permissive_policies:
--      Ensure policies are scoped with `TO <role>` so only the intended role sees the policy.
--
-- Behavioral impact:
--  - Intended to be *no functional change* for the app.
--  - NOTE: fx_pair_map is kept READ-ONLY for authenticated (service_role can write).
--
-- Safe to re-run: uses DROP POLICY IF EXISTS.
-- =========================================================

begin;

-- ---------------------------------------------------------
-- 0003_auth_rls_initplan : Fix per-row auth.uid()/current_setting re-eval
-- ---------------------------------------------------------

-- market_data_sync_runs
drop policy if exists "market_data_sync_runs_owner_read" on public.market_data_sync_runs;
drop policy if exists "market_data_sync_runs_service_write" on public.market_data_sync_runs;
drop policy if exists "market_data_sync_runs_service_update" on public.market_data_sync_runs;

create policy "market_data_sync_runs_owner_read"
on public.market_data_sync_runs for select
to authenticated
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

create policy "market_data_sync_runs_service_write"
on public.market_data_sync_runs for insert
to service_role
with check ((select public.is_service_role()));

create policy "market_data_sync_runs_service_update"
on public.market_data_sync_runs for update
to service_role
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

-- fx_rates_daily
drop policy if exists "fx_rates_daily_owner_read" on public.fx_rates_daily;
drop policy if exists "fx_rates_daily_service_write" on public.fx_rates_daily;
drop policy if exists "fx_rates_daily_service_update" on public.fx_rates_daily;

create policy "fx_rates_daily_owner_read"
on public.fx_rates_daily for select
to authenticated
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

create policy "fx_rates_daily_service_write"
on public.fx_rates_daily for insert
to service_role
with check ((select public.is_service_role()));

create policy "fx_rates_daily_service_update"
on public.fx_rates_daily for update
to service_role
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

-- stock_prices_daily
drop policy if exists "stock_prices_daily_owner_read" on public.stock_prices_daily;
drop policy if exists "stock_prices_daily_service_write" on public.stock_prices_daily;
drop policy if exists "stock_prices_daily_service_update" on public.stock_prices_daily;

create policy "stock_prices_daily_owner_read"
on public.stock_prices_daily for select
to authenticated
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

create policy "stock_prices_daily_service_write"
on public.stock_prices_daily for insert
to service_role
with check ((select public.is_service_role()));

create policy "stock_prices_daily_service_update"
on public.stock_prices_daily for update
to service_role
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

-- card_usage_daily
drop policy if exists "card_usage_daily_owner_read" on public.card_usage_daily;
drop policy if exists "card_usage_daily_service_write" on public.card_usage_daily;
drop policy if exists "card_usage_daily_service_update" on public.card_usage_daily;

create policy "card_usage_daily_owner_read"
on public.card_usage_daily for select
to authenticated
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

create policy "card_usage_daily_service_write"
on public.card_usage_daily for insert
to service_role
with check ((select public.is_service_role()));

create policy "card_usage_daily_service_update"
on public.card_usage_daily for update
to service_role
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

-- daily_snapshot_recalc_queue
drop policy if exists "daily_snapshot_recalc_queue_owner_read" on public.daily_snapshot_recalc_queue;
drop policy if exists "daily_snapshot_recalc_queue_service_write" on public.daily_snapshot_recalc_queue;

create policy "daily_snapshot_recalc_queue_owner_read"
on public.daily_snapshot_recalc_queue for select
to authenticated
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

create policy "daily_snapshot_recalc_queue_service_write"
on public.daily_snapshot_recalc_queue for insert
to service_role
with check ((select public.is_service_role()));

-- stock_realized_pnl
drop policy if exists "stock_realized_pnl_owner_read" on public.stock_realized_pnl;
drop policy if exists "stock_realized_pnl_service_write" on public.stock_realized_pnl;

create policy "stock_realized_pnl_owner_read"
on public.stock_realized_pnl for select
to authenticated
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

create policy "stock_realized_pnl_service_write"
on public.stock_realized_pnl for insert
to service_role
with check ((select public.is_service_role()));

-- snapshot_recalc_runs
drop policy if exists "snapshot_recalc_runs_owner_read" on public.snapshot_recalc_runs;
drop policy if exists "snapshot_recalc_runs_service_write" on public.snapshot_recalc_runs;
drop policy if exists "snapshot_recalc_runs_service_update" on public.snapshot_recalc_runs;

create policy "snapshot_recalc_runs_owner_read"
on public.snapshot_recalc_runs for select
to authenticated
using (
  (select public.is_service_role())
  or user_id = (select auth.uid())
);

create policy "snapshot_recalc_runs_service_write"
on public.snapshot_recalc_runs for insert
to service_role
with check ((select public.is_service_role()));

create policy "snapshot_recalc_runs_service_update"
on public.snapshot_recalc_runs for update
to service_role
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

-- ---------------------------------------------------------
-- 0006_multiple_permissive_policies : Consolidate / scope by roles
-- ---------------------------------------------------------

-- fx_pair_map: authenticated READ only / service_role ALL
drop policy if exists "fx_pair_map_read_auth" on public.fx_pair_map;
drop policy if exists "fx_pair_map_write_service" on public.fx_pair_map;
drop policy if exists "fx_pair_map_owner_all" on public.fx_pair_map;
drop policy if exists "fx_pair_map_service_all" on public.fx_pair_map;

create policy "fx_pair_map_read_auth"
on public.fx_pair_map for select
to authenticated
using ((select auth.uid()) is not null);

create policy "fx_pair_map_service_all"
on public.fx_pair_map for all
to service_role
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

-- stock_corporate_actions: authenticated owner / service_role all
drop policy if exists "stock_corp_actions_owner_all" on public.stock_corporate_actions;
drop policy if exists "stock_corp_actions_service_all" on public.stock_corporate_actions;

create policy "stock_corp_actions_owner_all"
on public.stock_corporate_actions for all
to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy "stock_corp_actions_service_all"
on public.stock_corporate_actions for all
to service_role
using ((select public.is_service_role()))
with check ((select public.is_service_role()));

commit;

-- Optional verification:
-- select schemaname, tablename, policyname, roles, cmd
-- from pg_policies
-- where schemaname='public'
--   and tablename in (
--     'market_data_sync_runs','fx_rates_daily','stock_prices_daily','card_usage_daily',
--     'daily_snapshot_recalc_queue','stock_realized_pnl','snapshot_recalc_runs',
--     'fx_pair_map','stock_corporate_actions'
--   )
-- order by tablename, cmd, policyname;


-- ============================================================================
-- PATCH: reverse_transaction correction category fix (2026-01-30)
-- ============================================================================

-- =========================================================
-- PAD v2.3.5 Patch (2026-01-30)
-- reverse_transaction: correction category alignment
--
-- Fix
--  - When a reversal maps into type '수입' or '지출', force the correction transaction
--    to use a dedicated '공용' category ([SYSTEM] 정정).
--
-- Rationale
--  - public.transactions has chk_transactions_category_required:
--      type in ('지출','수입') => category_id IS NOT NULL
--  - reverse_transaction flips '지출' <-> '수입' for corrections, so reusing the
--    original category (e.g., '지출' category) can violate kind validation.
-- =========================================================

begin;

create or replace function public.reverse_transaction(
  p_transaction_id uuid,
  p_reason text default 'USER'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_org public.transactions%rowtype;
  v_reverse_type transaction_type;
  v_reverse_account_id uuid;
  v_reverse_to_account_id uuid;
  v_reverse_memo text;
  v_new_tx_id uuid;

  v_reverse_category_id uuid;
  v_reverse_category text;
  v_sys_category_id uuid;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- Serialize per-user mutation
  perform pg_advisory_xact_lock(hashtextextended(v_user_id::text, 911911));

  select * into v_org
  from public.transactions
  where transaction_id = p_transaction_id
    and user_id = v_user_id
  for update;

  if not found then
    raise exception 'Transaction not found or not owned (transaction_id=%)', p_transaction_id;
  end if;

  if v_org.is_correction = true then
    raise exception 'Cannot reverse a correction transaction';
  end if;

  if v_org.is_voided = true then
    raise exception 'Already voided (transaction_id=%)', p_transaction_id;
  end if;

  -- Map reverse type + account routing
  if v_org.type in ('지출','수수료','세금') then
    v_reverse_type := '수입';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type in ('수입','배당금') then
    v_reverse_type := '지출';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '카드_대금' then
    v_reverse_type := '수입';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '이체' then
    v_reverse_type := '이체';
    v_reverse_account_id := v_org.to_account_id;
    v_reverse_to_account_id := v_org.account_id;
  elsif v_org.type = '주식_매수' then
    v_reverse_type := '주식_매도';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '주식_매도' then
    v_reverse_type := '주식_매수';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type = '대출_실행' then
    v_reverse_type := '대출_상환_원금';
    v_reverse_account_id := v_org.account_id;
  elsif v_org.type in ('대출_상환_원금','대출_상환_이자') then
    v_reverse_type := '대출_실행';
    v_reverse_account_id := v_org.account_id;
  else
    raise exception 'Unsupported reverse mapping for type=%', v_org.type;
  end if;

  v_reverse_memo :=
    coalesce('[REVERSAL] ' || p_reason, '[REVERSAL]') ||
    ' (orig=' || v_org.transaction_id::text || ')';

  -- For reversals that become (수입/지출), enforce a shared category to avoid kind mismatch
  if v_reverse_type in ('수입','지출') then
    select c.category_id
      into v_sys_category_id
    from public.categories c
    where c.user_id = v_user_id
      and c.category_name = '[SYSTEM] 정정'
    limit 1;

    if v_sys_category_id is null then
      insert into public.categories(user_id, category_name, category_kind, is_active, sort_order)
      values (v_user_id, '[SYSTEM] 정정', '공용', false, 9999)
      returning category_id into v_sys_category_id;
    end if;

    v_reverse_category_id := v_sys_category_id;
    v_reverse_category := '[SYSTEM] 정정';
  else
    v_reverse_category_id := v_org.category_id;
    v_reverse_category := v_org.category;
  end if;

  -- Void original FIRST so KPI recalculation inside process_transaction_v2 excludes it.
  update public.transactions
  set is_voided = true,
      voided_at = now(),
      void_reason = p_reason,
      updated_at = now()
  where transaction_id = v_org.transaction_id
    and user_id = v_user_id;

  -- Create opposite entry (correction) via main RPC
  v_new_tx_id := public.process_transaction_v2(
    v_org.date,
    v_reverse_type,
    v_org.amount,
    v_org.currency,
    v_reverse_account_id,
    v_reverse_to_account_id,
    v_org.card_id,
    v_org.stock_id,
    v_org.qty,
    v_org.fx_rate,
    v_org.liability_id,
    v_reverse_category,
    v_reverse_memo,
    true,                          -- is_correction
    v_org.transaction_id,          -- linked_transaction_id
    v_reverse_category_id,
    v_org.merchant,
    gen_random_uuid()              -- client_tx_id (server-side for reversals)
  );

  -- Link original -> correction for audit
  update public.transactions
  set superseded_by = v_new_tx_id,
      updated_at = now()
  where transaction_id = v_org.transaction_id
    and user_id = v_user_id;

  return v_new_tx_id;
end;
$$;

commit;


-- ============================================================================
-- PATCH: kis_token_cache align to Edge (2026-01-30)
-- ============================================================================

-- PAD v2.3.5 - KIS token cache alignment patch (Edge expects encrypted token)
-- Date: 2026-01-30 (KST)
--
-- 목적
--  1) kis_token_cache를 Edge(v2.3.5) 기대 스키마(access_token_enc)와 정합시킴
--  2) kis_token_decide/finish/fail 오버로드 전부 제거 후 단일 시그니처로 재생성
--  3) stuck 상태(refresh_deadline/owner) 초기화
--
-- 영향
--  - 기능/설계 변경 없음: 토큰 저장/재사용 로직만 정상화
--  - 현재 cache가 비정상(null) 상태라면, 패치 후 첫 동기화 시 1회 재발급될 수 있음

set statement_timeout = 0;
set lock_timeout = '10s';

begin;

-- 0) Ensure column exists (Edge stores ciphertext only)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'kis_token_cache'
      AND column_name = 'access_token_enc'
  ) THEN
    ALTER TABLE public.kis_token_cache ADD COLUMN access_token_enc text NULL;
  END IF;
END$$;

-- 1) Ensure single row exists
INSERT INTO public.kis_token_cache(id) VALUES (1)
ON CONFLICT (id) DO NOTHING;

-- 2) Drop all overloads of kis_token_* in public, then recreate single signatures
DO $$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT n.nspname AS schema_name,
           p.proname AS func_name,
           pg_get_function_identity_arguments(p.oid) AS args
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
     WHERE n.nspname = 'public'
       AND p.proname IN ('kis_token_decide','kis_token_finish_refresh','kis_token_fail_refresh')
  LOOP
    EXECUTE format('DROP FUNCTION IF EXISTS %I.%I(%s);', r.schema_name, r.func_name, r.args);
  END LOOP;
END$$;

-- 3) Recreate RPCs (single signature each)
CREATE OR REPLACE FUNCTION public.kis_token_decide(
  p_owner text DEFAULT NULL,
  p_safety_seconds int DEFAULT 60,
  p_min_interval_seconds int DEFAULT 60,
  p_refresh_deadline_seconds int DEFAULT 20
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_now timestamptz := now();
  v_access_token_enc text;
  v_expires_at timestamptz;
  v_last_attempt timestamptz;
  v_refresh_deadline timestamptz;
  v_wait int;
BEGIN
  INSERT INTO public.kis_token_cache(id) VALUES (1)
  ON CONFLICT (id) DO NOTHING;

  -- short critical section
  PERFORM pg_advisory_lock(73001331);

  SELECT access_token_enc, expires_at, last_attempt_at, refresh_deadline
    INTO v_access_token_enc, v_expires_at, v_last_attempt, v_refresh_deadline
  FROM public.kis_token_cache
  WHERE id = 1;

  -- 1) valid cache?
  IF v_access_token_enc IS NOT NULL AND v_expires_at IS NOT NULL
     AND (extract(epoch FROM (v_expires_at - v_now)) > p_safety_seconds)
  THEN
    PERFORM pg_advisory_unlock(73001331);
    RETURN jsonb_build_object(
      'action', 'USE_CACHE',
      'access_token_enc', v_access_token_enc,
      'expires_at', v_expires_at
    );
  END IF;

  -- 2) someone refreshing?
  IF v_refresh_deadline IS NOT NULL AND v_refresh_deadline > v_now THEN
    v_wait := ceil(extract(epoch FROM (v_refresh_deadline - v_now)))::int;
    PERFORM pg_advisory_unlock(73001331);
    RETURN jsonb_build_object('action','WAIT','wait_seconds', greatest(v_wait, 1));
  END IF;

  -- 3) min interval defense
  IF v_last_attempt IS NOT NULL AND (extract(epoch FROM (v_now - v_last_attempt)) < p_min_interval_seconds) THEN
    v_wait := ceil(p_min_interval_seconds - extract(epoch FROM (v_now - v_last_attempt)))::int;
    PERFORM pg_advisory_unlock(73001331);
    RETURN jsonb_build_object('action','WAIT','wait_seconds', greatest(v_wait, 1));
  END IF;

  -- 4) allow refresh
  UPDATE public.kis_token_cache
     SET refresh_deadline = v_now + make_interval(secs => p_refresh_deadline_seconds),
         refresh_owner = p_owner,
         last_attempt_at = v_now,
         updated_at = v_now
   WHERE id = 1;

  PERFORM pg_advisory_unlock(73001331);
  RETURN jsonb_build_object('action','REFRESH_ALLOWED','wait_seconds',0);
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      PERFORM pg_advisory_unlock(73001331);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
    RAISE;
END;
$$;

CREATE OR REPLACE FUNCTION public.kis_token_finish_refresh(
  p_owner text,
  p_access_token_enc text,
  p_expires_at timestamptz
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_now timestamptz := now();
BEGIN
  IF p_access_token_enc IS NULL OR length(p_access_token_enc) = 0 THEN
    RAISE EXCEPTION 'p_access_token_enc is required';
  END IF;
  IF p_expires_at IS NULL THEN
    RAISE EXCEPTION 'p_expires_at is required';
  END IF;

  PERFORM pg_advisory_lock(73001331);

  UPDATE public.kis_token_cache
     SET access_token_enc = p_access_token_enc,
         expires_at = p_expires_at,
         last_issued_at = v_now,
         refresh_deadline = NULL,
         refresh_owner = NULL,
         updated_at = v_now
   WHERE id = 1;

  PERFORM pg_advisory_unlock(73001331);
END;
$$;

CREATE OR REPLACE FUNCTION public.kis_token_fail_refresh(
  p_owner text,
  p_error text DEFAULT NULL
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_now timestamptz := now();
BEGIN
  PERFORM pg_advisory_lock(73001331);

  UPDATE public.kis_token_cache
     SET refresh_deadline = NULL,
         refresh_owner = NULL,
         updated_at = v_now
   WHERE id = 1;

  PERFORM pg_advisory_unlock(73001331);
END;
$$;

-- 4) Tighten privileges: only service_role should call these RPCs
REVOKE ALL ON FUNCTION public.kis_token_decide(text,int,int,int) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.kis_token_finish_refresh(text,text,timestamptz) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.kis_token_fail_refresh(text,text) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.kis_token_decide(text,int,int,int) TO service_role;
GRANT EXECUTE ON FUNCTION public.kis_token_finish_refresh(text,text,timestamptz) TO service_role;
GRANT EXECUTE ON FUNCTION public.kis_token_fail_refresh(text,text) TO service_role;

-- (옵션) SQL Editor에서 테스트를 편하게 하려면 주석 해제
-- GRANT EXECUTE ON FUNCTION public.kis_token_decide(text,int,int,int) TO authenticated;
-- GRANT EXECUTE ON FUNCTION public.kis_token_finish_refresh(text,text,timestamptz) TO authenticated;
-- GRANT EXECUTE ON FUNCTION public.kis_token_fail_refresh(text,text) TO authenticated;

-- 5) Clear stuck state (if any) - keeps last_attempt_at for throttle
UPDATE public.kis_token_cache
   SET refresh_deadline = NULL,
       refresh_owner = NULL,
       updated_at = now()
 WHERE id = 1;

commit;

-- Post-check (run manually if needed)
-- select last_issued_at, expires_at, last_attempt_at, refresh_deadline, refresh_owner, (access_token_enc is not null) as has_token
-- from public.kis_token_cache where id = 1;

-- =========================================================
-- FINAL HARDENING PATCH (v2.3.5 RELEASE) — 2026-01-30
-- Fix: authenticated 호출(get_dashboard)에서 kis_token_cache(RLS no-policy) 접근 시 permission denied
-- Strategy: keep get_dashboard as SECURITY INVOKER, but read kis_token_cache via SECURITY DEFINER helper
-- Security: set search_path, revoke public/anon execute
-- =========================================================

create or replace function public.get_kis_token_status()
returns jsonb
language plpgsql
stable
security definer
set search_path = public, pg_temp
as $$
declare
  v_kis jsonb;
begin
  select to_jsonb(k)
    into v_kis
  from (
    select
      id,
      expires_at,
      last_issued_at,
      last_attempt_at,
      refresh_deadline,
      refresh_owner,
      updated_at
    from public.kis_token_cache
    where id = 1
    limit 1
  ) k;

  return v_kis;
end $$;

revoke all on function public.get_kis_token_status() from public;
revoke all on function public.get_kis_token_status() from anon;
grant execute on function public.get_kis_token_status() to authenticated;
grant execute on function public.get_kis_token_status() to service_role;


create or replace function public.get_dashboard(
  p_limit int default 10,
  p_include_nav boolean default true
)
returns jsonb
language plpgsql
stable
security invoker
as $$
declare
  v_uid uuid := (select auth.uid());
  v_stats jsonb;
  v_recent jsonb;
  v_sync jsonb;
  v_kis jsonb;
  v_nav jsonb;
begin
  if v_uid is null then
    raise exception 'Unauthenticated: auth.uid() is null';
  end if;

  select to_jsonb(s)
  into v_stats
  from public.stats s
  where s.user_id = v_uid;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.date desc, t.created_at desc), '[]'::jsonb)
  into v_recent
  from (
    select *
    from public.v_transactions_display
    where user_id = v_uid
    order by date desc, created_at desc
    limit greatest(p_limit, 1)
  ) t;

  select to_jsonb(x)
  into v_sync
  from (
    select status, mode, market, started_at, finished_at, market_data_asof, detail
    from public.market_data_sync_runs
    where user_id = v_uid
    order by started_at desc
    limit 1
  ) x;

  v_kis := public.get_kis_token_status();

  if p_include_nav then
    select to_jsonb(n)
    into v_nav
    from (
      with last2 as (
        select trading_date, nav_krw
        from public.portfolio_nav_daily
        where user_id = v_uid
        order by trading_date desc
        limit 2
      )
      select
        (select trading_date from last2 order by trading_date desc limit 1) as latest_date,
        (select nav_krw from last2 order by trading_date desc limit 1) as latest_nav_krw,
        (select nav_krw from last2 order by trading_date desc offset 1 limit 1) as prev_nav_krw,
        ((select nav_krw from last2 order by trading_date desc limit 1)
         - (select nav_krw from last2 order by trading_date desc offset 1 limit 1)) as delta_nav_krw
    ) n;
  else
    v_nav := null;
  end if;

  return jsonb_build_object(
    'user_id', v_uid,
    'stats', v_stats,
    'recent', v_recent,
    'sync', v_sync,
    'kis', v_kis,
    'nav', v_nav,
    'generated_at', now()
  );
end $$;

revoke all on function public.get_dashboard(int, boolean) from public;
revoke all on function public.get_dashboard(int, boolean) from anon;
grant execute on function public.get_dashboard(int, boolean) to authenticated;
grant execute on function public.get_dashboard(int, boolean) to service_role;

-- =========================================================
-- PATCH: Returns Summary (Networth vs TWR) — 2026-01-30
-- =========================================================

begin;

-- =========================================================
-- PAD v2.3.5 Patch: Returns Summary (Networth vs Investment TWR)
-- Date: 2026-01-30
--
-- 목적
--  - "누적 순자산 증감률(NAV 기반)" 과 "입출금 제외 투자성과(TWR)"를 분리 제공
--  - 프론트(MAUI)에서 일/월/연/누적을 1회 RPC로 조회 가능
--
-- 추가/수정 객체
--  - function public.ctx_uid()
--  - view public.v_portfolio_assets_daily
--  - view public.v_external_cashflow_daily
--  - view public.v_portfolio_twr_daily
--  - function public.get_returns_summary()
--
-- 주의
--  - SQL Editor(비인증) 환경 테스트를 위해 ctx_uid()가 auth.uid()가 null이면
--    current_setting('app.user_id')를 fallback으로 사용합니다.
--  - 앱/Edge/PostgREST 환경에서는 auth.uid()가 정상 주입되므로 fallback은 영향 없습니다.
-- =========================================================

-- =========================================================
-- 0) Helper: ctx_uid()
--    - In production: auth.uid()
--    - In SQL Editor: set_config('app.user_id','<uuid>',true) 로 주입 가능
-- =========================================================
create or replace function public.ctx_uid()
returns uuid
language sql
stable
as $$
  select coalesce(
    auth.uid(),
    nullif(current_setting('app.user_id', true), '')::uuid
  );
$$;

grant execute on function public.ctx_uid() to authenticated;


-- =========================================================
-- 1) Assets daily series (KRW) with LIVE fallback
--    - snapshot: account_nav_daily 합계(포함 계좌만)
--    - live: stats(krw_cash_total + usd_value_krw + stock_value_krw)
-- =========================================================
create or replace view public.v_portfolio_assets_daily as
with u as (
  select public.ctx_uid() as user_id, (now() at time zone 'Asia/Seoul')::date as today
),
snap as (
  select
    an.user_id,
    an.trading_date,
    round(coalesce(sum(an.total_krw),0)::numeric, 2) as assets_krw,
    max(an.market_data_asof) as market_data_asof,
    max(an.source) as source,
    true as is_snapshot
  from public.account_nav_daily an
  join public.accounts a on a.account_id = an.account_id
  where an.user_id = (select u.user_id from u)
    and a.is_include_in_networth = true
  group by an.user_id, an.trading_date
),
live as (
  select
    s.user_id,
    (select u.today from u) as trading_date,
    round((s.krw_cash_total + s.usd_value_krw + s.stock_value_krw)::numeric, 2) as assets_krw,
    s.updated_at as market_data_asof,
    'LIVE'::text as source,
    false as is_snapshot
  from public.stats s
  where s.user_id = (select u.user_id from u)
    and not exists (
      select 1
      from public.account_nav_daily x
      where x.user_id = (select u.user_id from u)
        and x.trading_date = (select u.today from u)
      limit 1
    )
),
all_rows as (
  select * from snap
  union all
  select * from live
)
select * from all_rows;

grant select on public.v_portfolio_assets_daily to authenticated;


-- =========================================================
-- 2) External cashflow daily (NAV-effective flows only)
--    - include: income/expense via account (not card spend)
--    - include: card payment, loan principal/interest
--
-- 정책(기본)
--  - 외부 유입(+): 수입, 대출_실행
--  - 외부 유출(-): 지출(현금/계좌), 카드_대금, 대출_상환_원금, 대출_상환_이자
--  - 카드 사용(카드 결제 거래)은 "순자산"에 즉시 반영되지 않는 구조이므로,
--    외부흐름에서는 카드 사용이 아니라 카드_대금만 포함합니다.
-- =========================================================
create or replace view public.v_external_cashflow_daily as
with u as (select public.ctx_uid() as user_id)
select
  t.user_id,
  (t.date at time zone 'Asia/Seoul')::date as trading_date,
  round(sum(
    case
      -- 외부 유입(+)
      when t.type in ('수입','대출_실행') then
        case
          when t.currency = 'KRW' then t.amount
          else t.amount * coalesce(
            t.fx_rate,
            (select r.rate
             from public.fx_rates_daily r
             where r.user_id = t.user_id
               and r.trading_date = (t.date at time zone 'Asia/Seoul')::date
               and r.pair = 'USDKRW'
             limit 1),
            (select r2.rate
             from public.fx_rates r2
             where r2.user_id = t.user_id
               and r2.pair = 'USDKRW'
             limit 1)
          )
        end

      -- 외부 유출(-)
      when t.type in ('지출','카드_대금','대출_상환_원금','대출_상환_이자') then
        -(
          case
            when t.currency = 'KRW' then t.amount
            else t.amount * coalesce(
              t.fx_rate,
              (select r.rate
               from public.fx_rates_daily r
               where r.user_id = t.user_id
                 and r.trading_date = (t.date at time zone 'Asia/Seoul')::date
                 and r.pair = 'USDKRW'
               limit 1),
              (select r2.rate
               from public.fx_rates r2
               where r2.user_id = t.user_id
                 and r2.pair = 'USDKRW'
               limit 1)
            )
          end
        )
      else 0
    end
  )::numeric, 2) as external_flow_krw
from public.transactions t
where t.user_id = (select u.user_id from u)
  and t.is_voided = false
  and (
        (t.type in ('수입','지출') and t.account_id is not null and t.card_id is null)
     or (t.type = '카드_대금')
     or (t.type in ('대출_실행','대출_상환_원금','대출_상환_이자'))
  )
group by t.user_id, (t.date at time zone 'Asia/Seoul')::date;

grant select on public.v_external_cashflow_daily to authenticated;


-- =========================================================
-- 3) TWR daily series (assets-based) - NON-RECURSIVE / WINDOW
--
--  r_t = (A_t - A_{t-1} - Flow_t) / A_{t-1}
--  TWR Index = Π(1 + r_t) = exp( Σ ln(1 + r_t) )
--
--  - exp/ln은 double precision을 사용하므로,
--    round( , digits ) 적용을 위해 numeric 캐스팅을 포함합니다.
-- =========================================================
create or replace view public.v_portfolio_twr_daily as
with base as (
  select
    a.user_id,
    a.trading_date,
    a.assets_krw,
    coalesce(f.external_flow_krw, 0) as external_flow_krw,
    lag(a.assets_krw) over (partition by a.user_id order by a.trading_date) as prev_assets_krw
  from public.v_portfolio_assets_daily a
  left join public.v_external_cashflow_daily f
    on f.user_id = a.user_id
   and f.trading_date = a.trading_date
),
calc as (
  select
    *,
    case
      when prev_assets_krw is null or prev_assets_krw <= 0 then null
      else (assets_krw - prev_assets_krw - external_flow_krw) / prev_assets_krw
    end as twr_daily_r
  from base
),
acc as (
  select
    *,
    sum(
      case
        when twr_daily_r is null then 0::double precision
        when (1 + twr_daily_r) > 0 then ln((1 + twr_daily_r)::double precision)
        else 0::double precision
      end
    ) over (
      partition by user_id
      order by trading_date
      rows between unbounded preceding and current row
    ) as cum_ln,

    min(
      case
        when twr_daily_r is null then 1
        when (1 + twr_daily_r) > 0 then 1
        else 0
      end
    ) over (
      partition by user_id
      order by trading_date
      rows between unbounded preceding and current row
    ) as all_ok
  from calc
)
select
  user_id,
  trading_date,
  assets_krw,
  external_flow_krw,
  prev_assets_krw,
  round((assets_krw - prev_assets_krw - external_flow_krw)::numeric, 2) as pnl_ex_flow_krw,
  round((twr_daily_r * 100)::numeric, 4) as twr_daily_pct,

  case
    when all_ok = 1 then round((exp(cum_ln))::numeric, 12)
    else null
  end as twr_index,

  case
    when all_ok = 1 then round(((exp(cum_ln) - 1) * 100)::numeric, 4)
    else null
  end as twr_cum_pct
from acc;

grant select on public.v_portfolio_twr_daily to authenticated;


-- =========================================================
-- 4) Summary RPC: networth-return + TWR-return
--
-- 반환값:
--  - networth_* : v_portfolio_nav_daily 기반 (순자산 증감률)
--  - twr_*      : v_portfolio_twr_daily 기반 (입출금 제외 투자성과)
--
-- NOTE:
--  - returns table(...) 의 컬럼명이 PL/pgSQL 변수로도 존재하므로
--    내부 SELECT에서는 alias.column 형태로 완전 수식합니다(ambiguous 방지).
-- =========================================================
create or replace function public.get_returns_summary()
returns table (
  asof date,
  networth_krw numeric(18,2),
  networth_daily_pct numeric(10,4),
  networth_mtd_pct numeric(10,4),
  networth_ytd_pct numeric(10,4),
  networth_cum_pct numeric(10,4),
  assets_krw numeric(18,2),
  external_flow_today_krw numeric(18,2),
  twr_daily_pct numeric(10,4),
  twr_mtd_pct numeric(10,4),
  twr_ytd_pct numeric(10,4),
  twr_cum_pct numeric(10,4)
)
language plpgsql
set search_path = public
as $$
declare
  v_user_id uuid;
  v_asof date := (now() at time zone 'Asia/Seoul')::date;

  v_nav_today numeric(18,2);
  v_nav_today_daily_pct numeric(10,4);

  v_nav_month_start numeric(18,2);
  v_nav_year_start numeric(18,2);
  v_nav_first numeric(18,2);

  v_assets_today numeric(18,2);
  v_flow_today numeric(18,2);

  v_twr_today_pct numeric(10,4);
  v_twr_today_cum_pct numeric(10,4);
  v_twr_today_index numeric;

  v_month_start date := date_trunc('month', v_asof)::date;
  v_year_start  date := date_trunc('year',  v_asof)::date;

  v_baseline_index_m numeric := 1;
  v_baseline_index_y numeric := 1;
begin
  v_user_id := public.ctx_uid();
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- NAV today + daily %
  select n.nav_krw, n.delta_nav_pct
    into v_nav_today, v_nav_today_daily_pct
  from public.v_portfolio_nav_daily n
  where n.trading_date <= v_asof
  order by n.trading_date desc
  limit 1;

  -- NAV baselines
  select n.nav_krw
    into v_nav_month_start
  from public.v_portfolio_nav_daily n
  where n.trading_date >= v_month_start and n.trading_date <= v_asof
  order by n.trading_date asc
  limit 1;

  select n.nav_krw
    into v_nav_year_start
  from public.v_portfolio_nav_daily n
  where n.trading_date >= v_year_start and n.trading_date <= v_asof
  order by n.trading_date asc
  limit 1;

  select n.nav_krw
    into v_nav_first
  from public.v_portfolio_nav_daily n
  where n.trading_date <= v_asof
  order by n.trading_date asc
  limit 1;

  -- Assets today
  select a.assets_krw
    into v_assets_today
  from public.v_portfolio_assets_daily a
  where a.trading_date <= v_asof
  order by a.trading_date desc
  limit 1;

  -- External flow today
  select f.external_flow_krw
    into v_flow_today
  from public.v_external_cashflow_daily f
  where f.trading_date = v_asof
  limit 1;

  v_flow_today := coalesce(v_flow_today, 0);

  -- TWR today
  select t.twr_daily_pct, t.twr_cum_pct, t.twr_index
    into v_twr_today_pct, v_twr_today_cum_pct, v_twr_today_index
  from public.v_portfolio_twr_daily t
  where t.trading_date <= v_asof
  order by t.trading_date desc
  limit 1;

  -- Baseline indices for MTD/YTD
  select t.twr_index
    into v_baseline_index_m
  from public.v_portfolio_twr_daily t
  where t.trading_date < v_month_start
  order by t.trading_date desc
  limit 1;

  select t.twr_index
    into v_baseline_index_y
  from public.v_portfolio_twr_daily t
  where t.trading_date < v_year_start
  order by t.trading_date desc
  limit 1;

  v_baseline_index_m := coalesce(v_baseline_index_m, 1);
  v_baseline_index_y := coalesce(v_baseline_index_y, 1);

  -- Output
  asof := v_asof;

  networth_krw := v_nav_today;
  networth_daily_pct := v_nav_today_daily_pct;

  networth_mtd_pct :=
    case
      when v_nav_month_start is null or v_nav_month_start = 0 then null
      when v_nav_today is null then null
      else round(((v_nav_today / v_nav_month_start - 1) * 100)::numeric, 4)
    end;

  networth_ytd_pct :=
    case
      when v_nav_year_start is null or v_nav_year_start = 0 then null
      when v_nav_today is null then null
      else round(((v_nav_today / v_nav_year_start - 1) * 100)::numeric, 4)
    end;

  networth_cum_pct :=
    case
      when v_nav_first is null or v_nav_first = 0 then null
      when v_nav_today is null then null
      else round(((v_nav_today / v_nav_first - 1) * 100)::numeric, 4)
    end;

  assets_krw := v_assets_today;
  external_flow_today_krw := v_flow_today;

  twr_daily_pct := v_twr_today_pct;

  twr_mtd_pct :=
    case
      when v_twr_today_index is null then null
      when v_baseline_index_m = 0 then null
      else round(((v_twr_today_index / v_baseline_index_m - 1) * 100)::numeric, 4)
    end;

  twr_ytd_pct :=
    case
      when v_twr_today_index is null then null
      when v_baseline_index_y = 0 then null
      else round(((v_twr_today_index / v_baseline_index_y - 1) * 100)::numeric, 4)
    end;

  twr_cum_pct := v_twr_today_cum_pct;

  return next;
end;
$$;

grant execute on function public.get_returns_summary() to authenticated;

commit;

-- =========================================================
-- PAD v2.3.5 HOTFIX (2026-01-30) — Security/Privilege Alignment
-- - refresh_stats(uuid): prevent horizontal privilege escalation + make server-only
-- - capture_card_usage_snapshot(...): make server-only (client should not call directly)
-- =========================================================

create or replace function public.refresh_stats(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_krw_cash numeric(18,2);
  v_usd_value_krw numeric(18,2);
  v_stock_value_krw numeric(18,2);
  v_total_liability numeric(18,2);
  v_usdkrw numeric(18,6);
begin
  if p_user_id is null then
    raise exception 'p_user_id is required';
  end if;

  -- Allow:
  --  - service_role (Edge/cron/worker) to act on any user
  --  - authenticated user to act on themselves only (optional)
  if not public.is_service_role() then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Forbidden (p_user_id must equal auth.uid())';
    end if;
  end if;

  -- KRW cash total (only included accounts)
  select coalesce(sum(ab.balance), 0)
    into v_krw_cash
  from public.account_balances ab
  join public.accounts a on a.account_id = ab.account_id
  where ab.user_id = p_user_id
    and ab.currency = 'KRW'
    and a.is_include_in_networth = true;

  -- USD value in KRW (wallet)
  select coalesce(sum(est_value_krw), 0)
    into v_usd_value_krw
  from public.currency_wallet
  where user_id = p_user_id;

  -- USDKRW rate (0 if missing)
  select rate into v_usdkrw
  from public.fx_rates
  where user_id = p_user_id and pair = 'USDKRW'
  limit 1;

  if v_usdkrw is null then
    v_usdkrw := 0;
  end if;

  -- Stock value in KRW (requires stock_prices)
  select coalesce(sum(
      case
        when sp.currency = 'KRW' then h.holdings_qty * sp.price
        when sp.currency = 'USD' then h.holdings_qty * sp.price * v_usdkrw
        else 0
      end
    ), 0)
    into v_stock_value_krw
  from public.holdings h
  join public.stock_prices sp
    on sp.user_id = h.user_id and sp.stock_id = h.stock_id
  where h.user_id = p_user_id;

  -- Total liabilities
  select coalesce(sum(principal_remaining), 0)
    into v_total_liability
  from public.liabilities
  where user_id = p_user_id
    and is_include_in_networth = true;

  -- Ensure stats row exists (idempotent)
  insert into public.stats(user_id)
  values (p_user_id)
  on conflict (user_id) do nothing;

  -- Update stats
  update public.stats
  set
    krw_cash_total = v_krw_cash,
    usd_value_krw = v_usd_value_krw,
    stock_value_krw = v_stock_value_krw,
    total_liability_krw = v_total_liability,
    total_networth_krw = v_krw_cash + v_usd_value_krw + v_stock_value_krw - v_total_liability,
    updated_at = now()
  where user_id = p_user_id;
end;
$$;

-- Make refresh_stats server-only (Edge/cron/worker). Client should use Edge sync_me instead.
revoke all on function public.refresh_stats(uuid) from public;
revoke all on function public.refresh_stats(uuid) from anon;
revoke all on function public.refresh_stats(uuid) from authenticated;
grant execute on function public.refresh_stats(uuid) to service_role;

-- capture_card_usage_snapshot is a maintenance/snapshot routine. Restrict to service_role.
revoke all on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) from public;
revoke all on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) from anon;
revoke all on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) from authenticated;
grant execute on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) to service_role;

-- =========================================================
-- CRON RELEASE (OPTIONAL) — 2026-01-30
-- =========================================================

-- =========================================================
-- PAD v2.3.5 CRON (RELEASE)
-- Date: 2026-01-30
--
-- 요구 확장:
--  - extensions.pg_cron
--  - extensions.pg_net
--  - vault.supabase_vault
--
-- 실행 위치:
--  - Supabase Dashboard -> SQL Editor (한 번 실행)
--
-- 보안 모델:
--  - DB -> Edge 호출은 x-cron-secret 으로 보호
--  - Edge 내부 DB 쓰기는 SERVICE_ROLE_KEY(Edge Secret)로 수행
--
-- 배포 전제:
--  - Edge Functions: pad-market-sync / pad-recalc-worker 배포 완료
--  - Edge Function Settings: Verify JWT OFF (verify_jwt=false)
-- =========================================================

begin;

create extension if not exists pg_cron with schema extensions;
create extension if not exists pg_net  with schema extensions;
create extension if not exists supabase_vault with schema vault;

-- Vault secrets (DB side) - fill placeholders once, or set via UI and skip.
do $$
begin
  if not exists (select 1 from vault.secrets where name='SUPABASE_URL') then
    perform vault.create_secret('SUPABASE_URL', 'https://<PROJECT_REF>.supabase.co');
  end if;

  if not exists (select 1 from vault.secrets where name='SUPABASE_ANON_KEY') then
    perform vault.create_secret('SUPABASE_ANON_KEY', '<ANON_JWT>');
  end if;

  if not exists (select 1 from vault.secrets where name='CRON_SECRET') then
    perform vault.create_secret('CRON_SECRET', '<RANDOM_60_CHARS>');
  end if;
end $$;

-- jobname-based upsert (avoid jobid drift)
create or replace function public._cron_upsert_job(
  p_jobname text,
  p_schedule text,
  p_command text
) returns void
language plpgsql
security definer
set search_path = public, cron
as $$
declare
  v_jobid int;
begin
  select jobid into v_jobid from cron.job where jobname = p_jobname limit 1;

  if v_jobid is null then
    perform cron.schedule(p_jobname, p_schedule, p_command);
  else
    begin
      perform cron.alter_job(v_jobid, schedule := p_schedule, command := p_command, active := true);
    exception when undefined_function then
      perform cron.unschedule(v_jobid);
      perform cron.schedule(p_jobname, p_schedule, p_command);
    end;
  end if;
end;
$$;

-- 1) Recalc worker (every 15 minutes)
select public._cron_upsert_job(
  'pad-recalc-worker-15min',
  '*/15 * * * *',
  $cmd$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_URL')
             || '/functions/v1/pad-recalc-worker?op=run',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_ANON_KEY'),
        'x-cron-secret', (select decrypted_secret from vault.decrypted_secrets where name='CRON_SECRET')
      ),
      body := '{}'::jsonb
    ) as request_id;
  $cmd$
);

-- 2) Daily close - KR (KST 00:10 Tue-Sat => UTC 15:10 Mon-Fri)  // captures Mon-Fri market close
select public._cron_upsert_job(
  'pad-market-daily-close-kr-0010kst',
  '10 15 * * 1-5',
  $cmd$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_URL')
             || '/functions/v1/pad-market-sync?op=daily_close&market=KR',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_ANON_KEY'),
        'x-cron-secret', (select decrypted_secret from vault.decrypted_secrets where name='CRON_SECRET')
      ),
      body := '{}'::jsonb
    ) as request_id;
  $cmd$
);

-- 3) Daily close - US (KST 07:10 Tue-Sat => UTC 22:10 Mon-Fri)  // captures Mon-Fri market close
select public._cron_upsert_job(
  'pad-market-daily-close-us-0710kst',
  '10 22 * * 1-5',
  $cmd$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_URL')
             || '/functions/v1/pad-market-sync?op=daily_close&market=US',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_ANON_KEY'),
        'x-cron-secret', (select decrypted_secret from vault.decrypted_secrets where name='CRON_SECRET')
      ),
      body := '{}'::jsonb
    ) as request_id;
  $cmd$
);

-- 4) Optional: purge pg_net responses older than 7 days (weekly)
select public._cron_upsert_job(
  'pad-net-response-purge-weekly',
  '0 3 * * 0',
  $cmd$
    delete from net._http_response where created < now() - interval '7 days';
  $cmd$
);

commit;

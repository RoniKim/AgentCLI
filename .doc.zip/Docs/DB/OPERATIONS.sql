-- ============================================================================
-- PAD v2.3.5 - DB Operations Pack (COMBINED)
-- 생성일: 2026-01-30
-- 목적: Cron 설치, Smoke Test, (선택) Patch/Hotfix 단독 적용을 한 파일로 묶었습니다.
-- 주의:
-- 1) 신규 설치는 반드시 `INSTALL.sql`(DROP 포함)로 진행하세요.
-- 2) 아래 섹션들은 "필요한 것만" 실행하세요.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- [SECTION 1] CRON 설치 (선택이지만 권장)
-- 원본: PAD_v2.3.5_CRON_RELEASE_2026-01-30.sql
-- ---------------------------------------------------------------------------
-- =========================================================
-- PAD v2.3.5 CRON (RELEASE)
-- Date: 2026-01-30
--
-- 요구 확장:
--  - extensions.pg_cron
--  - extensions.pg_net
--  - vault.supabase_vault
--
-- 실행 위치:
--  - Supabase Dashboard -> SQL Editor (한 번 실행)
--
-- 보안 모델:
--  - DB -> Edge 호출은 x-cron-secret 으로 보호
--  - Edge 내부 DB 쓰기는 SERVICE_ROLE_KEY(Edge Secret)로 수행
--
-- 배포 전제:
--  - Edge Functions: pad-market-sync / pad-recalc-worker 배포 완료
--  - Edge Function Settings: Verify JWT OFF (verify_jwt=false)
-- =========================================================

begin;

create extension if not exists pg_cron with schema extensions;
create extension if not exists pg_net  with schema extensions;
create extension if not exists supabase_vault with schema vault;

-- Vault secrets (DB side) - fill placeholders once, or set via UI and skip.
do $$
begin
  if not exists (select 1 from vault.secrets where name='SUPABASE_URL') then
    perform vault.create_secret('SUPABASE_URL', 'https://<PROJECT_REF>.supabase.co');
  end if;

  if not exists (select 1 from vault.secrets where name='SUPABASE_ANON_KEY') then
    perform vault.create_secret('SUPABASE_ANON_KEY', '<ANON_JWT>');
  end if;

  if not exists (select 1 from vault.secrets where name='CRON_SECRET') then
    perform vault.create_secret('CRON_SECRET', '<RANDOM_60_CHARS>');
  end if;
end $$;

-- jobname-based upsert (avoid jobid drift)
create or replace function public._cron_upsert_job(
  p_jobname text,
  p_schedule text,
  p_command text
) returns void
language plpgsql
security definer
set search_path = public, cron
as $$
declare
  v_jobid int;
begin
  select jobid into v_jobid from cron.job where jobname = p_jobname limit 1;

  if v_jobid is null then
    perform cron.schedule(p_jobname, p_schedule, p_command);
  else
    begin
      perform cron.alter_job(v_jobid, schedule := p_schedule, command := p_command, active := true);
    exception when undefined_function then
      perform cron.unschedule(v_jobid);
      perform cron.schedule(p_jobname, p_schedule, p_command);
    end;
  end if;
end;
$$;

-- 1) Recalc worker (every 15 minutes)
select public._cron_upsert_job(
  'pad-recalc-worker-15min',
  '*/15 * * * *',
  $cmd$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_URL')
             || '/functions/v1/pad-recalc-worker?op=run',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_ANON_KEY'),
        'x-cron-secret', (select decrypted_secret from vault.decrypted_secrets where name='CRON_SECRET')
      ),
      body := '{}'::jsonb
    ) as request_id;
  $cmd$
);

-- 2) Daily close - KR (KST 00:10 Tue-Sat => UTC 15:10 Mon-Fri)  // captures Mon-Fri market close
select public._cron_upsert_job(
  'pad-market-daily-close-kr-0010kst',
  '10 15 * * 1-5',
  $cmd$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_URL')
             || '/functions/v1/pad-market-sync?op=daily_close&market=KR',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_ANON_KEY'),
        'x-cron-secret', (select decrypted_secret from vault.decrypted_secrets where name='CRON_SECRET')
      ),
      body := '{}'::jsonb
    ) as request_id;
  $cmd$
);

-- 3) Daily close - US (KST 07:10 Tue-Sat => UTC 22:10 Mon-Fri)  // captures Mon-Fri market close
select public._cron_upsert_job(
  'pad-market-daily-close-us-0710kst',
  '10 22 * * 1-5',
  $cmd$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_URL')
             || '/functions/v1/pad-market-sync?op=daily_close&market=US',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='SUPABASE_ANON_KEY'),
        'x-cron-secret', (select decrypted_secret from vault.decrypted_secrets where name='CRON_SECRET')
      ),
      body := '{}'::jsonb
    ) as request_id;
  $cmd$
);

-- 4) Optional: purge pg_net responses older than 7 days (weekly)
select public._cron_upsert_job(
  'pad-net-response-purge-weekly',
  '0 3 * * 0',
  $cmd$
    delete from net._http_response where created < now() - interval '7 days';
  $cmd$
);

commit;

-- ---------------------------------------------------------------------------
-- [SECTION 2] SMOKE TEST (기본 ROLLBACK)
-- 원본: PAD_v2.3.5_SMOKE_TEST_2026-01-30.sql
-- ---------------------------------------------------------------------------
-- =========================================================
-- PAD v2.3.5 Smoke Test (FINAL, Unambiguous)
--
-- 목적
--  - 설치/패치 이후 핵심 RPC/뷰/집계 테이블이 정상 동작하는지 빠르게 검증
--  - RLS(Authenticated) 컨텍스트에서 실제 앱과 유사하게 실행
--
-- 실행
--  - Supabase Dashboard > SQL Editor 에서 "전체 실행"
--
-- 주의
--  - 기본값은 ROLLBACK(데이터 오염 방지)
--    결과를 DB에 남기려면 마지막 ROLLBACK을 COMMIT으로 변경
-- =========================================================

begin;

-- ---------------------------------------------------------
-- 0) 테스트 유저 바인딩 (최근 생성된 유저 1명 사용)
--    - auth.users에 유저가 없으면 Auth에서 1명 생성 후 다시 실행
-- ---------------------------------------------------------
do $$
declare
  v_user_id uuid;
begin
  select id into v_user_id
  from auth.users
  order by created_at desc
  limit 1;

  if v_user_id is null then
    raise exception 'No users in auth.users. Create a user in Auth first.';
  end if;

  -- RLS 컨텍스트 주입 (트랜잭션 범위)
  perform set_config('request.jwt.claim.sub',  v_user_id::text, true);
  perform set_config('request.jwt.claim.role', 'authenticated', true);
end $$;

set local role authenticated;


-- ---------------------------------------------------------
-- 1) Preflight: "패치 적용 상태" 필수 체크 (실패 시 즉시 중단)
-- ---------------------------------------------------------

-- 1-1) refresh_stats가 현 스키마 컬럼을 참조하는지 (a.currency / a.is_include_in_stats 금지)
do $$
declare
  v_def text;
begin
  v_def := pg_get_functiondef('public.refresh_stats(uuid)'::regprocedure);
  if position('a.currency' in v_def) > 0 then
    raise exception 'refresh_stats is outdated: references a.currency. Apply FINAL patch pack or reinstall FINAL schema.';
  end if;
  if position('is_include_in_stats' in v_def) > 0 then
    raise exception 'refresh_stats is outdated: references is_include_in_stats. Apply FINAL patch pack or reinstall FINAL schema.';
  end if;
  if position('ab.currency' in v_def) = 0 then
    raise exception 'refresh_stats does not reference ab.currency. Apply FINAL patch pack or reinstall FINAL schema.';
  end if;
end $$;

-- 1-2) 레거시 오버로드가 남아 있지 않은지 (RPC 42725 방지)
do $$
begin
  if to_regprocedure('public.process_transaction_v2(timestamptz,transaction_type,numeric,currency_code,uuid,uuid,uuid,uuid,numeric,numeric,uuid,text,text,boolean,uuid,uuid,text)') is not null then
    raise exception 'Legacy overload exists: process_transaction_v2 without p_client_tx_id. Apply FINAL patch pack.';
  end if;

  if to_regprocedure('public.kis_token_decide(text)') is not null then
    raise exception 'Legacy overload exists: kis_token_decide(text). Apply FINAL patch pack.';
  end if;

  if to_regprocedure('public.ensure_account_balance_row(uuid,uuid)') is not null then
    raise exception 'Legacy overload exists: ensure_account_balance_row(uuid,uuid). Apply FINAL patch pack.';
  end if;
end $$;

-- 1-3) reverse_transaction: 이체 라벨이 '이체'로 매핑되는지 확인 (과거 '계좌_이체' 버그 방지)
select
  'patch.reverse_transaction.transfer_label_is_ok' as check_name,
  (position('v_org.type = ''이체''' in pg_get_functiondef('public.reverse_transaction(uuid,text)'::regprocedure)) > 0)
  as ok;

-- 1-4) reverse_transaction correction category: [SYSTEM] 정정 패치 적용 확인
do $$
declare
  v_def text;
begin
  v_def := pg_get_functiondef('public.reverse_transaction(uuid,text)'::regprocedure);
  if position('[SYSTEM] 정정' in v_def) = 0 then
    raise exception 'reverse_transaction correction-category patch missing. Apply PAD_v2.3.5_patch_reverse_transaction_correction_category_2026-01-30.sql';
  end if;
end $$;

-- ---------------------------------------------------------
-- 2) 테스트용 엔티티 생성 (temp table에 id 저장)
-- ---------------------------------------------------------
create temp table _smoke_ids(k text primary key, id uuid);

-- 계좌 2개
with ins as (
  insert into public.accounts(account_name, account_type, default_currency, memo)
  values ('[SMOKE] Bank A', 'Bank', 'KRW', 'smoke')
  returning account_id
)
insert into _smoke_ids(k,id)
select 'acc_a', account_id from ins;

with ins as (
  insert into public.accounts(account_name, account_type, default_currency, memo)
  values ('[SMOKE] Bank B', 'Bank', 'KRW', 'smoke')
  returning account_id
)
insert into _smoke_ids(k,id)
select 'acc_b', account_id from ins;

-- 카테고리 2개 (수입/지출)
with ins as (
  insert into public.categories(category_name, category_kind, sort_order)
  values ('[SMOKE] 급여', '수입', 0)
  returning category_id
)
insert into _smoke_ids(k,id)
select 'cat_income', category_id from ins;

with ins as (
  insert into public.categories(category_name, category_kind, sort_order)
  values ('[SMOKE] 식비', '지출', 0)
  returning category_id
)
insert into _smoke_ids(k,id)
select 'cat_expense', category_id from ins;

-- 카드 1개 (연결계좌: acc_a)
with ins as (
  insert into public.cards(card_name, payment_day, month_lag, linked_account_id)
  values ('[SMOKE] Card', 25, 1, (select id from _smoke_ids where k='acc_a'))
  returning card_id
)
insert into _smoke_ids(k,id)
select 'card_1', card_id from ins;

-- 대출 1개
with ins as (
  insert into public.liabilities(liability_name, liability_type, currency, principal_remaining)
  values ('[SMOKE] Loan', 'Credit', 'KRW', 0)
  returning liability_id
)
insert into _smoke_ids(k,id)
select 'loan_1', liability_id from ins;

-- 주식 1개(KR)
with ins as (
  insert into public.stocks(ticker, name, market, currency, note)
  values ('SMOKE-005930', '삼성전자(SMOKE)', 'KR', 'KRW', 'smoke')
  returning stock_id
)
insert into _smoke_ids(k,id)
select 'stock_kr_1', stock_id from ins;

-- ---------------------------------------------------------
-- 3) 핵심 입력 경로: process_transaction_v2 (정상 동작 + 집계/상태 테이블 갱신)
--    - 모든 호출에 p_client_tx_id 포함(명시)
--    - enum/currency는 명시적 캐스팅(unknown 방지)
-- ---------------------------------------------------------

-- 3-1) 수입 (현금 증가)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '수입'::transaction_type,
    p_amount => 1000000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_category_id => (select id from _smoke_ids where k='cat_income'),
    p_memo => '[SMOKE] income',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_income', id from tx;

-- 3-2) 지출 (현금 감소)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '지출'::transaction_type,
    p_amount => 50000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_category_id => (select id from _smoke_ids where k='cat_expense'),
    p_memo => '[SMOKE] expense',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_expense', id from tx;

-- 3-3) 이체 (A -> B)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '이체'::transaction_type,
    p_amount => 100000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_to_account_id => (select id from _smoke_ids where k='acc_b'),
    p_memo => '[SMOKE] transfer',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_transfer', id from tx;

-- 3-4) 카드 지출 (카드 결제: cash 미변동)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '지출'::transaction_type,
    p_amount => 30000::numeric,
    p_currency => 'KRW'::currency_code,
    p_card_id => (select id from _smoke_ids where k='card_1'),
    p_category_id => (select id from _smoke_ids where k='cat_expense'),
    p_memo => '[SMOKE] card_expense',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_card_expense', id from tx;

-- 3-5) 카드 대금 납부 (cash 감소, KPI 이중계상 방지)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '카드_대금'::transaction_type,
    p_amount => 30000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_card_id => (select id from _smoke_ids where k='card_1'),
    p_memo => '[SMOKE] card_payment',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_card_payment', id from tx;

-- 3-6) 주식 매수/매도 (holdings/실현손익)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '주식_매수'::transaction_type,
    p_amount => 200000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_stock_id => (select id from _smoke_ids where k='stock_kr_1'),
    p_qty => 2::numeric,
    p_memo => '[SMOKE] stock_buy',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_stock_buy', id from tx;

with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '주식_매도'::transaction_type,
    p_amount => 120000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_stock_id => (select id from _smoke_ids where k='stock_kr_1'),
    p_qty => 1::numeric,
    p_memo => '[SMOKE] stock_sell',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_stock_sell', id from tx;

-- 3-7) 환전 매수/매도 (currency_wallet)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '환전_매수'::transaction_type,
    p_amount => 130000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_qty => 100::numeric,
    p_fx_rate => 1300::numeric,
    p_memo => '[SMOKE] fx_buy',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_fx_buy', id from tx;

with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '환전_매도'::transaction_type,
    p_amount => 65000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_qty => 50::numeric,
    p_fx_rate => 1300::numeric,
    p_memo => '[SMOKE] fx_sell',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_fx_sell', id from tx;

-- 3-8) 대출 실행/상환 (liabilities)
with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '대출_실행'::transaction_type,
    p_amount => 1000000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_liability_id => (select id from _smoke_ids where k='loan_1'),
    p_memo => '[SMOKE] loan_draw',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_loan_draw', id from tx;

with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '대출_상환_원금'::transaction_type,
    p_amount => 100000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_liability_id => (select id from _smoke_ids where k='loan_1'),
    p_memo => '[SMOKE] loan_principal',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_loan_principal', id from tx;

with tx as (
  select public.process_transaction_v2(
    p_date => now(),
    p_type => '대출_상환_이자'::transaction_type,
    p_amount => 10000::numeric,
    p_currency => 'KRW'::currency_code,
    p_account_id => (select id from _smoke_ids where k='acc_a'),
    p_liability_id => (select id from _smoke_ids where k='loan_1'),
    p_memo => '[SMOKE] loan_interest',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_loan_interest', id from tx;

-- ---------------------------------------------------------
-- 4) 수정/취소 경로: edit_transaction_v2 / reverse_transaction
-- ---------------------------------------------------------
-- 4-1) 지출을 50,000 -> 60,000 으로 수정
with tx as (
  select public.edit_transaction_v2(
    p_original_transaction_id => (select id from _smoke_ids where k='tx_expense'),
    p_new_amount => 60000::numeric,
    p_edit_reason => 'SMOKE_EDIT',
    p_new_memo => '[SMOKE] expense_edited',
    p_client_tx_id => gen_random_uuid()
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_expense_edited', id from tx;

-- 4-2) 주식 매도 취소(역거래) -> 매수로 반대 거래가 생성되며 원거래는 void
with tx as (
  select public.reverse_transaction(
    p_transaction_id => (select id from _smoke_ids where k='tx_stock_sell'),
    p_reason => 'SMOKE_REVERSE'
  ) as id
)
insert into _smoke_ids(k,id) select 'tx_stock_sell_reversed', id from tx;

-- ---------------------------------------------------------
-- 5) 결과 확인(최소 기대값)
-- ---------------------------------------------------------
-- 5-1) 계좌잔액 (음수 금지 + 이체 반영)
select 'balance.acc_a' as check_name, ab.balance
from public.account_balances ab
where ab.user_id = auth.uid()
  and ab.account_id = (select id from _smoke_ids where k='acc_a')
  and ab.currency = 'KRW'::currency_code;

select 'balance.acc_b' as check_name, ab.balance
from public.account_balances ab
where ab.user_id = auth.uid()
  and ab.account_id = (select id from _smoke_ids where k='acc_b')
  and ab.currency = 'KRW'::currency_code;

-- 5-2) holdings (주식 매도 후 취소했으므로 최종 qty=2 기대)
select 'holdings.stock_kr_1' as check_name, h.holdings_qty, h.avg_buy_price
from public.holdings h
where h.user_id = auth.uid()
  and h.stock_id = (select id from _smoke_ids where k='stock_kr_1');

-- 5-3) 실현손익 테이블: 매도 후 즉시 취소했으므로 "voided 아닌" pnl이 0건이거나 0으로 정리되는지 확인
select 'stock_realized_pnl.active_rows' as check_name, count(*) as cnt
from public.stock_realized_pnl p
where p.user_id = auth.uid()
  and p.is_voided = false;

-- 5-4) 환전 지갑 (최종 foreign_held=50, invested=65,000 근처 기대)
select 'currency_wallet.usd' as check_name, w.total_foreign_held, w.total_krw_invested, w.avg_rate
from public.currency_wallet w
where w.user_id = auth.uid()
  and w.currency = 'USD'::currency_code;

-- 5-5) 대출 원금잔액 (최종 900,000 근처 기대)
select 'liability.loan_1' as check_name, l.principal_remaining
from public.liabilities l
where l.user_id = auth.uid()
  and l.liability_id = (select id from _smoke_ids where k='loan_1');

-- 5-6) 트랜잭션 뷰(사용자 표시용): void/correction 제외되어야 함
select 'v_transactions_display.count' as check_name, count(*) as cnt
from public.v_transactions_display v
where v.user_id = auth.uid()
  and (v.memo like '[SMOKE]%' or v.memo like '[REVERSAL]%' or v.memo like '[EDIT]%');

-- 5-7) 대시보드 RPC (반환 자체가 정상인지)
select 'rpc.get_dashboard.sample' as check_name, public.get_dashboard(30, true) as payload;

-- ---------------------------------------------------------
-- 6) 종료: 기본은 롤백
-- ---------------------------------------------------------
rollback;
-- commit;

-- ---------------------------------------------------------------------------
-- [SECTION 3] PATCH (Returns Summary: Networth vs TWR) - 이미 설치된 DB에만 필요
-- 원본: PAD_v2.3.5_PATCH_RETURNS_TWR_2026-01-30.sql
-- ---------------------------------------------------------------------------
begin;

-- =========================================================
-- PAD v2.3.5 Patch: Returns Summary (Networth vs Investment TWR)
-- Date: 2026-01-30
--
-- 목적
--  - "누적 순자산 증감률(NAV 기반)" 과 "입출금 제외 투자성과(TWR)"를 분리 제공
--  - 프론트(MAUI)에서 일/월/연/누적을 1회 RPC로 조회 가능
--
-- 추가/수정 객체
--  - function public.ctx_uid()
--  - view public.v_portfolio_assets_daily
--  - view public.v_external_cashflow_daily
--  - view public.v_portfolio_twr_daily
--  - function public.get_returns_summary()
--
-- 주의
--  - SQL Editor(비인증) 환경 테스트를 위해 ctx_uid()가 auth.uid()가 null이면
--    current_setting('app.user_id')를 fallback으로 사용합니다.
--  - 앱/Edge/PostgREST 환경에서는 auth.uid()가 정상 주입되므로 fallback은 영향 없습니다.
-- =========================================================

-- =========================================================
-- 0) Helper: ctx_uid()
--    - In production: auth.uid()
--    - In SQL Editor: set_config('app.user_id','<uuid>',true) 로 주입 가능
-- =========================================================
create or replace function public.ctx_uid()
returns uuid
language sql
stable
as $$
  select coalesce(
    auth.uid(),
    nullif(current_setting('app.user_id', true), '')::uuid
  );
$$;

grant execute on function public.ctx_uid() to authenticated;


-- =========================================================
-- 1) Assets daily series (KRW) with LIVE fallback
--    - snapshot: account_nav_daily 합계(포함 계좌만)
--    - live: stats(krw_cash_total + usd_value_krw + stock_value_krw)
-- =========================================================
create or replace view public.v_portfolio_assets_daily as
with u as (
  select public.ctx_uid() as user_id, (now() at time zone 'Asia/Seoul')::date as today
),
snap as (
  select
    an.user_id,
    an.trading_date,
    round(coalesce(sum(an.total_krw),0)::numeric, 2) as assets_krw,
    max(an.market_data_asof) as market_data_asof,
    max(an.source) as source,
    true as is_snapshot
  from public.account_nav_daily an
  join public.accounts a on a.account_id = an.account_id
  where an.user_id = (select u.user_id from u)
    and a.is_include_in_networth = true
  group by an.user_id, an.trading_date
),
live as (
  select
    s.user_id,
    (select u.today from u) as trading_date,
    round((s.krw_cash_total + s.usd_value_krw + s.stock_value_krw)::numeric, 2) as assets_krw,
    s.updated_at as market_data_asof,
    'LIVE'::text as source,
    false as is_snapshot
  from public.stats s
  where s.user_id = (select u.user_id from u)
    and not exists (
      select 1
      from public.account_nav_daily x
      where x.user_id = (select u.user_id from u)
        and x.trading_date = (select u.today from u)
      limit 1
    )
),
all_rows as (
  select * from snap
  union all
  select * from live
)
select * from all_rows;

grant select on public.v_portfolio_assets_daily to authenticated;


-- =========================================================
-- 2) External cashflow daily (NAV-effective flows only)
--    - include: income/expense via account (not card spend)
--    - include: card payment, loan principal/interest
--
-- 정책(기본)
--  - 외부 유입(+): 수입, 대출_실행
--  - 외부 유출(-): 지출(현금/계좌), 카드_대금, 대출_상환_원금, 대출_상환_이자
--  - 카드 사용(카드 결제 거래)은 "순자산"에 즉시 반영되지 않는 구조이므로,
--    외부흐름에서는 카드 사용이 아니라 카드_대금만 포함합니다.
-- =========================================================
create or replace view public.v_external_cashflow_daily as
with u as (select public.ctx_uid() as user_id)
select
  t.user_id,
  (t.date at time zone 'Asia/Seoul')::date as trading_date,
  round(sum(
    case
      -- 외부 유입(+)
      when t.type in ('수입','대출_실행') then
        case
          when t.currency = 'KRW' then t.amount
          else t.amount * coalesce(
            t.fx_rate,
            (select r.rate
             from public.fx_rates_daily r
             where r.user_id = t.user_id
               and r.trading_date = (t.date at time zone 'Asia/Seoul')::date
               and r.pair = 'USDKRW'
             limit 1),
            (select r2.rate
             from public.fx_rates r2
             where r2.user_id = t.user_id
               and r2.pair = 'USDKRW'
             limit 1)
          )
        end

      -- 외부 유출(-)
      when t.type in ('지출','카드_대금','대출_상환_원금','대출_상환_이자') then
        -(
          case
            when t.currency = 'KRW' then t.amount
            else t.amount * coalesce(
              t.fx_rate,
              (select r.rate
               from public.fx_rates_daily r
               where r.user_id = t.user_id
                 and r.trading_date = (t.date at time zone 'Asia/Seoul')::date
                 and r.pair = 'USDKRW'
               limit 1),
              (select r2.rate
               from public.fx_rates r2
               where r2.user_id = t.user_id
                 and r2.pair = 'USDKRW'
               limit 1)
            )
          end
        )
      else 0
    end
  )::numeric, 2) as external_flow_krw
from public.transactions t
where t.user_id = (select u.user_id from u)
  and t.is_voided = false
  and (
        (t.type in ('수입','지출') and t.account_id is not null and t.card_id is null)
     or (t.type = '카드_대금')
     or (t.type in ('대출_실행','대출_상환_원금','대출_상환_이자'))
  )
group by t.user_id, (t.date at time zone 'Asia/Seoul')::date;

grant select on public.v_external_cashflow_daily to authenticated;


-- =========================================================
-- 3) TWR daily series (assets-based) - NON-RECURSIVE / WINDOW
--
--  r_t = (A_t - A_{t-1} - Flow_t) / A_{t-1}
--  TWR Index = Π(1 + r_t) = exp( Σ ln(1 + r_t) )
--
--  - exp/ln은 double precision을 사용하므로,
--    round( , digits ) 적용을 위해 numeric 캐스팅을 포함합니다.
-- =========================================================
create or replace view public.v_portfolio_twr_daily as
with base as (
  select
    a.user_id,
    a.trading_date,
    a.assets_krw,
    coalesce(f.external_flow_krw, 0) as external_flow_krw,
    lag(a.assets_krw) over (partition by a.user_id order by a.trading_date) as prev_assets_krw
  from public.v_portfolio_assets_daily a
  left join public.v_external_cashflow_daily f
    on f.user_id = a.user_id
   and f.trading_date = a.trading_date
),
calc as (
  select
    *,
    case
      when prev_assets_krw is null or prev_assets_krw <= 0 then null
      else (assets_krw - prev_assets_krw - external_flow_krw) / prev_assets_krw
    end as twr_daily_r
  from base
),
acc as (
  select
    *,
    sum(
      case
        when twr_daily_r is null then 0::double precision
        when (1 + twr_daily_r) > 0 then ln((1 + twr_daily_r)::double precision)
        else 0::double precision
      end
    ) over (
      partition by user_id
      order by trading_date
      rows between unbounded preceding and current row
    ) as cum_ln,

    min(
      case
        when twr_daily_r is null then 1
        when (1 + twr_daily_r) > 0 then 1
        else 0
      end
    ) over (
      partition by user_id
      order by trading_date
      rows between unbounded preceding and current row
    ) as all_ok
  from calc
)
select
  user_id,
  trading_date,
  assets_krw,
  external_flow_krw,
  prev_assets_krw,
  round((assets_krw - prev_assets_krw - external_flow_krw)::numeric, 2) as pnl_ex_flow_krw,
  round((twr_daily_r * 100)::numeric, 4) as twr_daily_pct,

  case
    when all_ok = 1 then round((exp(cum_ln))::numeric, 12)
    else null
  end as twr_index,

  case
    when all_ok = 1 then round(((exp(cum_ln) - 1) * 100)::numeric, 4)
    else null
  end as twr_cum_pct
from acc;

grant select on public.v_portfolio_twr_daily to authenticated;


-- =========================================================
-- 4) Summary RPC: networth-return + TWR-return
--
-- 반환값:
--  - networth_* : v_portfolio_nav_daily 기반 (순자산 증감률)
--  - twr_*      : v_portfolio_twr_daily 기반 (입출금 제외 투자성과)
--
-- NOTE:
--  - returns table(...) 의 컬럼명이 PL/pgSQL 변수로도 존재하므로
--    내부 SELECT에서는 alias.column 형태로 완전 수식합니다(ambiguous 방지).
-- =========================================================
create or replace function public.get_returns_summary()
returns table (
  asof date,
  networth_krw numeric(18,2),
  networth_daily_pct numeric(10,4),
  networth_mtd_pct numeric(10,4),
  networth_ytd_pct numeric(10,4),
  networth_cum_pct numeric(10,4),
  assets_krw numeric(18,2),
  external_flow_today_krw numeric(18,2),
  twr_daily_pct numeric(10,4),
  twr_mtd_pct numeric(10,4),
  twr_ytd_pct numeric(10,4),
  twr_cum_pct numeric(10,4)
)
language plpgsql
set search_path = public
as $$
declare
  v_user_id uuid;
  v_asof date := (now() at time zone 'Asia/Seoul')::date;

  v_nav_today numeric(18,2);
  v_nav_today_daily_pct numeric(10,4);

  v_nav_month_start numeric(18,2);
  v_nav_year_start numeric(18,2);
  v_nav_first numeric(18,2);

  v_assets_today numeric(18,2);
  v_flow_today numeric(18,2);

  v_twr_today_pct numeric(10,4);
  v_twr_today_cum_pct numeric(10,4);
  v_twr_today_index numeric;

  v_month_start date := date_trunc('month', v_asof)::date;
  v_year_start  date := date_trunc('year',  v_asof)::date;

  v_baseline_index_m numeric := 1;
  v_baseline_index_y numeric := 1;
begin
  v_user_id := public.ctx_uid();
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  -- NAV today + daily %
  select n.nav_krw, n.delta_nav_pct
    into v_nav_today, v_nav_today_daily_pct
  from public.v_portfolio_nav_daily n
  where n.trading_date <= v_asof
  order by n.trading_date desc
  limit 1;

  -- NAV baselines
  select n.nav_krw
    into v_nav_month_start
  from public.v_portfolio_nav_daily n
  where n.trading_date >= v_month_start and n.trading_date <= v_asof
  order by n.trading_date asc
  limit 1;

  select n.nav_krw
    into v_nav_year_start
  from public.v_portfolio_nav_daily n
  where n.trading_date >= v_year_start and n.trading_date <= v_asof
  order by n.trading_date asc
  limit 1;

  select n.nav_krw
    into v_nav_first
  from public.v_portfolio_nav_daily n
  where n.trading_date <= v_asof
  order by n.trading_date asc
  limit 1;

  -- Assets today
  select a.assets_krw
    into v_assets_today
  from public.v_portfolio_assets_daily a
  where a.trading_date <= v_asof
  order by a.trading_date desc
  limit 1;

  -- External flow today
  select f.external_flow_krw
    into v_flow_today
  from public.v_external_cashflow_daily f
  where f.trading_date = v_asof
  limit 1;

  v_flow_today := coalesce(v_flow_today, 0);

  -- TWR today
  select t.twr_daily_pct, t.twr_cum_pct, t.twr_index
    into v_twr_today_pct, v_twr_today_cum_pct, v_twr_today_index
  from public.v_portfolio_twr_daily t
  where t.trading_date <= v_asof
  order by t.trading_date desc
  limit 1;

  -- Baseline indices for MTD/YTD
  select t.twr_index
    into v_baseline_index_m
  from public.v_portfolio_twr_daily t
  where t.trading_date < v_month_start
  order by t.trading_date desc
  limit 1;

  select t.twr_index
    into v_baseline_index_y
  from public.v_portfolio_twr_daily t
  where t.trading_date < v_year_start
  order by t.trading_date desc
  limit 1;

  v_baseline_index_m := coalesce(v_baseline_index_m, 1);
  v_baseline_index_y := coalesce(v_baseline_index_y, 1);

  -- Output
  asof := v_asof;

  networth_krw := v_nav_today;
  networth_daily_pct := v_nav_today_daily_pct;

  networth_mtd_pct :=
    case
      when v_nav_month_start is null or v_nav_month_start = 0 then null
      when v_nav_today is null then null
      else round(((v_nav_today / v_nav_month_start - 1) * 100)::numeric, 4)
    end;

  networth_ytd_pct :=
    case
      when v_nav_year_start is null or v_nav_year_start = 0 then null
      when v_nav_today is null then null
      else round(((v_nav_today / v_nav_year_start - 1) * 100)::numeric, 4)
    end;

  networth_cum_pct :=
    case
      when v_nav_first is null or v_nav_first = 0 then null
      when v_nav_today is null then null
      else round(((v_nav_today / v_nav_first - 1) * 100)::numeric, 4)
    end;

  assets_krw := v_assets_today;
  external_flow_today_krw := v_flow_today;

  twr_daily_pct := v_twr_today_pct;

  twr_mtd_pct :=
    case
      when v_twr_today_index is null then null
      when v_baseline_index_m = 0 then null
      else round(((v_twr_today_index / v_baseline_index_m - 1) * 100)::numeric, 4)
    end;

  twr_ytd_pct :=
    case
      when v_twr_today_index is null then null
      when v_baseline_index_y = 0 then null
      else round(((v_twr_today_index / v_baseline_index_y - 1) * 100)::numeric, 4)
    end;

  twr_cum_pct := v_twr_today_cum_pct;

  return next;
end;
$$;

grant execute on function public.get_returns_summary() to authenticated;

commit;

-- ---------------------------------------------------------------------------
-- [SECTION 4] HOTFIX (Security/Privilege Alignment) - 이미 설치된 DB에만 필요
-- 원본: PAD_v2.3.5_HOTFIX_SECURITY_PRIVS_2026-01-30.sql
-- ---------------------------------------------------------------------------
-- =========================================================
-- PAD v2.3.5 HOTFIX (2026-01-30) — Security/Privilege Alignment
-- - refresh_stats(uuid): prevent horizontal privilege escalation + make server-only
-- - capture_card_usage_snapshot(...): make server-only (client should not call directly)
-- =========================================================

create or replace function public.refresh_stats(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_krw_cash numeric(18,2);
  v_usd_value_krw numeric(18,2);
  v_stock_value_krw numeric(18,2);
  v_total_liability numeric(18,2);
  v_usdkrw numeric(18,6);
begin
  if p_user_id is null then
    raise exception 'p_user_id is required';
  end if;

  -- Allow:
  --  - service_role (Edge/cron/worker) to act on any user
  --  - authenticated user to act on themselves only (optional)
  if not public.is_service_role() then
    if auth.uid() is null or auth.uid() <> p_user_id then
      raise exception 'Forbidden (p_user_id must equal auth.uid())';
    end if;
  end if;

  -- KRW cash total (only included accounts)
  select coalesce(sum(ab.balance), 0)
    into v_krw_cash
  from public.account_balances ab
  join public.accounts a on a.account_id = ab.account_id
  where ab.user_id = p_user_id
    and ab.currency = 'KRW'
    and a.is_include_in_networth = true;

  -- USD value in KRW (wallet)
  select coalesce(sum(est_value_krw), 0)
    into v_usd_value_krw
  from public.currency_wallet
  where user_id = p_user_id;

  -- USDKRW rate (0 if missing)
  select rate into v_usdkrw
  from public.fx_rates
  where user_id = p_user_id and pair = 'USDKRW'
  limit 1;

  if v_usdkrw is null then
    v_usdkrw := 0;
  end if;

  -- Stock value in KRW (requires stock_prices)
  select coalesce(sum(
      case
        when sp.currency = 'KRW' then h.holdings_qty * sp.price
        when sp.currency = 'USD' then h.holdings_qty * sp.price * v_usdkrw
        else 0
      end
    ), 0)
    into v_stock_value_krw
  from public.holdings h
  join public.stock_prices sp
    on sp.user_id = h.user_id and sp.stock_id = h.stock_id
  where h.user_id = p_user_id;

  -- Total liabilities
  select coalesce(sum(principal_remaining), 0)
    into v_total_liability
  from public.liabilities
  where user_id = p_user_id
    and is_include_in_networth = true;

  -- Ensure stats row exists (idempotent)
  insert into public.stats(user_id)
  values (p_user_id)
  on conflict (user_id) do nothing;

  -- Update stats
  update public.stats
  set
    krw_cash_total = v_krw_cash,
    usd_value_krw = v_usd_value_krw,
    stock_value_krw = v_stock_value_krw,
    total_liability_krw = v_total_liability,
    total_networth_krw = v_krw_cash + v_usd_value_krw + v_stock_value_krw - v_total_liability,
    updated_at = now()
  where user_id = p_user_id;
end;
$$;

-- Make refresh_stats server-only (Edge/cron/worker). Client should use Edge sync_me instead.
revoke all on function public.refresh_stats(uuid) from public;
revoke all on function public.refresh_stats(uuid) from anon;
revoke all on function public.refresh_stats(uuid) from authenticated;
grant execute on function public.refresh_stats(uuid) to service_role;

-- capture_card_usage_snapshot is a maintenance/snapshot routine. Restrict to service_role.
revoke all on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) from public;
revoke all on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) from anon;
revoke all on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) from authenticated;
grant execute on function public.capture_card_usage_snapshot(uuid, date, timestamptz, text) to service_role;

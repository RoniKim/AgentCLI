## Edge API
- 원본: `EDGE_API.FINAL.md`

## Edge API (pad-market-sync / pad-recalc-worker) — v2.3.5 (2026-01-30)

이 문서는 **MAUI(클라이언트)**가 호출하는 Edge API와 **서버 전용(Cron/운영)** 호출을 명확히 분리합니다.

---

### 공통 보안 규칙 (필수)
- **클라이언트(MAUI)**
  - `Authorization: Bearer <user_access_token>` 로만 호출합니다.
  - **CRON_SECRET / SERVICE_ROLE_KEY는 절대 포함하지 않습니다.**
- **서버 전용(Cron/운영)**
  - `x-cron-secret: <CRON_SECRET>` 헤더가 반드시 필요합니다.
  - body에 `user_id` 등 운영 파라미터를 포함할 수 있습니다.
- Edge Function 설정
  - 운영상 `verify_jwt=false`로 배포할 수 있으나, 이 경우 **(1) user-mode는 Authorization 검사**, **(2) server-mode는 x-cron-secret 검사**가 필수입니다.

---

### 1) pad-market-sync

#### 엔드포인트
- `POST /functions/v1/pad-market-sync?op=<op>&...`

#### op=ensure_stock (user-mode / server-mode)
**목적**: ticker를 `stocks`에 등록/정규화하고, 가능하면 **현재가**를 `stock_prices`에 저장합니다.

##### 요청
- Query: `op=ensure_stock`
- Body(JSON)
  - `ticker` (string, 필수)
  - `market` ("KR"|"US", 필수)
  - `name` (string|null, 선택) — 깨진 한글(모지바케) 대체용
  - `note` (string|null, 선택)
  - **server-mode 전용**
    - `user_id` (uuid, 필수)
    - `force_refresh` (bool, 선택) — 가격 캐시 무시
    - `price_ttl_seconds` (int, 선택, 기본 60) — 가격 캐시 TTL

##### 호출 모드
- **user-mode (MAUI)**: `Authorization: Bearer ...`
  - KR: 종목명/현재가를 KIS에서 조회해 저장(가능한 한 정확)
  - US: KIS 환경 제약이 있으면 실패할 수 있음(`KIS_ENV=vts`에서 US 조회 불가)
- **server-mode (Cron/운영)**: `x-cron-secret` + body.user_id

##### 응답 (공통)
```json
{
  "ok": true,
  "mode": "user|server",
  "stock": { "stock_id": "...", "ticker": "...", "market": "KR|US", "currency": "KRW|USD", ... },
  "latestPrice": 12345.67
}
```
- 실패 시
```json
{ "ok": false, "error": "..." }
```

---

#### op=sync_me (MAUI 수동 동기화)
**목적**: 사용자가 “지금 동기화”를 눌렀을 때, 본인 데이터만 최신으로 만듭니다.

##### 요청
- Query
  - `op=sync_me`
  - `market=KR|US|ALL` (선택, 기본 ALL)
- Headers: `Authorization: Bearer <user_access_token>`
- Body: 없음 (권장)

##### 동작
1) FX(USDKRW) 조회 → `fx_rates` upsert  
2) USD 지갑 재평가(`currency_wallet`)  
3) 보유종목 현재가 갱신(`stock_prices`)  
4) `refresh_stats(p_user_id)` 실행 (**server-only 권장; Edge가 service_role로 호출**)
5) `market_data_sync_runs`에 run log 업데이트

> ⚠️ **sync_me는 “스냅샷(daily)”을 만들지 않습니다.**  
> 일별 스냅샷/월 KPI 확정은 `daily_close`(서버 배치)에서 수행합니다.

##### 응답
- 정상 완료
```json
{
  "ok": true,
  "mode": "manual",
  "status": "SUCCESS|PARTIAL",
  "run_id": "...",
  "market": "ALL",
  "market_data_asof": "2026-01-30T00:00:00Z",
  "usdkrw": 1325.12,
  "counts": { "updatedWallet": 1, "updatedStocks": 5 },
  "errorCount": 0,
  "errors": []
}
```

- 쿨다운 (60초 룰)
```json
{
  "ok": true,
  "skipped": true,
  "reason": "cooldown",
  "wait_ms": 12345,
  "last_run_id": "..."
}
```

- 진행중 가드(다른 기기/탭에서 실행중으로 판단)
```json
{
  "ok": true,
  "skipped": true,
  "reason": "in_progress",
  "run_id": "...",
  "since_ms": 54321
}
```

- 실패
```json
{ "ok": false, "status": "FAILED", "run_id": "...", "error": "...", "errors": ["..."] }
```

---

#### op=sync (server-only, 전체 사용자 배치)
- Query: `op=sync&market=KR|US|ALL`
- Headers: `x-cron-secret: <CRON_SECRET>`
- 목적: 운영 배치 동기화 (주로 Daily Close 전/후 보조)

---

#### op=daily_close (server-only, 장마감 확정)
- Query: `op=daily_close&market=KR|US`
- Headers: `x-cron-secret: <CRON_SECRET>`
- 목적:
  - 장마감 기준으로 **일별 종가/환율(데일리) 저장**
  - 일별 NAV/계좌/종목 NAV 스냅샷 캡처
  - 월 수익률/지표 등 파생값 갱신(서버 전용 RPC)
- 결과는 `market_data_sync_runs`/각 daily 테이블로 남습니다.

---

### 2) pad-recalc-worker (server-only)

#### 엔드포인트
- `POST /functions/v1/pad-recalc-worker?op=run`
- Headers: `x-cron-secret: <CRON_SECRET>`

#### 동작 요약
- `daily_snapshot_recalc_queue`에서 날짜를 모아서 사용자별 **연속 구간(contiguous range)**으로 그룹화 후,
  `rebuild_daily_snapshots(p_user_id, p_from_date, p_to_date, p_source)`를 호출합니다.

#### 응답 예시
```json
{
  "ok": true,
  "today_kst": "2026-01-30",
  "users": 2,
  "processed": [
    {
      "user_id": "...",
      "dates": 12,
      "groups": [{ "from": "2026-01-01", "to": "2026-01-12", "count": 12, "ok": true }],
      "success": 12,
      "fail": 0
    }
  ]
}
```

---

### 장애 시그널(현장에서 바로 보는 기준)
- 401: 인증 누락
  - user-mode: Authorization 누락/만료
  - server-mode: `x-cron-secret` 불일치
- 500: env 누락(SERVICE_ROLE_KEY 등), DB RPC 오류, 외부 API 실패(KIS/FX)
- PARTIAL: 외부 API 일부 실패(주로 US 시세 조회 제약) — errors[]를 UI에서 요약 표기 권장

---
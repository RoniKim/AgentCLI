## 보안/설정(Secrets) & 환경
- 원본: `SECRETS_AND_CONFIG.md`

## Secrets & Config

### 1) Edge Secrets (Supabase Dashboard → Edge Functions → Secrets)
필수:
- `SERVICE_ROLE_KEY`
- `CRON_SECRET`
- `KIS_APP_KEY`
- `KIS_APP_SECRET`
- `KIS_TOKEN_CRYPTO_KEY`

선택:
- `KIS_ENV` : `prod`(기본) / `vts`
- `RECALC_MAX_USERS` : recalc-worker 1회 실행 시 최대 유저 수 (기본 20)
- `RECALC_MAX_DATES_PER_USER` : 유저당 최대 날짜 수 (기본 31)

참고:
- `SUPABASE_URL`, `SUPABASE_ANON_KEY`는 Supabase Edge 런타임에서 기본 제공되는 경우가 많습니다.
  (제공되지 않는 환경이면 별도 주입 필요)

### 2) DB Vault Secrets (CRON 스크립트가 생성/참조)
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `CRON_SECRET`

CRON은 DB가 Edge로 HTTP 호출할 때 `Authorization: Bearer <ANON_KEY>`를 넣어 호출합니다.
(Verify JWT OFF 상태에서 동작하지만, 요청 라우팅 및 추적을 위해 유지)

### 3) Verify JWT 설정
- `pad-market-sync`: Verify JWT **OFF**
- `pad-recalc-worker`: Verify JWT **OFF**


## 예외/에러 규약
- 원본: `EXCEPTIONS.md`

## 기존 문서 재사용 예외사항

아래 파일들은 “기능 정의/UX/흐름”이 중심이며, 이번 RELEASE의 파일명/권한 하드닝과 충돌하지 않아 **그대로 재사용**합니다.

- `PAD_v2.3.5_기능정의서_FULL_2026-01-29.md`
- `PAD_v2.3.5_기능설계서_FULL_2026-01-29.md`

아래는 **참고자료로만 유지**합니다(단일 진실 아님).
- 한국투자증권 오픈API 전체 문서(xlsx)

아래는 RELEASE에서 **새로 작성한 문서**가 기준입니다.
- `README.md`
- `EDGE_API.md`
- `SECRETS_AND_CONFIG.md`
- `OPS_RUNBOOK.md`

---
---
# BACKLOG

- [x] T1 Fix mobile sidebar overlay + backdrop in CSS and MainLayout
- [x] T2 Fix Delete methods missing CancellationToken in ApiService
- [x] T3 Add RadzenDataGrid mobile column hiding CSS + apply to key grids
- [x] T4 Extract DashboardSyncCard component from Dashboard.razor
- [x] T5 Add empty state fallback to Cards chart sections + loading states


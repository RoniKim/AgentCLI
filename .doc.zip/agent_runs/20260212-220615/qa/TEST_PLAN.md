# QA Test Plan - Cycle 004
**Date**: 2026-02-12
**Platform**: Windows 10+ (dev), Android (target)
**Build Status**: ✅ Passing (30 warnings, 0 errors)

---

## Overview

This test plan covers validation for the three most recently completed development tasks:

**Completed Tasks**:
- **T1**: Calendar quick-add button and truncation warning fix
- **T2**: Portfolio add-stock cancel warning and Reports heatmap accessibility
- **T3**: Sync cooldown dynamic value from EdgeResponse

---

## 1. Calendar Page Enhancements (T1) - P1

### 1.1 Quick-Add Transaction Button
**File**: `Components/Pages/Calendar.razor`

**Test Steps**:
1. Navigate to `/calendar`
2. Select any date in the calendar view
3. Verify '+' icon button appears next to selected date (e.g., "2026년 2월 12일 [+]")
4. Click the '+' button
   - [ ] Navigates to `/transactions/new?date=YYYY-MM-DD`
   - [ ] Date parameter matches selected calendar date
5. Verify button is disabled when `_isLoading = true`
6. Test with different dates (start/middle/end of month)

**Pass Criteria**: Quick-add button navigates correctly with date pre-filled

---

### 1.2 Truncation Warning Text Fix
**File**: `Components/Pages/Calendar.razor`

**Test Steps**:
1. Create test scenario with >5,000 transactions in a month
   - OR temporarily modify `maxBatches` to 1 for testing (1,000 limit)
2. Navigate to that month in Calendar
3. Verify warning displays: **"5,000건 초과 — 합계가 정확하지 않을 수 있습니다"**
   - [ ] Text shows "5,000건" (not "2,000건")
   - [ ] Warning icon present
   - [ ] `.text-warning` class applied

**Pass Criteria**: Warning accurately reflects 5,000 transaction limit

---

## 2. Portfolio & Reports Improvements (T2) - P0/P1

### 2.1 Portfolio Add-Stock Cancel Confirmation
**File**: `Components/Pages/Portfolio.razor`

**Test Steps**:

**Test Case 1 - With Data (should warn)**:
1. Navigate to `/portfolio`
2. Click "종목 추가" button
3. Enter ticker (e.g., "005930") in 티커 field
4. Click "취소" button
   - [ ] ConfirmDialog appears with message: "입력한 내용을 취소하시겠습니까?"
   - [ ] Dialog has "취소" (confirm) and "계속 작성" (cancel) buttons
5. Click "취소" in dialog
   - [ ] Form closes
   - [ ] `_newTicker` field cleared

**Test Case 2 - Without Data (no warning)**:
1. Click "종목 추가" again
2. Leave ticker field empty/blank
3. Click "취소" button
   - [ ] Form closes immediately (no dialog)

**Test Case 3 - Continue Editing**:
1. Enter ticker, click cancel
2. In confirmation dialog, click "계속 작성"
   - [ ] Dialog closes
   - [ ] Form remains open
   - [ ] Entered ticker preserved

**Pass Criteria**: Confirmation only shown when data exists, prevents accidental data loss

---

### 2.2 Reports Heatmap Accessibility (WCAG 2.1 AA)
**File**: `Components/Pages/Reports.razor`

**Test Steps**:

**Visual Indicators**:
1. Navigate to `/reports` → "성과" tab
2. Scroll to "월별 수익률 히트맵" section
3. Verify directional indicators:
   - [ ] Positive returns: "▲ 2.5%" format
   - [ ] Negative returns: "▼ -1.2%" format
   - [ ] Zero returns: "— 0.0%" format
4. Verify space after indicator for readability

**Screen Reader Test**:
1. Enable screen reader (NVDA/JAWS/VoiceOver)
2. Tab through heatmap cells
   - [ ] Each cell announces: "MM-YY: 수익률 X.XX%"
   - [ ] aria-label provides complete context

**Colorblind Accessibility**:
1. Use browser colorblind simulation:
   - Chrome DevTools → Rendering → Emulate vision deficiencies
2. Test with protanopia, deuteranopia, tritanopia
   - [ ] Directional indicators (▲/▼/—) remain visible
   - [ ] Information not conveyed by color alone

**Tooltip Test**:
1. Hover over heatmap cells
   - [ ] Tooltip shows month and percentage (existing `title` attribute)

**Pass Criteria**: WCAG 2.1 Level AA compliant (Use of Color, Name/Role/Value)

---

## 3. Sync Page Dynamic Cooldown (T3) - P1

### 3.1 EdgeResponse CooldownMinutes Property
**Files**: `Models/EdgeResponse.cs`, `BudgetBook.Tests/EdgeResponseTests.cs`

**Unit Test Verification**:
```bash
dotnet test --filter "FullyQualifiedName~EdgeResponseTests"
```
- [ ] All 23 tests pass (including 4 new cooldown_minutes tests)
- [ ] `Deserialize_CooldownMinutes_MapsFromSnakeCase()` passes
- [ ] `Deserialize_CooldownMinutes_MissingFieldDefaultsNull()` passes
- [ ] `CooldownMinutes_RoundTrip_PreservedAfterSerialization()` passes
- [ ] `CooldownMinutes_Null_SerializesCorrectly()` passes

**Pass Criteria**: EdgeResponse deserializes `cooldown_minutes` JSON field correctly

---

### 3.2 Sync Page Dynamic Cooldown Message
**File**: `Components/Pages/Sync.razor`

**Test Steps**:

**Scenario 1 - Edge Function returns cooldown_minutes**:
1. Navigate to `/sync`
2. Trigger manual sync (KR or US)
3. Within cooldown period, trigger another sync immediately
4. **If Edge Function returns `cooldown_minutes: 3`**:
   - [ ] Error toast shows: "3분 쿨다운 중입니다. 잠시 후 다시 시도하세요."
   - [ ] Message uses dynamic value (not hardcoded "5분")

**Scenario 2 - Edge Function does NOT return field**:
1. Same steps as above
2. **If Edge Function response lacks `cooldown_minutes`**:
   - [ ] Fallback message: "5분 쿨다운 중입니다. 잠시 후 다시 시도하세요."
   - [ ] Uses null-coalescing operator default (5 minutes)

**Edge Function Response Examples**:
```json
// With cooldown_minutes
{"ok": true, "skipped": true, "reason": "cooldown", "cooldown_minutes": 3}

// Without cooldown_minutes (fallback to 5)
{"ok": true, "skipped": true, "reason": "cooldown"}
```

**Pass Criteria**: Cooldown message dynamic with sensible fallback

---

## 4. Regression Testing (Smoke Test)

**Core Flows** (verify no breakage):
- [ ] Calendar: Date selection, transaction list, month navigation
- [ ] Portfolio: Holdings display, add stock form, stock removal
- [ ] Reports: Performance tab, heatmap rendering, tooltips
- [ ] Sync: Manual sync triggers (KR/US), sync history display
- [ ] TransactionEntry: Form loads, date picker works, save succeeds

**Pass Criteria**: No existing functionality broken

---

## 5. Build & Unit Tests

**Build Gate**:
```bash
cd "D:\006. Budgetbook"
dotnet clean && dotnet build
```
- [ ] Exit code: 0
- [ ] Build errors: 0
- [ ] Build warnings: ≤30 (currently 30)

**Unit Test Gate**:
```bash
dotnet test BudgetBook.Tests/BudgetBook.Tests.csproj
```
- [ ] All tests pass (no failures)
- [ ] EdgeResponseTests: 23/23 pass (including new CooldownMinutes tests)

**Pass Criteria**: Build clean, all tests green

---

## 6. Accessibility Compliance (T2 Focus)

### WCAG 2.1 Level AA Checklist

**1.4.1 Use of Color**:
- [ ] Reports heatmap has directional indicators (▲/▼/—)
- [ ] Color not sole means of conveying information

**4.1.2 Name, Role, Value**:
- [ ] Heatmap cells have aria-labels
- [ ] Screen readers announce full context

**2.1.1 Keyboard**:
- [ ] Quick-add button keyboard accessible (Tab + Enter)
- [ ] Portfolio cancel button keyboard accessible

**Pass Criteria**: No accessibility regressions, heatmap fully accessible

---

## 7. Cross-Platform Testing

### Windows (Development)
**Platform**: Windows 10/11, .NET 9.0

**Test Environment**:
- [ ] Run with `dotnet run -f net9.0-windows10.0.19041.0`
- [ ] Test all sections 1-4 above
- [ ] Verify browser console: no JS errors

**Pass Criteria**: All features work on Windows

---

### Android (Target Platform)
**Prerequisites**:
- Android SDK 34+
- MAUI Android workload installed
- Emulator or physical device

**Build APK**:
```bash
dotnet build -f net9.0-android -c Release
```

**Deploy & Test**:
- [ ] APK installs successfully
- [ ] Quick-add button touch target ≥44px
- [ ] Heatmap indicators visible on mobile screen
- [ ] Cooldown toast notification displays correctly
- [ ] Android back button works

**Pass Criteria**: No platform-specific crashes

---

## 8. Performance Spot Check

**Page Load Times** (Windows, good connection):
- [ ] Calendar page: <2s
- [ ] Portfolio page: <2s
- [ ] Reports page (with heatmap): <3s
- [ ] Sync page: <1s

**User Interaction**:
- [ ] Quick-add button click: <200ms navigation
- [ ] Portfolio cancel dialog: <100ms open
- [ ] Heatmap cell hover tooltip: <50ms display

**Pass Criteria**: No performance regression vs previous cycle

---

## 9. Test Execution Log

| Section | Status | Tester | Date | Notes |
|---------|--------|--------|------|-------|
| 1. Calendar (T1) | ⬜ Pending | | | |
| 2. Portfolio & Reports (T2) | ⬜ Pending | | | |
| 3. Sync Cooldown (T3) | ⬜ Pending | | | |
| 4. Regression | ⬜ Pending | | | |
| 5. Build & Tests | ⬜ Pending | | | |
| 6. Accessibility | ⬜ Pending | | | |
| 7. Cross-Platform | ⬜ Pending | | | |
| 8. Performance | ⬜ Pending | | | |

**Legend**: ✅ Pass | ❌ Fail | ⚠️ Warning | ⬜ Not Started | 🔄 In Progress

---

## 10. Known Issues & Warnings

### Pre-Existing Warnings (30 total)
- **CS8602** null reference warnings (28) - Radzen binding patterns, safe
- **CS1998** async without await (2) - intentional event handlers
- **Status**: Not blockers, address in future cycle

### Follow-Up Items (Out of Scope)
1. **TransactionEntry date query parameter**: Quick-add button navigation works, but TransactionEntry may need updates to handle `?date=` query parameter
2. **Heatmap keyboard navigation**: Currently not focusable, consider Tab navigation in future
3. **Portfolio cancel confirmation for other forms**: Currently only add-stock, could extend to edit forms

---

## Pass Criteria Summary

✅ **T1 Calendar**: Quick-add button navigates correctly, warning text shows "5,000건"
✅ **T2 Portfolio**: Cancel confirmation works, only shown when data exists
✅ **T2 Reports**: Heatmap has ▲/▼/— indicators and aria-labels, WCAG AA compliant
✅ **T3 Sync**: Cooldown message dynamic (fallback to 5 min), EdgeResponse tests pass
✅ **Build**: 0 errors, ≤30 warnings, all tests pass
✅ **Regression**: Core flows work on Windows
🔄 **Android**: Pending APK build and deployment test

---

## Quick Test Commands

```bash
# Full build check
cd "D:\006. Budgetbook"
dotnet clean && dotnet build

# Unit tests
dotnet test BudgetBook.Tests/BudgetBook.Tests.csproj

# EdgeResponse tests only
dotnet test --filter "FullyQualifiedName~EdgeResponseTests"

# Run Windows app
dotnet run -f net9.0-windows10.0.19041.0

# Build Android APK
dotnet build -f net9.0-android -c Release
```

---

**QA Status**: ⬜ **Ready for Testing**
**Next Actions**: Execute manual tests, validate on Windows + Android, report any issues

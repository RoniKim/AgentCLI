# T41: Add Reports page CSV export

**Files changed:** `Helpers/FormatHelpers.cs`, `Components/Pages/Reports.razor`

**What:** Added CSV export button to Reports page header. Exports active tab data (spending/NAV/returns) using BOM+CsvEscape pattern consistent with Transactions and Portfolio exports. Button disabled when loading or data empty. Added `BuildSpendingCsv`, `BuildReturnsCsv`, `BuildNavCsv` to FormatHelpers.

**Validate:** Open Reports page → load data → click CSV button on each tab → verify CSV file opens with correct columns.

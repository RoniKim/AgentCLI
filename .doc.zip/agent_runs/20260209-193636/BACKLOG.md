# BACKLOG

- [x] T54 Add accessibility improvements to shared components and page headers
- [x] T55 Add sorting options and currency grouping toggle to Accounts page
- [x] T56 Add XML doc comments to EdgeService, ConnectivityService, AuthService, and SupabaseService
- [x] T57 Add unit tests for TransactionGrid edge cases and Calendar navigation logic
- [x] T58 Add search filter and holdings count summary to Portfolio page
- [x] T53 Add expandable sync run detail view to Sync page


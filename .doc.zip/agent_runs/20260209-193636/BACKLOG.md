# BACKLOG

- [x] T38 Replace BuildPortfolioCsv reflection with strongly-typed overload and add tests
- [x] T39 Add keyboard shortcut hints and pass CancellationToken to LoginAsync
- [x] T40 Add CSV export to Accounts page and search filter to Categories page
- [ ] T41 Add Reports page CSV export for spending and returns data
- [ ] T42 Add unit tests for CSV export methods and date range quick-select logic


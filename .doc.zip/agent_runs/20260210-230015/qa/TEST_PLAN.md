# QA Test Plan — MAUI Blazor Hybrid (Windows + Android)

**Scope:** Frontend-only verification
**Date:** 2026-02-10
**Target:** BudgetBook v1.0 (net10.0)

## 1. Build & Launch

### Windows
- [ ] Build succeeds (`dotnet build -f net10.0-windows10.0.19041.0`)
- [ ] No CS errors/warnings
- [ ] App launches without crash
- [ ] Login page loads

### Android
- [ ] Build succeeds (`dotnet build -f net10.0-android`)
- [ ] APK installs on emulator/device
- [ ] App launches without crash
- [ ] Login page loads

## 2. Auth Flow (P0)

### Login
- [ ] Valid credentials → Dashboard redirect
- [ ] Invalid credentials → error toast
- [ ] Network offline → error message

### Session Management
- [ ] Token auto-refresh (check after 5min idle)
- [ ] 401 response → auto logout + redirect to login
- [ ] Logout button → clears session + redirect

## 3. Core Pages (P0)

### Dashboard
- [ ] Stats cards display (net worth, cash, stocks, debt)
- [ ] Recent transactions table shows
- [ ] Returns summary card renders
- [ ] Sync badge shows last sync status
- [ ] Manual refresh updates data

### Transactions
- [ ] List loads with pagination
- [ ] Filter panel works (date range, type, account)
- [ ] Search by memo works
- [ ] Transaction grid renders properly

### TransactionEntry
- [ ] All 9 transaction types selectable
- [ ] Field visibility changes per type:
  - 수입/지출: account, category, amount
  - 이체: from_account, to_account, amount
  - 매수/매도: account, stock, quantity, price
  - FX_매수/FX_매도: account, fx_rate field
  - 배당금: account, stock, amount
- [ ] Submit → success toast + navigate back
- [ ] Validation errors shown inline

### Portfolio
- [ ] Holdings table displays
- [ ] PnL columns show (amount, percentage, color-coded)
- [ ] "Add Stock" dialog functional (if implemented)

### Accounts
- [ ] Account list loads
- [ ] Create account → saved
- [ ] Edit account → updated
- [ ] Delete account → removed (if 0 transactions)

### Categories
- [ ] Category list loads (does NOT crash)
- [ ] Transaction count displays
- [ ] Delete button only for categories with 0 transactions
- [ ] Delete → ConfirmDialog → removed

### Sync
- [ ] Manual sync button triggers EdgeService.SyncMeAsync
- [ ] Sync status updates (started → success/failed)
- [ ] Cooldown prevents duplicate requests
- [ ] Sync history table shows runs

### Calendar
- [ ] Date picker renders
- [ ] Daily transactions load for selected date
- [ ] Month summary card displays (income/expense/net)
- [ ] Date badges show daily totals (if implemented)

### Reports
- [ ] Nav chart renders
- [ ] Returns chart renders
- [ ] Date range picker functional

### Settings
- [ ] App version displays
- [ ] Last sync time shows
- [ ] Profile layout renders properly (check alignment)

## 4. UI/UX (P0-P1)

### Error Handling
- [ ] ErrorToast component present on all pages
- [ ] Network failures → NetworkErrorBanner + retry button
- [ ] Server errors (5xx) → user-friendly message + retry
- [ ] Validation errors (4xx) → field-level messages

### Loading States
- [ ] SkeletonLoader shows during data fetch
- [ ] Async buttons disable + spinner during action
- [ ] Page state: Loading → Ready → Error flow works

### Design System
- [ ] All pages use .premium-card glassmorphism
- [ ] CSS variables used (no hardcoded colors)
- [ ] Radzen Material theme applied
- [ ] Page fade-in animations present
- [ ] Card hover effects work

### Mobile/Responsive (P1)
- [ ] Windows: sidebar always visible
- [ ] Android: sidebar collapsible at <641px
- [ ] Forms stack vertically on narrow screens
- [ ] Calendar switches to single column on mobile

## 5. Data Integrity (P0)

### Security Policy
- [ ] No `service_role` or `cron_secret` in client code
- [ ] EdgeService uses user JWT only
- [ ] AppConfig exposes only `SupabaseUrl`, `SupabaseAnonKey`

### API Integration
- [ ] All RPC calls use correct DTOs
- [ ] TransactionRequestDto validates required fields per type
- [ ] Dashboard models map correctly (sync/kis/nav sub-objects)
- [ ] PortfolioNavDailyDto includes delta_krw/delta_pct

## 6. Critical Bug Checks (P0)

- [ ] Categories page does NOT crash on load
- [ ] Dashboard sync error handled gracefully
- [ ] Sidebar hover does NOT flash/flicker
- [ ] Profile layout aligned properly
- [ ] All pages implement IDisposable + CancellationToken

## 7. Smoke Test (Quick Pass)

**Windows (5 min):**
1. Launch → Login → Dashboard loads
2. Add 1 income transaction → saved
3. Navigate to Portfolio → no crash
4. Navigate to Categories → no crash
5. Logout → returns to login

**Android (5 min):**
1. Install APK → Launch → Login → Dashboard loads
2. Add 1 expense transaction → saved
3. Navigate to Calendar → date picker works
4. Navigate to Sync → manual sync works
5. Logout → returns to login

---

## Backend Requests (Out of Scope)

_Record any backend/API gaps found during testing in NOTES.md as "Backend Request"._

---

## Test Execution Notes

- Test on Windows 10/11 (net10.0-windows10.0.19041.0)
- Test on Android Emulator API 24+ or physical device (net10.0-android)
- Use valid Supabase credentials (check `.env` file)
- Network connectivity required (mock offline mode if needed)

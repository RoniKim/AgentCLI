# Build Checks — MAUI Blazor Hybrid (Windows + Android)

**Scope:** Frontend build verification
**Date:** 2026-02-10
**SDK:** .NET 10.0.102

## Pre-Flight

### Environment Setup
```bash
# Verify SDK
dotnet --version
# Expected: 10.0.102+

# Verify MAUI workload
dotnet workload list
# Expected: maui-windows, maui-android installed

# Check .env file exists
ls .env
# Should contain: SUPABASE_URL, SUPABASE_ANON_KEY
```

### Project Structure
```bash
# Verify critical files
ls BudgetBook.csproj
ls Components/App.razor
ls Components/Routes.razor
ls MauiProgram.cs
```

---

## 1. Windows Build

### Command
```bash
cd C:\Dev\BudgetBook
dotnet build -f net10.0-windows10.0.19041.0 --configuration Debug
```

### Success Criteria
- [x] Exit code 0
- [ ] 0 errors
- [ ] 0 warnings (or only benign warnings)
- [ ] Output: `BudgetBook.dll`, `BudgetBook.exe`

### Common Issues
- **CS0246 (missing type):** Check PackageReferences in .csproj
- **CS0103 (name does not exist):** Check using directives, service registration
- **NETSDK1005 (missing workload):** Run `dotnet workload install maui-windows`
- **Radzen components not found:** Verify `Radzen.Blazor` v8.7.4+ in .csproj

### Verify Output
```bash
ls bin/Debug/net10.0-windows10.0.19041.0/win10-x64/BudgetBook.exe
# Should exist after successful build
```

---

## 2. Android Build

### Command
```bash
cd C:\Dev\BudgetBook
dotnet build -f net10.0-android --configuration Debug
```

### Success Criteria
- [x] Exit code 0
- [ ] 0 errors
- [ ] 0 warnings (or only benign APK warnings)
- [ ] Output: APK in `bin/Debug/net10.0-android/`

### Common Issues
- **Android SDK not found:** Set `ANDROID_HOME` environment variable
- **Java SDK missing:** Install JDK 17+ and set `JAVA_HOME`
- **NETSDK1005 (missing workload):** Run `dotnet workload install maui-android`
- **APT2260 (resource not found):** Check Resources folder structure

### Verify Output
```bash
ls bin/Debug/net10.0-android/com.companyname.budgetbook-Signed.apk
# Should exist after successful build
```

---

## 3. Test Project Build

### Command
```bash
cd C:\Dev\BudgetBook
dotnet build BudgetBook.Tests/BudgetBook.Tests.csproj --configuration Debug
```

### Success Criteria
- [ ] Exit code 0
- [ ] 0 errors
- [ ] Output: `BudgetBook.Tests.dll`

### Run Tests
```bash
dotnet test BudgetBook.Tests/BudgetBook.Tests.csproj --no-build
```

### Expected
- [ ] All tests pass (or known failures documented)
- [ ] ApiQueryHelpersTests runs successfully

---

## 4. Code Quality Checks

### No Forbidden Secrets
```bash
cd C:\Dev\BudgetBook
rg "service_role|cron_secret|CRON_SECRET|serviceRole|cronSecret" --glob "*.cs" --glob "*.razor"
```
- **Expected:** 0 matches
- **If found:** Security Policy P0 violation → FAIL

### AppConfig Validation
```bash
rg "SupabaseServiceRoleKey|SERVICE_ROLE_KEY" --glob "*.cs"
```
- **Expected:** 0 matches in Services/AppConfig.cs
- **Allowed:** Only in backend docs/edge functions (not client code)

### EdgeService JWT Pattern
```bash
rg "Authorization.*Bearer" Services/EdgeService.cs
```
- **Expected:** 1 match in BuildRequest() using CurrentSession.AccessToken
- **Verify:** NO hardcoded service role key

---

## 5. Dependency Audit

### NuGet Packages (from BudgetBook.csproj)
```xml
<PackageReference Include="Microsoft.Maui.Controls" Version="10.0.30" />
<PackageReference Include="Microsoft.AspNetCore.Components.WebView.Maui" Version="10.0.30" />
<PackageReference Include="Supabase" Version="1.1.1" />
<PackageReference Include="Supabase.Postgrest" Version="4.1.0" />
<PackageReference Include="Supabase.Gotrue" Version="6.0.3" />
<PackageReference Include="Newtonsoft.Json" Version="13.0.4" />
<PackageReference Include="Radzen.Blazor" Version="8.7.4" />
```

### Restore Check
```bash
dotnet restore
```
- [ ] All packages restore successfully
- [ ] No version conflicts
- [ ] No deprecated packages (check warnings)

---

## 6. Runtime Prerequisites (Windows)

### Launch Test
```bash
dotnet run --framework net10.0-windows10.0.19041.0
```

### Success Criteria
- [ ] App window opens
- [ ] No unhandled exceptions in console
- [ ] Login page renders
- [ ] Can authenticate with valid credentials

### Common Runtime Errors
- **MissingMethodException:** Version mismatch in Radzen/MAUI packages
- **FileNotFoundException (.env):** Copy `.env` to output directory
- **Supabase 400/401:** Check `SUPABASE_ANON_KEY` validity

---

## 7. Runtime Prerequisites (Android)

### Deploy to Emulator
```bash
# Start emulator (if not running)
emulator -avd Pixel_5_API_34

# Install APK
adb install -r bin/Debug/net10.0-android/com.companyname.budgetbook-Signed.apk

# Launch app
adb shell am start -n com.companyname.budgetbook/.MainActivity
```

### Success Criteria
- [ ] APK installs without errors
- [ ] App opens (no crash on startup)
- [ ] Login page renders
- [ ] Can authenticate with valid credentials

### Common Runtime Errors
- **System.TypeLoadException:** ABI mismatch → rebuild for correct architecture
- **NetworkOnMainThreadException:** Check ConnectivityService async patterns
- **Supabase timeout:** Check network permissions in AndroidManifest.xml

---

## 8. P0 Gate Criteria

### Build Gate
- [ ] Windows build: 0 errors
- [ ] Android build: 0 errors
- [ ] Test project build: 0 errors
- [ ] Security policy checks pass

### Runtime Gate
- [ ] Windows: Launches + Login works
- [ ] Android: Launches + Login works
- [ ] No critical exceptions in logs

### Blocker Issues
If any of these FAIL, escalate immediately:
1. Build errors preventing compilation
2. Security policy violations (service_role in client code)
3. Runtime crash on app launch
4. Authentication completely broken

---

## 9. CI/CD Integration (Future)

### GitHub Actions Example
```yaml
- name: Build Windows
  run: dotnet build -f net10.0-windows10.0.19041.0

- name: Build Android
  run: dotnet build -f net10.0-android

- name: Run Tests
  run: dotnet test --no-build
```

---

## Backend Requests (Out of Scope)

_If backend API errors occur during testing, record in NOTES.md as "Backend Request" with:_
- RPC name
- Expected vs actual response
- Error code/message

---

## Execution Log

**Last Run:** [DATE]
**Windows Build:** ✅ PASS / ❌ FAIL
**Android Build:** ✅ PASS / ❌ FAIL
**Security Checks:** ✅ PASS / ❌ FAIL
**Runtime Smoke Test:** ✅ PASS / ❌ FAIL

_Update after each build cycle._

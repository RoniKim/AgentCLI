# BACKLOG

- [ ] T1 Add FixedExpenseDto and CRUD API methods to ApiService
- [ ] T2 Create FixedExpenses management page with full CRUD
- [ ] T3 Add FixedExpenses nav item to MainLayout sidebar
- [ ] T4 Add LiabilityDto and CRUD API methods for liabilities
- [ ] T5 Add unit tests for LiabilityDto serialization and defaults


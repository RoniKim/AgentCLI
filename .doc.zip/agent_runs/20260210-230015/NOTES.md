# Task T2: Create FixedExpenses Management Page - COMPLETED

## Files Changed
- Components/Pages/FixedExpenses.razor - Refactored from ListBox/detail view to DataGrid view

## Changes Made
- Replaced ListBox selection UI with RadzenDataGrid showing all fields inline
- DataGrid displays: ExpenseName, AmountKrw (formatted), PaymentDay, CategoryName, IsActive (badge), Note
- Row-level Edit/Delete buttons in DataGrid with HandleEditRow() and HandleDeleteRow() methods
- Removed _selectedId and _selectedExpense state variables (not needed for DataGrid approach)
- Added _deletingExpense to track which expense is being deleted
- All CRUD operations wired to ApiService: GetFixedExpensesAsync, UpsertFixedExpenseAsync, DeleteFixedExpenseAsync
- Full lifecycle management: CancellationTokenSource, _disposed flag, safe StateHasChanged
- Form validation for ExpenseName (required field)
- SkeletonLoader, ErrorToast, NetworkErrorBanner, ConfirmDialog all implemented

## Validation
- Run the app and navigate to /fixed-expenses
- Verify DataGrid shows all expenses with columns: ExpenseName, AmountKrw, PaymentDay, CategoryName, IsActive, Note
- Test Create: click "새 고정지출", fill form, save
- Test Edit: click edit button on a row, modify, save
- Test Delete: click delete button, confirm dialog, verify deletion
- Verify FormatHelpers.FormatKrw() formats amounts correctly
- Verify badge shows "활성" (green) or "비활성" (red) based on IsActive
